# V3R4 复现包

论文：*Common Breaks and Break Intervals in Heterogeneous Factor Panels*（V3R4，2026 年 10 月；以 V3R3 为底稿）。

## 1. 包内文件

```
V3R4/
├── README.md            本说明
├── DATA_SOURCES.md      复现数据来源清单
├── data/v9_8_data.csv   唯一的输入数据（v9_8 冻结面板）
├── run_all.R            主程序：只生成 Tables/*.tex 和 Figures/app_scan.pdf
├── R/
│   ├── 01_estimators.R  本文的三步估计量：扫描统计量、局部精估、诊断、置信区间、断点区间
│   ├── 02_benchmarks.R  四个比较方法：BFK、Dai、DKW、OW
│   ├── 03_simulation.R  蒙特卡洛数据生成与逐次重复
│   ├── 04_application.R 英国房价实证（动态方程）
│   └── 05_output.R      唯一写文件的模块：写表和图
├── Tables/              11 个结果表，每表一个 .tex（由 run_all.R 生成）
├── Figures/app_scan.pdf 唯一的图（由 run_all.R 生成）
├── main.tex  appendix.tex  preamble.tex  references.tex
├── build.sh             由 tex、Tables、Figures 编译两份 PDF
├── main.pdf  appendix.pdf
```

## 2. 复现步骤

```sh
Rscript --vanilla run_all.R --cores=4   # 生成全部表和图
sh build.sh                              # 编译 main.pdf 和 appendix.pdf
```

- 软件：R ≥ 4.0，只用基础包（stats、graphics、grDevices、parallel），在 R 4.3.3 下测试；pdfLaTeX（TeX Live 2023 测试通过）。
- 运行时间：在 4 核云主机上 `--cores=4` 共约 2 小时 45 分钟，单核约 10.5 小时。几乎全部用于蒙特卡洛（3,900 个模拟面板），其中断点区间设计（1,200 个面板）最耗时，因为每个面板要对每个起点和每个长度 D = 1, …, 12 计算一次压缩统计量。Windows 上 `--cores` 无效，自动单核运行。
- 每次重复都有自己的固定种子，结果与核数无关。
- `run_all.R` 只写 `Tables/` 下 11 个 `.tex` 和 `Figures/app_scan.pdf`，不写任何中间文件、日志或数据。模拟结果和实证结果只保存在内存里。
- 重新运行后，11 个表与包内版本逐字节相同；图的内容相同，只有 R 的 `pdf()` 自动写入的创建时间戳不同。

## 3. 表、图与代码的对应

正文表 1（三类日期的定义）是概念表，直接写在 `main.tex` 中，不由代码生成。

| 输出 | 正文位置 | 生成函数（05_output.R） | 计算来源 |
|---|---|---|---|
| `Tables/mc_dates.tex` | 表 2 | `write_mc_tables()` | `run_mc()` → `one_replication()`（03） |
| `Tables/mc_diagnosis.tex` | 表 3 | `write_mc_tables()` | 同上，`declared` 列 |
| `Tables/mc_ci.tex` | 表 4 | `write_mc_tables()` | `interval_replication()`（03）→ `refine_break()`（01） |
| `Tables/mc_breakint.tex` | 表 5 | `write_mc_tables()` | `breakint_replication()`（03）→ `breaks_and_intervals()`（01）、`benchmark_m_dates()`（03） |
| `Tables/mc_intloc.tex` | 表 6 | `write_mc_tables()` | 同上 |
| `Tables/mc_dynamic.tex` | 表 7 | `write_mc_tables()` | `dynamic_replication()`（03） |
| `Tables/app_breaks.tex` | 表 8 | `write_app_tables()` | `run_application()`（04）→ `breaks_and_intervals()`（01） |
| `Tables/app_intervals.tex` | 表 9 | `write_app_tables()` | 同上，`find_intervals()`、`classify_dates()`（01） |
| `Tables/app_compare.tex` | 表 10 | `write_app_tables()` | `benchmark_m_dates()`（03）→ 02 中各方法 |
| `Tables/app_country.tex` | 表 11 | `write_app_tables()` | `participation_by_group()`、`interval_participation()`（04） |
| `Tables/app_sensitivity.tex` | 表 12 | `write_app_tables()` | `run_application()` 中 h = 18、36 |
| `Figures/app_scan.pdf` | 图 1 | `write_figures()` | `concentration_scan()`、`find_intervals()`（01） |

R 代码中每个函数前都有注释，写明三件事：作用（Purpose）、在包内被谁调用（Used by）、最终贡献于哪些表和图（Feeds）。

## 4. tex 修订标记

- 以 V3R3 为底稿。V3R3 中用 `%%` 隐藏的 V3R2_2 段落已直接删除；V3R3 的绿色标记已去掉，相应文字恢复为黑色。
- V3R3 中不再需要的段落（静态方程的实证结果等）已直接删除。
- V3R4 中新增或改写的段落为橙色：单独段落用 `\textcolor{revisionorange}{...}`；新增的整节、定义、定理、假设、注释和表格放在 `\begingroup\color{revisionorange} ... \endgroup` 中。`revisionorange` 在 `preamble.tex` 中定义。
- `main.tex` 和 `appendix.tex` 通过 `xr-hyper` 互相引用，因此 `build.sh` 交替编译五次。

## 5. 相对 V3R3 的主要改动

1. **三类日期。** 每个日期归入共同断点、断点区间或其他之一（正文表 1）。共同断点的判定规则不变：$\hat C(\hat k)>\kappa$，报告 $\hat k$ 及其 95% 置信区间。断点区间由新的第 3 步给出：删去区间内的观测，把区间前后各 h 期拼接，在拼接点上计算同一个扫描统计量，得到压缩集中度 $\hat G(t_1,t_2)$。若 $\hat G(t_1,t_2)>\kappa$ 且 $1\le t_2-t_1\le D_{\max}$，则报告区间 $[t_1,t_2]$（保留 90% 能量的最短区间）、压缩日期 $t^*$ 和能量 $\hat G$。被分离规则压下去的尖峰（区间内 $\hat C>\kappa$）也归入断点区间。
2. **$D_{\max}=12$ 个月。**
3. **理论。** 以静态面板为基准：定义 2.1 加入断点区间；新增假设 4.6、定理 4.8（压缩集中度的一致极限）、定理 4.9（三类划分的一致性）和注 4.4（共同断点附近的断点区间）；命题 5.1 把这些结果推广到动态面板。附录新增 G 节的证明。
4. **第 2 类在静态方程上的处理。** 不使用拼接点截距哑变量（它会在短区间上产生偏差）。拼接后的面板满足与原面板相同的假设，所以理论和代码都直接沿用原扫描统计量。静态模拟包含 AR(1) 误差的设计。
5. **蒙特卡洛。** 新增断点区间设计（表 5、表 6），与 BFK、Dai、DKW、OW 比较；动态设计（表 7）加入 DKW 和 OW。
6. **实证。** 只用动态价格方程。新增断点区间表（表 9）；比较表、参与度表和窗口敏感性表都加入断点区间。
