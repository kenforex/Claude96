# =====================================================================
# 05_output.R
# The only module that writes files: one .tex file per table in Tables/
# and one .pdf file per figure in Figures/.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: format numbers, with "--" for missing values.
# Used by: every table writer below.
# Feeds: all tables.
# ---------------------------------------------------------------------
fmt <- function(x, digits = 2) {
  ifelse(is.na(x), "--", formatC(x, format = "f", digits = digits))
}

# ---------------------------------------------------------------------
# Purpose: write one LaTeX table (booktabs) with a caption, label, header
#   rows, body rows and a note.
# Used by: write_mc_tables(), write_app_tables().
# Feeds: all tables.
# ---------------------------------------------------------------------
write_tex_table <- function(root, file, caption, label, align, header, body, note) {
  lines <- c("\\begin{table}[htbp]", "\\centering", "\\small",
             paste0("\\caption{", caption, "}\\label{", label, "}"),
             paste0("\\begin{tabular}{", align, "}"), "\\toprule", header, "\\midrule",
             body, "\\bottomrule", "\\end{tabular}",
             paste0("\\par\\smallskip\\begin{minipage}{.95\\linewidth}\\footnotesize ",
                    note, "\\end{minipage}"),
             "\\end{table}")
  writeLines(lines, file.path(root, "Tables", paste0(file, ".tex")))
}

# ---------------------------------------------------------------------
# Purpose: readable names of the Monte Carlo designs.
# Used by: write_mc_tables().
# Feeds: Tables mc_dates, mc_diagnosis, mc_dynamic.
# ---------------------------------------------------------------------
design_name <- c(same_none = "Same sign, none", mixed_none = "Mixed sign, none",
                 same_dispersed = "Same sign, dispersed", mixed_dispersed = "Mixed sign, dispersed",
                 same_cluster = "Same sign, clustered", mixed_cluster = "Mixed sign, clustered",
                 null_dispersed = "No common break, dispersed")

# ---------------------------------------------------------------------
# Purpose: label of a break interval [t1, t2] in months (first month of
#   the new regime at both ends).
# Used by: write_app_tables().
# Feeds: Tables app_intervals, app_country.
# ---------------------------------------------------------------------
interval_label <- function(t1, t2) {
  paste(month_label(t1), "to", month_label(t2))
}

# ---------------------------------------------------------------------
# Purpose: write the Monte Carlo tables.
# Used by: write_tables().
# Feeds: Tables mc_dates, mc_diagnosis, mc_ci, mc_dynamic, mc_breakint,
#        mc_intloc.
# ---------------------------------------------------------------------
write_mc_tables <- function(root, mc, settings) {
  k0 <- settings$k0
  methods <- c("Proposed", "BFK", "Dai", "DKW", "OW")
  # ---- Table mc_dates: exact date and date within two periods --------
  d <- mc$dates[mc$dates$design != "null_dispersed", ]
  body <- c()
  for (panel in c("exact", "within")) {
    label <- "A. Estimated date equals $k_0$"
    if (panel == "within") label <- "B. Estimated date within two periods of $k_0$"
    body <- c(body, paste0("\\multicolumn{7}{@{}l}{\\textit{", label, "}}\\\\"))
    for (des in unique(d$design)) for (N in settings$N_grid) {
      z <- d[d$design == des & d$N == N, ]
      vals <- c()
      for (m in methods) {
        e <- z[[m]] - k0
        if (panel == "exact") vals <- c(vals, mean(!is.na(e) & e == 0))
        else vals <- c(vals, mean(!is.na(e) & abs(e) <= 2))
      }
      body <- c(body, paste0(design_name[des], " & ", N, " & ",
                             paste(fmt(vals), collapse = " & "), "\\\\"))
    }
  }
  write_tex_table(root, "mc_dates",
    "Monte Carlo: accuracy of the common break date",
    "tab:mc-dates", "@{}llccccc@{}",
    "Design & $N$ & Proposed & BFK & Dai & DKW & OW\\\\", body,
    paste0(settings$R, " replications per cell; $T=", settings$T, "$, $k_0=", k0,
           "$, one common break shared by half of the units, jump magnitude ", settings$d,
           ". Individual breaks: none; dispersed (one per unit, uniform over the sample); ",
           "clustered (40\\% of the units, jump magnitude ", 1.5 * settings$d,
           ", dates 25--64 periods after $k_0$). Proposed: $h=", settings$h, "$, $\\ell=",
           settings$ell, "$, $\\kappa=", settings$kappa, "$; a replication without a declared ",
           "common break counts as a failure. Benchmarks estimate one break on the full sample."))
  # ---- Table mc_diagnosis: number of declared common breaks ----------
  body <- c()
  for (des in unique(mc$dates$design)) {
    target <- 1
    if (des == "null_dispersed") target <- 0
    cells <- c()
    for (N in settings$N_grid) {
      z <- mc$dates[mc$dates$design == des & mc$dates$N == N, ]
      cells <- c(cells, fmt(mean(z$declared == target)), fmt(mean(z$declared)))
    }
    body <- c(body, paste0(design_name[des], " & ", paste(cells, collapse = " & "), "\\\\"))
  }
  write_tex_table(root, "mc_diagnosis",
    "Monte Carlo: diagnosis of the number of common breaks",
    "tab:mc-diagnosis", "@{}lcccccc@{}",
    paste0(" & \\multicolumn{2}{c}{$N=", settings$N_grid[1], "$} & \\multicolumn{2}{c}{$N=",
           settings$N_grid[2], "$} & \\multicolumn{2}{c}{$N=", settings$N_grid[3], "$}\\\\",
           " Design & Correct & Mean & Correct & Mean & Correct & Mean\\\\"), body,
    paste0("Correct: frequency with which the rule declares exactly the true number of common ",
           "breaks (one, or zero in the last design). Mean: average number declared. ",
           "Same designs and settings as Table~\\ref{tab:mc-dates}."))
  # ---- Table mc_ci: 95% confidence intervals for the common break date
  body <- c()
  for (N in settings$N_ci) for (dd in settings$d_ci) {
    z <- mc$intervals[mc$intervals$N == N & mc$intervals$d == dd, ]
    ok <- abs(z$k_hat - settings$k0_ci) <= floor(settings$h_ci / 2)
    body <- c(body, paste0(N, " & ", dd, " & ", fmt(mean(ok)), " & ",
                           fmt(mean(z$k_hat == settings$k0_ci)), " & ",
                           fmt(mean(z$cover)), " & ", fmt(mean(z$cover[ok])), " & ",
                           fmt(mean(z$length), 1), "\\\\"))
  }
  write_tex_table(root, "mc_ci",
    "Monte Carlo: 95\\% confidence intervals for the common break date",
    "tab:mc-ci", "@{}cccccccc@{}",
    "$N$ & Jump & Located & Exact & Coverage & Coverage$\\mid$located & Length\\\\", body,
    paste0(settings$R, " replications per cell; $T=", settings$T_ci, "$, $k_0=",
           settings$k0_ci, "$, half of the units break, no individual breaks; $h=",
           settings$h_ci, "$, $\\ell=", settings$ell_ci, "$. Located: the refined date lies ",
           "within $h/2$ of $k_0$. Intervals are $\\hat k\\pm\\lfloor q_{.975}/\\hat L\\rfloor$ with ",
           "$q_{.975}=", fmt(argmax_quantile(0.95)), "$ from the argmax distribution."))
  # ---- Table mc_dynamic ----------------------------------------------
  body <- c()
  dyn_methods <- c("Static", "Dynamic", "BFK", "Dai", "DKW", "OW")
  for (des in unique(mc$dynamic$design)) {
    z <- mc$dynamic[mc$dynamic$design == des, ]
    cells <- c()
    for (m in dyn_methods) {
      e <- z[[m]] - k0
      cells <- c(cells, paste0(fmt(mean(!is.na(e) & e == 0)), "/", fmt(mean(!is.na(e) & abs(e) <= 2))))
    }
    body <- c(body, paste0(design_name[des], " & ", paste(cells, collapse = " & "),
                           " & ", fmt(mean(z$declared_static == 1)), " & ",
                           fmt(mean(z$declared_dynamic == 1)), "\\\\"))
  }
  write_tex_table(root, "mc_dynamic",
    "Monte Carlo: dynamic panels",
    "tab:mc-dynamic", "@{}l*{8}{@{\\hspace{5pt}}c}@{}",
    paste0(" & \\multicolumn{6}{c}{Exact / within two periods} & ",
           "\\multicolumn{2}{c}{One break declared}\\\\ ",
           "Design & Static & Dynamic & BFK & Dai & DKW & OW & Static & Dynamic\\\\"), body,
    paste0(settings$R, " replications, $N=", settings$N_dyn, "$, $T=", settings$T,
           "$; $y_{it}$ has a unit-specific autoregressive coefficient drawn from $U(0.3,0.7)$. ",
           "Static and Dynamic: the proposed estimator without and with the lagged dependent ",
           "variable and two lags of the averages. The benchmarks use the dynamic specification ",
           "and estimate one break. One break declared: frequency with which exactly one common ",
           "break is declared."))
  # ---- Table mc_breakint: common break and break interval ------------
  bi <- mc$breakint
  bi_static <- c("static_iid_int", "static_ar_int", "static_iid_none", "static_ar_none",
                 "static_ar8_none")
  bi_dynamic <- c("dynamic_int", "dynamic_none")
  row_name <- c(static_iid_int = "Interval, i.i.d.", static_ar_int = "Interval, AR(0.5)",
                static_iid_none = "None, i.i.d.", static_ar_none = "None, AR(0.5)",
                static_ar8_none = "None, AR(0.8)", dynamic_int = "Interval",
                dynamic_none = "None")
  body <- c()
  for (panel in c("static", "dynamic")) {
    designs <- bi_static
    title <- "A. Static panels"
    if (panel == "dynamic") { designs <- bi_dynamic; title <- "B. Dynamic panels" }
    body <- c(body, paste0("\\multicolumn{13}{@{}l}{\\textit{", title, "}}\\\\"))
    for (des in designs) for (N in unique(bi$N[bi$design == des])) {
      z <- bi[bi$design == des & bi$N == N, ]
      cells <- c(fmt(mean(z$common)))
      for (m in c("BFK", "Dai", "DKW", "OW")) cells <- c(cells, fmt(mean(z[[paste0(m, "_common")]])))
      cells <- c(cells, fmt(mean(z$found)), fmt(mean(z$as_common)))
      for (m in c("BFK", "Dai", "DKW", "OW")) cells <- c(cells, fmt(mean(z[[paste0(m, "_inside")]])))
      body <- c(body, paste0(row_name[des], " & ", N, " & ", paste(cells, collapse = " & "), "\\\\"))
    }
  }
  lo <- min(settings$int_dates); hi <- max(settings$int_dates)
  write_tex_table(root, "mc_breakint",
    "Monte Carlo: common breaks and break intervals",
    "tab:mc-breakint", "@{}l@{\\hspace{4pt}}c@{\\hspace{6pt}}ccccc@{\\hspace{8pt}}cccccc@{}",
    paste0(" & & \\multicolumn{5}{c}{Common break dated exactly} & ",
           "\\multicolumn{6}{c}{Break interval}\\\\ ",
           "\\cmidrule(lr){3-7}\\cmidrule(l){8-13} ",
           "Design & $N$ & Prop. & BFK & Dai & DKW & OW & Prop. & Common & BFK & Dai & DKW & OW\\\\"),
    body,
    paste0(settings$R, " replications per cell; $T=", settings$T, "$. Common break at $k_0=",
           settings$k0_bi, "$ (half of the units, jump ", settings$d, "); one individual break per ",
           "unit (jump $\\pm", settings$d_bg, "$, date uniform over the sample). Interval designs: ",
           100 * settings$int_share, "\\% of the units also change once (jump $\\pm", settings$d,
           "$) at a date drawn uniformly from $\\{", lo, ",\\ldots,", hi, "\\}$, so the interval ",
           "carries ", 100 * settings$int_share / settings$share, "\\% of the energy of the common ",
           "break. None: no interval. AR($\\rho$): AR(1) errors with all jumps multiplied by ",
           "$\\{(1+\\rho)/(1-\\rho)\\}^{1/2}$, which keeps the long-run energies unchanged. Dynamic ",
           "panels: autoregressive coefficient drawn from $U(0.3,0.7)$, i.i.d.\\ errors. Proposed: $h=",
           settings$h, "$, $\\ell=", settings$ell, "$, $\\kappa=", settings$kappa, "$, $D_{\\max}=",
           settings$Dmax, "$, $1-\\alpha=", 1 - settings$alpha, "$. Break interval, Prop.: a break ",
           "interval overlapping $[", lo, ",", hi, "]$ is declared (in the designs without an interval, ",
           "a false one). Common: a common break is declared inside $[", lo, ",", hi, "]$. ",
           "Benchmarks estimate two breaks (minimum regime length ", settings$trim, "); for them the ",
           "interval columns give the frequency of a date inside $[", lo, ",", hi, "]$. OW: dates of ",
           "the largest group."))
  # ---- Table mc_intloc: location of the break interval ---------------
  body <- c()
  for (panel in c("static", "dynamic")) {
    designs <- bi_static
    title <- "A. Static panels"
    if (panel == "dynamic") { designs <- bi_dynamic; title <- "B. Dynamic panels" }
    body <- c(body, paste0("\\multicolumn{8}{@{}l}{\\textit{", title, "}}\\\\"))
    for (des in designs) for (N in unique(bi$N[bi$design == des])) {
      z <- bi[bi$design == des & bi$N == N, ]
      start <- paste0(row_name[des], " & ", N, " & ")
      if (all(is.na(z$t1))) {
        body <- c(body, paste0(start, "-- & -- & -- & -- & ", fmt(mean(z$other)), " & ",
                               fmt(mean(z$declared)), "\\\\"))
      } else {
        body <- c(body, paste0(start, fmt(mean(z$t1, na.rm = TRUE), 1), " & ",
                               fmt(mean(z$t2, na.rm = TRUE), 1), " & ",
                               fmt(mean(z$tstar, na.rm = TRUE), 1), " (", fmt(sd(z$tstar, na.rm = TRUE), 1),
                               ") & ", fmt(mean(z$G, na.rm = TRUE)), " & ", fmt(mean(z$other)), " & ",
                               fmt(mean(z$declared)), "\\\\"))
      }
    }
  }
  write_tex_table(root, "mc_intloc",
    "Monte Carlo: location and energy of the break interval",
    "tab:mc-intloc", "@{}llcccccc@{}",
    paste0("Design & $N$ & $\\hat t_1$ & $\\hat t_2$ & $\\hat t^*$ (s.d.) & $\\hat G(\\hat t_1,\\hat t_2)$ & ",
           "Other intervals & Common breaks\\\\"),
    body,
    paste0("Same designs as Table~\\ref{tab:mc-breakint}. $\\hat t_1$, $\\hat t_2$, $\\hat t^*$ and ",
           "$\\hat G$: means over the replications in which a break interval overlapping the true one ",
           "is declared; true interval ", lo, "--", hi, " (centre ", fmt((lo + hi) / 2, 1), "). Other ",
           "intervals: average number per panel of declared break intervals more than $\\ell$ away ",
           "from the true interval that do not contain the common break. Common breaks: average ",
           "number of declared common breaks (true number one)."))
}

# ---------------------------------------------------------------------
# Purpose: write the application tables.
# Used by: write_tables().
# Feeds: Tables app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity.
# ---------------------------------------------------------------------
write_app_tables <- function(root, app) {
  st <- app$settings
  b <- app$main$breaks
  iv <- app$main$intervals
  # ---- Table app_breaks -----------------------------------------------
  body <- c()
  for (j in seq_len(nrow(b))) {
    near <- app$v98[which.min(abs(app$v98 - b$k_hat[j]))]
    ref <- "--"
    if (abs(near - b$k_hat[j]) <= 12) ref <- month_label(near)
    ci <- month_label(b$k_hat[j])
    if (b$lower[j] != b$upper[j]) ci <- paste(month_label(b$lower[j]), "to", month_label(b$upper[j]))
    body <- c(body, paste0(month_label(b$k_screen[j]), " & ", month_label(b$k_hat[j]), " & ", ci,
                           " & ", fmt(b$C[j]), " & ", fmt(b$lambda[j]), " & ", ref, "\\\\"))
  }
  write_tex_table(root, "app_breaks",
    "Common breaks in the UK house-price equation",
    "tab:app-breaks", "@{}llcccc@{}",
    "Screened & Refined & 95\\% conf.\\ interval & $\\hat C(\\hat k)$ & $\\hat\\lambda/N$ & PC date\\\\",
    body,
    paste0("349 LADs, 2004m1--2025m12. Dates are the first month of the new regime. ",
           "Dynamic price equation: lagged price, changing slopes on log sales and log employment, ",
           "and as CCEX proxies the averages of both regressors and of the lagged price with three ",
           "lags of each. $h=", st$h, "$, $\\ell=", st$ell, "$, $\\kappa=", st$kappa, "$. ",
           "$\\hat C$ is in long-run signal-to-noise units; $\\hat\\lambda/N$ is the debiased ",
           "break energy per LAD. PC date: the nearest common date of Pang and Chaudhuri (2026) ",
           "within twelve months."))
  # ---- Table app_intervals ---------------------------------------------
  cls <- classify_dates(app$main$scan, b, iv)
  body <- c()
  for (q in seq_len(nrow(iv))) {
    type <- "dispersed"
    if (iv$type[q] == "peak") type <- "suppressed peak"
    body <- c(body, paste0(interval_label(iv$t1[q], iv$t2[q]), " & ", iv$t2[q] - iv$t1[q] + 1, " & ",
                           month_label(iv$tstar[q]), " & ", fmt(iv$G[q]), " & ", fmt(iv$G_max[q]),
                           " & ", fmt(iv$peak[q]), " & ", type, "\\\\"))
  }
  if (nrow(iv) == 0) body <- "\\multicolumn{7}{c}{none}\\\\"
  write_tex_table(root, "app_intervals",
    "Break intervals in the UK house-price equation",
    "tab:app-intervals", "@{}lcccccl@{}",
    "Interval $[\\hat t_1,\\hat t_2]$ & Months & $\\hat t^*$ & $\\hat G(\\hat t_1,\\hat t_2)$ & $\\max\\hat G$ & Peak $\\hat C$ & Type\\\\",
    body,
    paste0("Same equation and tuning as Table~\\ref{tab:app-breaks}; $D_{\\max}=", st$Dmax,
           "$ months and $1-\\alpha=", 1 - st$alpha, "$. Of the ", sum(!is.na(cls)), " scanned months, ",
           sum(cls == 1, na.rm = TRUE), " are common breaks, ", sum(cls == 2, na.rm = TRUE),
           " lie in break intervals and ", sum(cls == 3, na.rm = TRUE), " are in neither category. ",
           "Interval: the shortest interval that keeps ",
           "a share $1-\\alpha$ of the largest compressed concentration $\\max\\hat G$ of its ",
           "neighbourhood, in first months of the new regime. $\\hat t^*$: compressed date, which ",
           "splits the interval's energy in half. Peak $\\hat C$: largest value of the scan inside ",
           "the interval. Suppressed peak: the scan exceeds $\\kappa$ inside the interval, but the ",
           "date lies within $h$ of a stronger common break and is not a candidate."))
  # ---- Table app_compare -----------------------------------------------
  body <- c(paste0("Proposed: common breaks & ", paste(month_label(b$k_hat), collapse = ", "), "\\\\"),
            paste0("Proposed: break intervals & ",
                   paste0(month_label(iv$t1), "/", substr(month_label(iv$t2), 3, 7), collapse = ", "), "\\\\"))
  for (m in c("BFK", "Dai", "DKW", "OW")) {
    labs <- month_label(app$bench[[m]])
    for (j in seq_along(labs)) {
      k <- app$bench[[m]][j]
      if (any(abs(k - b$k_hat) <= 2)) labs[j] <- paste0(labs[j], "$^{a}$")
      else if (any(k >= iv$t1 - 2 & k <= iv$t2 + 2)) labs[j] <- paste0(labs[j], "$^{b}$")
    }
    body <- c(body, paste0(m, " & ", paste(labs, collapse = ", "), "\\\\"))
  }
  body <- c(body, "\\midrule", paste0("Pang and Chaudhuri (2026), spatial & ",
                                      paste(month_label(app$v98), collapse = ", "), "\\\\"))
  write_tex_table(root, "app_compare",
    "Common break dates: proposed estimator and existing methods",
    "tab:app-compare", "@{}lp{0.62\\linewidth}@{}",
    "Method & Dates (first month of the new regime)\\\\", body,
    paste0("Dynamic price equation. Break intervals are written as first/last month. Benchmarks ",
           "estimate four common breaks on the full sample with a minimum regime length of 24 ",
           "months, by sequential splitting with repartition. BFK: unit slopes, averages of prices ",
           "and regressors with regime-specific loadings. Dai: CCEX removed on the full sample, unit ",
           "slopes (spatial lag omitted). DKW: CCEX removed, pooled slopes. OW: three groups with ",
           "group-specific breaks; dates of the largest group. $^{a}$ within two months of a ",
           "proposed common break; $^{b}$ inside a proposed break interval or within two months ",
           "of it. Pang and Chaudhuri (2026): static spatial panel with four imposed breaks."))
  # ---- Table app_country -----------------------------------------------
  cc <- app$country; body <- c()
  for (type in c("break", "interval")) {
    z_type <- cc[cc$type == type, ]
    if (nrow(z_type) == 0) next
    title <- "A. Common breaks"
    if (type == "interval") title <- "B. Break intervals"
    body <- c(body, paste0("\\multicolumn{5}{@{}l}{\\textit{", title, "}}\\\\"))
    keys <- unique(paste(z_type$k, z_type$k2))
    for (key in keys) {
      z <- z_type[paste(z_type$k, z_type$k2) == key, ]
      lab <- month_label(z$k[1])
      if (type == "interval") lab <- interval_label(z$k[1], z$k2[1])
      body <- c(body, paste0(lab, " & ",
                             paste(paste0(fmt(z$share), " (", fmt(z$energy), ")"), collapse = " & "),
                             "\\\\"))
    }
  }
  write_tex_table(root, "app_country",
    "Participation by country group",
    "tab:app-country", "@{}lcccc@{}",
    "Break & England excl.\\ London & London & Scotland & Wales\\\\", body,
    paste0("Share of LADs whose own HAC jump Wald statistic exceeds the 5\\% $\\chi^2_2$ critical ",
           "value; mean long-run signal-to-noise jump energy in parentheses. Common breaks: jump at ",
           "the refined date in the refinement window. Break intervals: net slope change across the ",
           "interval, estimated in the compressed panel. LAD counts: ",
           paste(paste0(cc$group[1:4], " ", cc$n[1:4]), collapse = ", "), "."))
  # ---- Table app_sensitivity ------------------------------------------
  body <- c()
  for (hh in c("18", "24", "36")) {
    s <- app$sensitivity[[hh]]
    br <- "--"
    if (nrow(s$breaks) > 0) br <- paste(month_label(s$breaks$k_hat), collapse = ", ")
    ints <- "--"
    if (nrow(s$intervals) > 0) {
      ints <- paste0(month_label(s$intervals$t1), "/", substr(month_label(s$intervals$t2), 3, 7),
                     collapse = ", ")
    }
    body <- c(body, paste0(hh, " & ", br, " & ", ints, "\\\\"))
  }
  write_tex_table(root, "app_sensitivity",
    "Common breaks and break intervals for different window half-widths",
    "tab:app-sensitivity", "@{}cp{0.33\\linewidth}p{0.5\\linewidth}@{}",
    "$h$ & Common breaks & Break intervals (first/last month)\\\\", body,
    paste0("Same data and specification as Table~\\ref{tab:app-breaks}; $\\ell=", st$ell,
           "$, $\\kappa=", st$kappa, "$, $D_{\\max}=", st$Dmax, "$; three lags of the averages ",
           "for every $h$."))
}

# ---------------------------------------------------------------------
# Purpose: write every table of the paper.
# Used by: run_all.R.
# Feeds: all tables.
# ---------------------------------------------------------------------
write_tables <- function(root, mc, app, settings) {
  write_mc_tables(root, mc, settings)
  write_app_tables(root, app)
}

# ---------------------------------------------------------------------
# Purpose: Figure app_scan: the concentration scan C(k) of the dynamic
#   equation with the threshold kappa, the common breaks (dots), the
#   break intervals (shaded) with their compressed dates (triangles),
#   and the common dates of Pang and Chaudhuri (2026) (dotted lines).
# Used by: run_all.R.
# Feeds: Figure app_scan.
# ---------------------------------------------------------------------
write_figures <- function(root, app) {
  pdf(file.path(root, "Figures", "app_scan.pdf"), width = 7.2, height = 3.6)
  par(mar = c(3, 4, 1, 0.8), mgp = c(2.1, 0.6, 0), cex = 0.8)
  C <- app$main$scan
  k <- seq_along(C)
  date <- 2004 + k / 12                          # first month of the new regime
  top <- max(C, na.rm = TRUE)
  yl <- c(min(C, na.rm = TRUE), top * 1.45)
  plot(date, C, type = "n", xlab = "", ylab = expression(hat(C)(k)), ylim = yl,
       xlim = range(date[!is.na(C)]) + c(-0.3, 0.3))
  iv <- app$main$intervals
  for (q in seq_len(nrow(iv))) {
    rect(2004 + (iv$t1[q] - 0.5) / 12, yl[1] - 1, 2004 + (iv$t2[q] + 0.5) / 12, top * 1.15,
         col = "#F4D3A6", border = NA)
  }
  lines(date, C, col = "#1B6CA8", lwd = 1.2)
  abline(h = app$settings$kappa, lty = 2, col = "grey40")
  abline(v = 2004 + app$v98 / 12, lty = 3, col = "grey30")
  b <- app$main$breaks
  points(2004 + b$k_hat / 12, b$C, pch = 19, col = "#1B6CA8", cex = 0.9)
  if (nrow(iv) > 0) points(2004 + iv$tstar / 12, rep(top * 1.1, nrow(iv)), pch = 25,
                           bg = "#B35806", col = "#B35806", cex = 0.8)
  legend("top", c(expression(hat(C)(k)), expression(kappa), "common break", "break interval",
                  "compressed date", "Pang-Chaudhuri"),
         col = c("#1B6CA8", "grey40", "#1B6CA8", "#F4D3A6", "#B35806", "grey30"),
         lty = c(1, 2, NA, NA, NA, 3), pch = c(NA, NA, 19, 15, 25, NA),
         pt.bg = c(NA, NA, NA, NA, "#B35806", NA), pt.cex = c(1, 1, 1, 2, 1, 1),
         bg = "white", box.col = "white", ncol = 6, cex = 0.72, inset = 0.01)
  invisible(dev.off())
}
