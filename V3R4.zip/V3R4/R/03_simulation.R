# =====================================================================
# 03_simulation.R
# Monte Carlo designs. Every replication draws a new panel from its own
# seed, applies the proposed estimator and the benchmarks to the same
# panel, and returns one row of results. Nothing is written to disk.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: simulate one heterogeneous panel with a CCE factor structure,
#   one common break at k0, optional individual breaks and an optional
#   break interval.
#   y_it = alpha_i + phi_i y_i,t-1 + beta_it x_it + gamma_i f_t + e_it
#   x_it = a_i + Gamma_i f_t + v_it
#   beta_it = beta_i + Delta_i 1{t > k0} + theta_i 1{t > s_i}
#   Break interval: a share int_share of the units change their slope by
#   +-int_jump once, at a date drawn uniformly from int_dates.
#   rho_e > 0 gives AR(1) errors with the same variance sigma_i^2.
#   The new options draw random numbers only when they are used, so the
#   panels of the original designs are unchanged.
# Used by: one_replication(), interval_replication(), dynamic_replication(),
#          breakint_replication().
# Feeds: Tables mc_dates, mc_diagnosis, mc_ci, mc_dynamic, mc_breakint,
#        mc_intloc.
# ---------------------------------------------------------------------
simulate_panel <- function(N, TT, k0, sign = "same", d = 0.3, share = 0.5,
                           indiv = "none", d_ind = 0.3, dynamic = FALSE, seed = 1,
                           int_dates = c(), int_share = 0, int_jump = 0, rho_e = 0) {
  set.seed(seed)
  burn <- 50; TB <- TT + burn
  f <- rep(0, TB); for (t in 2:TB) f[t] <- 0.5 * f[t - 1] + sqrt(0.75) * rnorm(1)
  a <- runif(N); Gam <- runif(N, 0.5, 1.5); alpha <- rnorm(N); gam <- runif(N, 0.5, 1.5)
  sig <- sqrt(runif(N, 0.5, 1.5)); beta <- runif(N, 0.5, 1.5)
  phi <- if (dynamic) runif(N, 0.3, 0.7) else rep(0, N)
  v <- matrix(0, N, TB)
  for (t in 2:TB) v[, t] <- 0.5 * v[, t - 1] + sqrt(0.75) * rnorm(N)
  x <- a + outer(Gam, f) + v
  # coefficient paths (dates refer to the sample after the burn-in)
  B <- matrix(beta, N, TT)
  Delta <- rep(0, N)
  if (sign != "none") {
    part <- sample(N, floor(share * N))
    s <- if (sign == "same") rep(1, length(part)) else rep(c(1, -1), length.out = length(part))
    Delta[part] <- d * s
    B <- B + outer(Delta, as.numeric(1:TT > k0))
  }
  if (indiv == "dispersed") {                 # one break per unit, anywhere
    dates <- setdiff(ceiling(0.1 * TT):floor(0.9 * TT), k0)
    for (i in 1:N) {
      s_i <- dates[sample(length(dates), 1)]
      B[i, ] <- B[i, ] + d_ind * sample(c(-1, 1), 1) * as.numeric(1:TT > s_i)
    }
  }
  if (indiv == "cluster") {                   # 40% of the units, 25-64 periods after k0
    for (i in sample(N, floor(0.4 * N))) {
      s_i <- k0 + sample(25:64, 1)
      B[i, ] <- B[i, ] + d_ind * sample(c(-1, 1), 1) * as.numeric(1:TT > s_i)
    }
  }
  if (int_share > 0) {                        # break interval
    for (i in sample(N, floor(int_share * N))) {
      s_i <- int_dates[sample(length(int_dates), 1)]
      B[i, ] <- B[i, ] + int_jump * sample(c(-1, 1), 1) * as.numeric(1:TT > s_i)
    }
  }
  B <- cbind(matrix(beta, N, burn), B)
  y <- matrix(0, N, TB)
  eps <- matrix(rnorm(N * TB), N, TB) * sig
  if (rho_e > 0) {                            # AR(1) errors, variance kept at sigma_i^2
    for (t in 2:TB) eps[, t] <- rho_e * eps[, t - 1] + sqrt(1 - rho_e^2) * eps[, t]
  }
  for (t in 1:TB) {
    y_lag <- if (t > 1) y[, t - 1] else rep(0, N)
    y[, t] <- alpha + phi * y_lag + B[, t] * x[, t] + gam * f[t] + eps[, t]
  }
  keep <- (burn + 1):TB
  list(y = y[, keep], x = x[, keep], y_lag = y[, keep - 1], k0 = k0)
}

# ---------------------------------------------------------------------
# Purpose: build the static panel object (CCEX proxy = xbar) or the
#   dynamic one (lagged y as stable regressor; CSA proxies xbar_t and
#   lags 1..q of xbar and ybar, as in Chudik and Pesaran, 2015).
# Used by: one_replication(), interval_replication(), dynamic_replication(),
#          breakint_replication().
# Feeds: Tables mc_dates, mc_diagnosis, mc_ci, mc_dynamic, mc_breakint,
#        mc_intloc.
# ---------------------------------------------------------------------
sim_panel_object <- function(sim, dynamic = FALSE, q = 2) {
  xbar <- colMeans(sim$x)
  if (!dynamic) return(make_panel_data(sim$y, list(sim$x), cbind(xbar)))
  ybar_lag <- colMeans(sim$y_lag)
  TT <- ncol(sim$y)
  csa <- cbind(xbar, ybar_lag)
  for (L in 1:q) csa <- cbind(csa, c(rep(NA, L), xbar[1:(TT - L)]),
                              c(rep(NA, L), ybar_lag[1:(TT - L)]))
  make_panel_data(sim$y, list(sim$x), csa, stable = list(sim$y_lag), first = q + 1)
}

# ---------------------------------------------------------------------
# Purpose: one break date from each benchmark, estimated on the full
#   sample with trimming. OW: the group break with the largest energy.
# Used by: one_replication(), dynamic_replication().
# Feeds: Tables mc_dates, mc_dynamic.
# ---------------------------------------------------------------------
run_benchmarks <- function(panel, trim) {
  cands <- trim:(panel$T - trim)
  a <- panel$first - 1; b <- panel$T
  dfac <- defactor_ccex(panel)
  BFK <- cands[which.min(bfk_profile(panel, a, b, cands))]
  Dai <- cands[which.min(dai_profile(dfac, a, b, cands))]
  DKW <- cands[which.min(dkw_profile(dfac, a, b, cands))]
  ow <- ow_fit(dfac, G = 3, m = 1, min_len = trim, T_first = panel$first)
  OW <- ow$breaks$k[which.max(ow$breaks$energy)]
  c(BFK = BFK, Dai = Dai, DKW = DKW, OW = OW)
}

# ---------------------------------------------------------------------
# Purpose: m break dates from each benchmark, estimated on the full
#   sample by sequential splitting with a minimum regime length min_len.
#   OW: the dates of the largest group (as in the application).
# Used by: breakint_replication(), run_application() (04).
# Feeds: Tables mc_breakint, app_compare.
# ---------------------------------------------------------------------
benchmark_m_dates <- function(panel, m, min_len) {
  dfac <- defactor_ccex(panel)
  first <- panel$first; last <- panel$T
  bfk <- function(a, b, cands) bfk_profile(panel, a, b, cands)
  dai <- function(a, b, cands) dai_profile(dfac, a, b, cands)
  dkw <- function(a, b, cands) dkw_profile(dfac, a, b, cands)
  out <- list()
  out$BFK <- sequential_breaks(bfk, first, last, m, min_len)
  out$Dai <- sequential_breaks(dai, first, last, m, min_len)
  out$DKW <- sequential_breaks(dkw, first, last, m, min_len)
  ow <- ow_fit(dfac, G = 3, m = m, min_len = min_len, T_first = first)
  big <- ow$breaks[ow$breaks$size == max(ow$breaks$size), ]
  out$OW <- sort(big$k)
  out
}

# ---------------------------------------------------------------------
# Purpose: the date of the declared common break with the largest
#   concentration (NA if none is declared).
# Used by: one_replication(), dynamic_replication().
# Feeds: Tables mc_dates, mc_dynamic.
# ---------------------------------------------------------------------
main_date <- function(res) {
  if (nrow(res$breaks) == 0) return(NA)
  res$breaks$k_hat[which.max(res$breaks$C)]
}

# ---------------------------------------------------------------------
# Purpose: one replication of a date-accuracy design (static DGP).
#   Returns the date of every method, and the number of common breaks
#   declared by the proposed diagnosis rule.
# Used by: run_mc().
# Feeds: Tables mc_dates, mc_diagnosis.
# ---------------------------------------------------------------------
one_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T, settings$k0, job$sign, settings$d,
                        settings$share, job$indiv, job$d_ind, FALSE, job$seed)
  panel <- sim_panel_object(sim)
  res <- common_breaks(panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  bench <- c(BFK = NA, Dai = NA, DKW = NA, OW = NA)
  if (job$sign != "none") bench <- run_benchmarks(panel, settings$trim)
  data.frame(design = job$design, N = job$N, rep = job$rep, Proposed = main_date(res),
             BFK = bench["BFK"], Dai = bench["Dai"], DKW = bench["DKW"], OW = bench["OW"],
             declared = nrow(res$breaks))
}

# ---------------------------------------------------------------------
# Purpose: one replication of the small-break design used to check the
#   95% date interval implied by the argmax limit.
# Used by: run_mc().
# Feeds: Table mc_ci.
# ---------------------------------------------------------------------
interval_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T_ci, settings$k0_ci, "same", job$d,
                        settings$share, "none", 0, FALSE, job$seed)
  panel <- sim_panel_object(sim)
  C <- concentration_scan(panel, settings$h_ci, settings$ell_ci)
  k_tilde <- which.max(C)
  r <- refine_break(panel, k_tilde, settings$h_ci)
  data.frame(design = job$design, N = job$N, rep = job$rep, d = job$d,
             k_hat = r$k_hat, lower = r$lower, upper = r$upper,
             cover = r$lower <= settings$k0_ci && settings$k0_ci <= r$upper,
             length = r$upper - r$lower + 1)
}

# ---------------------------------------------------------------------
# Purpose: one replication of the dynamic date-accuracy design. Compares
#   the static and dynamic (lag-augmented) versions of the proposed
#   estimator with the four benchmarks estimated on the dynamic
#   specification.
# Used by: run_mc().
# Feeds: Table mc_dynamic.
# ---------------------------------------------------------------------
dynamic_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T, settings$k0, job$sign, settings$d,
                        settings$share, job$indiv, job$d_ind, TRUE, job$seed)
  static_panel <- sim_panel_object(sim, dynamic = FALSE)
  dyn_panel <- sim_panel_object(sim, dynamic = TRUE, q = 2)
  r_static <- common_breaks(static_panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  r_dyn <- common_breaks(dyn_panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  bench <- run_benchmarks(dyn_panel, settings$trim)
  data.frame(design = job$design, N = job$N, rep = job$rep,
             Static = main_date(r_static), Dynamic = main_date(r_dyn),
             BFK = bench["BFK"], Dai = bench["Dai"], DKW = bench["DKW"], OW = bench["OW"],
             declared_static = nrow(r_static$breaks), declared_dynamic = nrow(r_dyn$breaks))
}

# ---------------------------------------------------------------------
# Purpose: one replication of a break-interval design. The panel has a
#   common break at k0_bi, one dispersed individual break per unit and,
#   when int_share > 0, a break interval: a share of the units change
#   their slopes once at dates spread uniformly over int_dates. With
#   AR(1) errors (rho > 0) all jumps are multiplied by
#   {(1 + rho)/(1 - rho)}^(1/2), so that long-run signal-to-noise
#   energies equal those of the design with independent errors. The
#   proposed three-way procedure is compared with the four benchmarks,
#   each estimating two breaks.
# Used by: run_mc().
# Feeds: Tables mc_breakint, mc_intloc.
# ---------------------------------------------------------------------
breakint_replication <- function(job, settings) {
  scale <- sqrt((1 + job$rho) / (1 - job$rho))
  sim <- simulate_panel(job$N, settings$T, settings$k0_bi, "same", settings$d * scale,
                        settings$share, "dispersed", settings$d_bg * scale, job$dynamic,
                        job$seed, int_dates = settings$int_dates, int_share = job$int_share,
                        int_jump = settings$d * scale, rho_e = job$rho)
  panel <- sim_panel_object(sim, dynamic = job$dynamic, q = 2)
  res <- breaks_and_intervals(panel, settings$h, settings$ell, settings$kappa,
                              settings$Dmax, settings$alpha, with_ci = FALSE)
  k0 <- settings$k0_bi; lo <- min(settings$int_dates); hi <- max(settings$int_dates)
  k_hat <- res$breaks$k_hat
  iv <- res$intervals
  # the interval that overlaps the true interval with the largest G
  hit <- NA
  if (nrow(iv) > 0) {
    overlap <- which(iv$t2 >= lo & iv$t1 <= hi)
    if (length(overlap) > 0) hit <- overlap[which.max(iv$G[overlap])]
  }
  other <- 0
  if (nrow(iv) > 0) {
    for (q in 1:nrow(iv)) {
      near_interval <- iv$t2[q] >= lo - settings$ell && iv$t1[q] <= hi + settings$ell
      near_common <- iv$t1[q] <= k0 + 2 && iv$t2[q] >= k0 - 2
      if (!near_interval && !near_common) other <- other + 1
    }
  }
  bench <- benchmark_m_dates(panel, 2, settings$trim)
  row <- data.frame(design = job$design, N = job$N, rep = job$rep,
                    common = any(k_hat == k0), as_common = any(k_hat >= lo & k_hat <= hi),
                  declared = length(k_hat),
                    found = !is.na(hit), t1 = NA, t2 = NA, tstar = NA, G = NA, other = other)
  if (!is.na(hit)) {
    row$t1 <- iv$t1[hit]; row$t2 <- iv$t2[hit]; row$tstar <- iv$tstar[hit]; row$G <- iv$G[hit]
  }
  for (m in c("BFK", "Dai", "DKW", "OW")) {
    row[[paste0(m, "_common")]] <- any(bench[[m]] == k0)
    row[[paste0(m, "_inside")]] <- any(bench[[m]] >= lo & bench[[m]] <= hi)
  }
  row
}

# ---------------------------------------------------------------------
# Purpose: apply one replication function to a list of jobs, in
#   parallel where possible, and stack the rows. Seeds are fixed per
#   job, so the results do not depend on the number of cores.
# Used by: run_mc().
# Feeds: all Monte Carlo tables.
# ---------------------------------------------------------------------
run_jobs <- function(jobs, fun, settings, cores) {
  if (cores > 1 && .Platform$OS.type != "windows") {
    res <- parallel::mclapply(jobs, fun, settings = settings, mc.cores = cores,
                              mc.set.seed = FALSE)
  } else {
    res <- lapply(jobs, fun, settings = settings)
  }
  out <- res[[1]]
  for (j in seq_along(res)[-1]) out <- rbind(out, res[[j]])
  rownames(out) <- NULL
  out
}

# ---------------------------------------------------------------------
# Purpose: run every Monte Carlo design and return the results.
# Used by: run_all.R.
# Feeds: Tables mc_dates, mc_diagnosis, mc_ci, mc_dynamic,
#        mc_breakint, mc_intloc.
# ---------------------------------------------------------------------
run_mc <- function(settings, cores = 1) {
  # date-accuracy and diagnosis designs
  design <- c("same_none", "mixed_none", "same_dispersed", "mixed_dispersed",
              "same_cluster", "mixed_cluster", "null_dispersed")
  sign <- c("same", "mixed", "same", "mixed", "same", "mixed", "none")
  indiv <- c("none", "none", "dispersed", "dispersed", "cluster", "cluster", "dispersed")
  d_ind <- settings$d * c(1, 1, 1, 1, 1.5, 1.5, 1)
  jobs <- list()
  for (j in 1:7) for (N in settings$N_grid) for (r in 1:settings$R) {
    jobs[[length(jobs) + 1]] <- list(design = design[j], sign = sign[j], indiv = indiv[j],
                                     d_ind = d_ind[j], N = N, rep = r,
                                     seed = 1000000 * j + 1000 * N + r)
  }
  message("Monte Carlo: ", length(jobs), " date-accuracy panels")
  dates <- run_jobs(jobs, one_replication, settings, cores)
  # 95% date interval design
  jobs <- list()
  for (d in settings$d_ci) for (N in settings$N_ci) for (r in 1:settings$R) {
    jobs[[length(jobs) + 1]] <- list(design = "interval", N = N, rep = r, d = d,
                                     seed = 8000000 + round(1000 * d) * 1000 + N * 7 + r)
  }
  message("Monte Carlo: ", length(jobs), " date-interval panels")
  intervals <- run_jobs(jobs, interval_replication, settings, cores)
  # dynamic date-accuracy design
  jobs <- list()
  for (sg in c("same", "mixed")) for (N in settings$N_dyn) for (r in 1:settings$R) {
    jobs[[length(jobs) + 1]] <- list(design = paste0(sg, "_dispersed"), sign = sg,
                                     indiv = "dispersed", d_ind = settings$d, N = N, rep = r,
                                     seed = 9000000 + (sg == "mixed") * 100000 + N * 100 + r)
  }
  message("Monte Carlo: ", length(jobs), " dynamic panels")
  dynamic <- run_jobs(jobs, dynamic_replication, settings, cores)
  # break-interval designs
  bi <- data.frame(design = c("static_iid_int", "static_ar_int", "static_iid_none",
                              "static_ar_none", "dynamic_int", "dynamic_none", "static_ar8_none"),
                   rho = c(0, 0.5, 0, 0.5, 0, 0, 0.8),
                   int_share = settings$int_share * c(1, 1, 0, 0, 1, 0, 0),
                   dynamic = c(FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE))
  jobs <- list()
  for (j in 1:nrow(bi)) {
    N_list <- if (bi$dynamic[j]) settings$N_dyn else settings$N_bi
    for (N in N_list) for (r in 1:settings$R) {
      jobs[[length(jobs) + 1]] <- list(design = bi$design[j], rho = bi$rho[j],
                                       int_share = bi$int_share[j], dynamic = bi$dynamic[j],
                                       N = N, rep = r, seed = 10000000 + 100000 * j + 1000 * N + r)
    }
  }
  message("Monte Carlo: ", length(jobs), " break-interval panels")
  breakint <- run_jobs(jobs, breakint_replication, settings, cores)
  list(dates = dates, intervals = intervals, dynamic = dynamic, breakint = breakint)
}
