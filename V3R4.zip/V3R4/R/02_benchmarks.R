# =====================================================================
# 02_benchmarks.R
# Existing common-break estimators used for comparison. Each profile
# function returns the objective at every candidate date k of one
# segment (a, b]; sequential_breaks() turns a profile into m dates.
#   BFK : Baltagi, Feng and Kao (2016). Unit-specific slopes, CCE with
#         averages of y and x whose loadings differ across regimes.
#   Dai : Dai, Wang and Zheng (2026) without the spatial lag. CCEX
#         (averages of x only) removed on the full sample, then
#         unit-specific slopes.
#   DKW : Ditzen, Karavias and Westerlund (2025). CCEX removed on the
#         full sample, then pooled (common) slopes.
#   OW  : Okui and Wang (2021) type grouped breaks. Units are grouped by
#         k-means iterations and each group has its own break dates.
#         Break dates inside a group are found by least squares instead
#         of the adaptive group fused lasso.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: residual sum of squares of an OLS regression (0 rows -> 0).
# Used by: bfk_profile(), step_ssr().
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
ols_ssr <- function(y, X) {
  if (length(y) == 0) return(0)
  sum(.lm.fit(X, y)$residuals^2)
}

# ---------------------------------------------------------------------
# Purpose: SSR with a slope step H; when the step is empty (candidate at
#   the segment end) the regression without step is used.
# Used by: dai_profile(), dkw_profile().
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
step_ssr <- function(y, X, H) {
  if (all(H == 0)) return(ols_ssr(y, X))
  ols_ssr(y, cbind(X, H))
}

# ---------------------------------------------------------------------
# Purpose: CCEX defactoring on the full sample. Every unit's y and x are
#   residualised on (1, stable regressors, CSA proxies).
# Used by: run_benchmarks() and benchmark_m_dates() (03), which pass the
#          result to dai_profile(), dkw_profile() and ow_fit().
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
defactor_ccex <- function(panel) {
  N <- panel$N; TT <- panel$T; rows <- panel$first:TT
  ys <- matrix(NA, N, TT)
  xs <- list(); for (j in 1:panel$p) xs[[j]] <- matrix(NA, N, TT)
  for (i in 1:N) {
    B <- cbind(1, panel$csa[rows, , drop = FALSE])
    if (length(panel$stable) > 0) {
      for (j in seq_along(panel$stable)) B <- cbind(B, panel$stable[[j]][i, rows])
    }
    qb <- qr(B, tol = 1e-9)
    ys[i, rows] <- qr.resid(qb, panel$y[i, rows])
    for (j in 1:panel$p) xs[[j]][i, rows] <- qr.resid(qb, panel$x[[j]][i, rows])
  }
  list(y = ys, x = xs)
}

# ---------------------------------------------------------------------
# Purpose: BFK profile. For candidate k, each unit is fitted separately
#   on (a, k] and (k, b] with regressors (1, x, stable, ybar, CSA), so
#   the CCE loadings are regime specific; the profile sums unit SSRs.
# Used by: run_benchmarks() and, through sequential_breaks(), benchmark_m_dates() (03).
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
bfk_profile <- function(panel, a, b, cands) {
  ybar <- colMeans(panel$y)
  S <- rep(0, length(cands))
  for (i in 1:panel$N) {
    Z <- matrix(1, panel$T, 1)
    for (j in 1:panel$p) Z <- cbind(Z, panel$x[[j]][i, ])
    if (length(panel$stable) > 0) {
      for (j in seq_along(panel$stable)) Z <- cbind(Z, panel$stable[[j]][i, ])
    }
    Z <- cbind(Z, ybar, panel$csa)
    for (j in seq_along(cands)) {
      k <- cands[j]
      left <- seq_len(k - a) + a                  # (a, k]
      right <- seq_len(b - k) + k                 # (k, b]
      S[j] <- S[j] + ols_ssr(panel$y[i, left], Z[left, , drop = FALSE]) +
        ols_ssr(panel$y[i, right], Z[right, , drop = FALSE])
    }
  }
  S
}

# ---------------------------------------------------------------------
# Purpose: Dai (non-spatial) profile. On CCEX-defactored data each unit
#   has its own slopes before and after k inside the segment (a, b].
# Used by: run_benchmarks() and, through sequential_breaks(), benchmark_m_dates() (03).
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
dai_profile <- function(dfac, a, b, cands) {
  rows <- (a + 1):b
  N <- nrow(dfac$y); p <- length(dfac$x)
  S <- rep(0, length(cands))
  for (i in 1:N) {
    X <- matrix(0, length(rows), p)
    for (j in 1:p) X[, j] <- dfac$x[[j]][i, rows]
    for (jj in seq_along(cands)) {
      H <- X * as.numeric(rows > cands[jj])
      S[jj] <- S[jj] + step_ssr(dfac$y[i, rows], X, H)
    }
  }
  S
}

# ---------------------------------------------------------------------
# Purpose: DKW profile. On CCEX-defactored data all units share the
#   slopes before and after k (pooled OLS on the stacked segment).
# Used by: run_benchmarks() and, through sequential_breaks(), benchmark_m_dates() (03).
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
dkw_profile <- function(dfac, a, b, cands) {
  rows <- (a + 1):b
  N <- nrow(dfac$y); p <- length(dfac$x)
  yv <- as.vector(t(dfac$y[, rows]))                   # stacked unit by unit
  X <- matrix(0, length(yv), p)
  for (j in 1:p) X[, j] <- as.vector(t(dfac$x[[j]][, rows]))
  after <- rep(rows, N)
  S <- rep(0, length(cands))
  for (jj in seq_along(cands)) {
    H <- X * as.numeric(after > cands[jj])
    S[jj] <- step_ssr(yv, X, H)
  }
  S
}

# ---------------------------------------------------------------------
# Purpose: m break dates from a profile by sequential splitting (Bai,
#   1997): add the break that most reduces the total objective, then
#   re-estimate each break between its neighbours (repartition).
# Used by: ow_fit(), run_benchmarks() and benchmark_m_dates() (03).
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
sequential_breaks <- function(profile_fun, T_first, T_last, m, min_len) {
  breaks <- c()
  best_split <- function(a, b) {
    cands <- (a + min_len):(b - min_len)
    if (length(cands) < 1 || cands[1] > cands[length(cands)]) return(NULL)
    S <- profile_fun(a, b, cands)
    S0 <- profile_fun(a, b, b)                    # no break in (a, b]
    list(k = cands[which.min(S)], gain = S0 - min(S))
  }
  for (step in seq_len(m)) {
    edges <- c(T_first - 1, sort(breaks), T_last)
    best <- NULL
    for (s in 1:(length(edges) - 1)) {
      r <- best_split(edges[s], edges[s + 1])
      if (!is.null(r) && (is.null(best) || r$gain > best$gain)) best <- r
    }
    if (is.null(best)) break
    breaks <- sort(c(breaks, best$k))
  }
  if (length(breaks) > 1) {                       # repartition step
    for (j in seq_along(breaks)) {
      lo <- if (j == 1) T_first - 1 else breaks[j - 1]
      hi <- if (j == length(breaks)) T_last else breaks[j + 1]
      r <- best_split(lo, hi)
      if (!is.null(r)) breaks[j] <- r$k
    }
  }
  sort(breaks)
}

# ---------------------------------------------------------------------
# Purpose: Okui-Wang type grouped breaks on CCEX-defactored data.
#   G groups share slopes and break dates; groups are updated by
#   reassigning each unit to the group path that fits it best.
#   Returns the group break dates, group sizes and break energies.
# Used by: run_benchmarks() and benchmark_m_dates() (03).
# Feeds: Tables mc_dates, mc_dynamic, mc_breakint, app_compare.
# ---------------------------------------------------------------------
ow_fit <- function(dfac, G, m, min_len, T_first, seed = 1, iterations = 10) {
  y <- dfac$y; N <- nrow(y); TT <- ncol(y); p <- length(dfac$x)
  rows <- T_first:TT
  # initial groups: k-means on unit slopes estimated in blocks of 12 periods
  blocks <- split(rows, ceiling(seq_along(rows) / 12))
  feat <- matrix(0, N, length(blocks) * p)
  for (i in 1:N) {
    for (s in seq_along(blocks)) {
      r <- blocks[[s]]
      X <- matrix(0, length(r), p)
      for (j in 1:p) X[, j] <- dfac$x[[j]][i, r]
      feat[i, (s - 1) * p + 1:p] <- .lm.fit(X, y[i, r])$coefficients
    }
  }
  set.seed(seed)
  group <- kmeans(scale(feat), G, nstart = 5)$cluster
  paths <- NULL
  for (it in 1:iterations) {
    fitted_paths <- list(); group_breaks <- list()
    for (g in 1:G) {
      members <- which(group == g)
      if (length(members) == 0) { fitted_paths[[g]] <- NULL; next }
      sub <- list(y = y[members, , drop = FALSE],
                  x = lapply(dfac$x, function(z) z[members, , drop = FALSE]))
      prof <- function(a, b, cands) dkw_profile(sub, a, b, cands)
      br <- sequential_breaks(prof, T_first, TT, m, min_len)
      group_breaks[[g]] <- br
      # group coefficient path: pooled slopes regime by regime
      path <- matrix(0, TT, p)
      edges <- c(T_first - 1, br, TT)
      for (s in 1:(length(edges) - 1)) {
        r <- (edges[s] + 1):edges[s + 1]
        yv <- as.vector(t(sub$y[, r])); X <- matrix(0, length(yv), p)
        for (j in 1:p) X[, j] <- as.vector(t(sub$x[[j]][, r]))
        path[r, ] <- matrix(.lm.fit(X, yv)$coefficients, length(r), p, byrow = TRUE)
      }
      fitted_paths[[g]] <- path
    }
    # reassign each unit to the best-fitting group path
    new_group <- group
    for (i in 1:N) {
      best <- Inf
      for (g in 1:G) {
        if (is.null(fitted_paths[[g]])) next
        fit <- rep(0, length(rows))
        for (j in 1:p) fit <- fit + dfac$x[[j]][i, rows] * fitted_paths[[g]][rows, j]
        ssr <- sum((y[i, rows] - fit)^2)
        if (ssr < best) { best <- ssr; new_group[i] <- g }
      }
    }
    if (all(new_group == group)) break
    group <- new_group
  }
  # summary of each group's breaks: size and break energy n_g * |jump|^2
  out <- data.frame()
  for (g in 1:G) {
    if (is.null(fitted_paths[[g]])) next
    for (k in group_breaks[[g]]) {
      jump <- fitted_paths[[g]][k + 1, ] - fitted_paths[[g]][k, ]
      out <- rbind(out, data.frame(group = g, size = sum(group == g), k = k,
                                   energy = sum(group == g) * sum(jump^2)))
    }
  }
  list(breaks = out, group = group)
}
