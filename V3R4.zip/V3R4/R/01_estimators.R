# =====================================================================
# 01_estimators.R
# The proposed three-step procedure:
#   Step 1 (global screening): the concentration scan C(k) over all dates.
#   Step 2 (local refinement): the pooled least-squares date inside a
#           window of half-width h around each screened candidate, the
#           diagnosis rule, and the confidence interval (common breaks).
#   Step 3 (break intervals): the compressed concentration G(a, b) of
#           every short interval and the selection of break intervals.
# All functions work on a "panel" list built by make_panel_data():
#   y      N x T matrix of the dependent variable
#   x      list of p N x T matrices whose slopes may break
#   stable list of N x T matrices with stable unit-specific slopes
#          (empty in the static model, the lagged dependent variable
#          in the dynamic model)
#   csa    T x q matrix of cross-sectional averages (CCEX proxies)
#   first  first period that can be used (after lags)
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: collect everything a unit-by-unit window regression needs.
# Used by: 03_simulation.R (simulated panels) and 04_application.R
#          (housing panel).
# Feeds: all tables and Figure app_scan (all estimators start from this list).
# ---------------------------------------------------------------------
make_panel_data <- function(y, x, csa, stable = list(), first = 1) {
  list(y = y, x = x, csa = as.matrix(csa), stable = stable,
       first = first, N = nrow(y), T = ncol(y), p = length(x))
}

# ---------------------------------------------------------------------
# Purpose: regressor matrices of unit i on the rows of one window.
#   B = stable part (intercept, x, stable regressors, CSA proxies),
#   X = the p regressors whose slopes are allowed to break.
# Used by: local_profile(), unit_jump().
# Feeds: all tables and Figure app_scan.
# ---------------------------------------------------------------------
window_design <- function(panel, i, rows) {
  X <- matrix(0, length(rows), panel$p)
  for (j in 1:panel$p) X[, j] <- panel$x[[j]][i, rows]
  B <- cbind(1, X)
  if (length(panel$stable) > 0) {
    for (j in seq_along(panel$stable)) B <- cbind(B, panel$stable[[j]][i, rows])
  }
  B <- cbind(B, panel$csa[rows, , drop = FALSE])
  list(B = B, X = X)
}

# ---------------------------------------------------------------------
# Purpose: Bartlett long-run variance of a series, with the Newey-West
#   lag rule floor(4 (n/100)^(2/9)).
# Used by: break_scale().
# Feeds: Tables mc_ci, app_breaks.
# ---------------------------------------------------------------------
long_run_variance <- function(u) {
  n <- length(u)
  L <- floor(4 * (n / 100)^(2 / 9))
  lrv <- mean(u^2)
  if (L > 0) for (l in 1:L) lrv <- lrv + 2 * (1 - l / (L + 1)) * mean(u[-(1:l)] * u[1:(n - l)])
  lrv
}

# ---------------------------------------------------------------------
# Purpose: Bartlett long-run covariance matrix of the rows of S (n x p),
#   same lag rule as long_run_variance().
# Used by: unit_jump().
# Feeds: Tables mc_ci, app_breaks, app_country.
# ---------------------------------------------------------------------
long_run_cov <- function(S) {
  S <- as.matrix(S); n <- nrow(S)
  L <- floor(4 * (n / 100)^(2 / 9))
  V <- crossprod(S) / n
  if (L > 0) for (l in 1:L) {
    G <- crossprod(S[-(1:l), , drop = FALSE], S[1:(n - l), , drop = FALSE]) / n
    V <- V + (1 - l / (L + 1)) * (G + t(G))
  }
  V
}

# ---------------------------------------------------------------------
# Purpose: residual sums of squares of one unit's window regression with
#   a slope step after each candidate date (Frisch-Waugh form: y and the
#   step regressors are first residualised on the stable part B).
#   Also returns, for the fit with the step at `center`, the residual
#   variance (unit weight 1 / sigma2) and the first-order residual
#   autocorrelation (used to express C(k) in long-run units).
# Used by: local_profile().
# Feeds: same tables and figure as local_profile().
# ---------------------------------------------------------------------
unit_ssr <- function(y, B, X, rows, cands, center) {
  qb <- qr(B, tol = 1e-9)
  y_res <- qr.resid(qb, y)
  df <- length(rows) - qb$rank - ncol(X)
  ssr <- rep(NA, length(cands)); sigma2 <- NA; rho <- NA
  for (j in seq_along(cands)) {
    H <- X * as.numeric(rows > cands[j])       # step regressors x * 1{t > k}
    H_res <- qr.resid(qb, H)
    G <- crossprod(H_res)
    if (rcond(G) < 1e-8) next                    # step not identified
    g <- crossprod(H_res, y_res)
    b <- solve(G, g)
    ssr[j] <- sum(y_res^2) - sum(g * b)
    if (cands[j] == center) {
      u <- as.vector(y_res - H_res %*% b)
      sigma2 <- sum(u^2) / df
      rho <- sum(u[-1] * u[-length(u)]) / sum(u^2)
    }
  }
  list(ssr = ssr, sigma2 = sigma2, rho = rho)
}

# ---------------------------------------------------------------------
# Purpose: pooled local profile S(k) = sum_i pi_i SSR_i(k) on the window
#   (center - h, center + h], with weights pi_i = 1 / sigma_i^2 taken
#   from the fit with the step at the window centre. lr_factor =
#   (1 - rho)/(1 + rho), rho = median residual autocorrelation (floored
#   at zero), converts short-run into long-run signal-to-noise units.
# Used by: concentration_scan(), refine_break(), compressed_concentration(),
#          interval_participation() (04).
# Feeds: all tables and Figure app_scan.
# ---------------------------------------------------------------------
local_profile <- function(panel, center, h, cands) {
  rows <- (center - h + 1):(center + h)
  ssr <- matrix(NA, panel$N, length(cands))
  w <- rep(NA, panel$N); rho <- rep(NA, panel$N)
  for (i in 1:panel$N) {
    d <- window_design(panel, i, rows)
    fit <- unit_ssr(panel$y[i, rows], d$B, d$X, rows, cands, center)
    if (any(is.na(fit$ssr)) || is.na(fit$sigma2) || fit$sigma2 <= 0) next   # unidentified unit
    ssr[i, ] <- fit$ssr
    w[i] <- 1 / fit$sigma2
    rho[i] <- fit$rho
  }
  ok <- !is.na(w)
  rho_bar <- max(0, median(rho[ok]))
  list(S = colSums(ssr[ok, , drop = FALSE] * w[ok]), cands = cands,
       weights = w, used = sum(ok), lr_factor = (1 - rho_bar) / (1 + rho_bar))
}

# ---------------------------------------------------------------------
# Purpose: Step 1, the global concentration scan
#   C(k) = lr_factor * [S(k - l) + S(k + l) - 2 S(k)] / (2 l N),
#   computed on a window of half-width h centred at every date k.
#   C(k) is the average long-run signal-to-noise break energy located at
#   date k: of order one at a common break, negligible when only
#   dispersed individual breaks are present.
# Used by: common_breaks(), interval_replication() (03).
# Feeds: all tables and Figure app_scan.
# ---------------------------------------------------------------------
concentration_scan <- function(panel, h, ell) {
  C <- rep(NA, panel$T)
  first_k <- panel$first + h - 1
  for (k in first_k:(panel$T - h)) {
    prof <- local_profile(panel, k, h, c(k - ell, k, k + ell))
    C[k] <- prof$lr_factor * (prof$S[1] + prof$S[3] - 2 * prof$S[2]) / (2 * ell * prof$used)
  }
  C
}

# ---------------------------------------------------------------------
# Purpose: greedy local maxima of a scan, at least `sep` periods apart.
# Used by: common_breaks().
# Feeds: Tables mc_dates, mc_diagnosis, mc_dynamic, mc_breakint, mc_intloc,
#        app_breaks, app_intervals, app_compare, app_country, app_sensitivity;
#        Figure app_scan.
# ---------------------------------------------------------------------
find_peaks <- function(stat, sep) {
  peaks <- c()
  for (k in order(stat, decreasing = TRUE)) {
    if (is.na(stat[k])) next
    if (length(peaks) == 0 || min(abs(k - peaks)) >= sep) peaks <- c(peaks, k)
  }
  peaks
}

# ---------------------------------------------------------------------
# Purpose: estimated jump, its HAC covariance, residuals and raw
#   regressor moment of unit i when the step is placed after date k.
# Used by: break_scale(), interval_participation() (04).
# Feeds: Tables mc_ci, app_breaks, app_country.
# ---------------------------------------------------------------------
unit_jump <- function(panel, i, rows, k) {
  d <- window_design(panel, i, rows)
  qb <- qr(d$B, tol = 1e-9)
  y_res <- qr.resid(qb, panel$y[i, rows])
  H_res <- qr.resid(qb, d$X * as.numeric(rows > k))
  G <- crossprod(H_res)
  if (rcond(G) < 1e-8) return(NULL)
  b <- solve(G, crossprod(H_res, y_res))
  u <- as.vector(y_res - H_res %*% b)
  n <- length(rows); df <- n - qb$rank - ncol(d$X)
  Gi <- solve(G)
  V <- Gi %*% (n * long_run_cov(H_res * u)) %*% Gi * n / df   # HAC covariance
  list(b = as.vector(b), V = V, u = u, X = d$X, Q = crossprod(d$X) / n)
}

# ---------------------------------------------------------------------
# Purpose: debiased break energy lambda, long-run variance omega of the
#   aggregated score
#   xi_t = sum_i pi_i (Delta_i' x_it) u_it, and the argmax scale
#   L = lambda^2 / omega at date k, using
#   the refinement window centred at `center`.
#   The scale of the date limit is (lambda^2/omega)(k_hat - k0).
# Used by: refine_break().
# Feeds: Tables mc_ci, app_breaks, app_country.
# ---------------------------------------------------------------------
break_scale <- function(panel, k, h, weights, center = k) {
  rows <- (center - h + 1):(center + h); n <- length(rows)
  lam <- 0; bias <- 0; xi <- rep(0, n)
  jumps <- vector("list", panel$N)
  for (i in 1:panel$N) {
    if (is.na(weights[i])) next
    f <- unit_jump(panel, i, rows, k)
    if (is.null(f)) next
    jumps[[i]] <- f
    lam  <- lam + weights[i] * sum(f$b * (f$Q %*% f$b))
    bias <- bias + weights[i] * sum(diag(f$Q %*% f$V))
    xi   <- xi + weights[i] * as.vector(f$X %*% f$b) * f$u   # aggregated score
  }
  om <- long_run_variance(xi)            # long-run variance of the aggregated score
  # the drift lambda is debiased for the estimation noise in the jumps;
  # omega is not, because that noise is part of the finite-window profile
  lam_d <- max(lam - bias, 1e-8)
  list(lambda = lam_d, omega = om, scale = lam_d^2 / om, jumps = jumps)
}

# ---------------------------------------------------------------------
# Purpose: distribution function of argmax_v {W(v) - |v|/2} for x > 0
#   (Bai, 1997), and its two-sided quantile used for date intervals.
# Used by: refine_break(), 05_output.R (note of Table mc_ci).
# Feeds: Tables mc_ci, app_breaks.
# ---------------------------------------------------------------------
argmax_cdf <- function(x) {
  1 + sqrt(x / (2 * pi)) * exp(-x / 8) - 0.5 * (x + 5) * pnorm(-sqrt(x) / 2) +
    1.5 * exp(x) * pnorm(-1.5 * sqrt(x))
}
argmax_quantile <- function(level = 0.95) {
  uniroot(function(x) argmax_cdf(x) - (1 + level) / 2, c(0.01, 200))$root
}

# ---------------------------------------------------------------------
# Purpose: Step 2, local refinement around a screened candidate:
#   the pooled least-squares date inside the window, and a 95% interval
#   k_hat +/- floor(q / L_hat) based on the argmax limit.
# Used by: common_breaks(), interval_replication() (03).
# Feeds: Tables mc_ci, app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
refine_break <- function(panel, k_tilde, h) {
  half <- floor(h / 2)
  cands <- (k_tilde - half):(k_tilde + half)
  prof <- local_profile(panel, k_tilde, h, cands)
  k_hat <- cands[which.min(prof$S)]
  sc <- break_scale(panel, k_hat, h, prof$weights, center = k_tilde)
  half_width <- floor(argmax_quantile(0.95) / sc$scale)   # |k_hat - k0| is an integer
  list(k_hat = k_hat, lambda = sc$lambda / prof$used, scale = sc$scale,
       lower = k_hat - half_width, upper = k_hat + half_width,
       profile = prof$S - min(prof$S), cands = cands, jumps = sc$jumps,
       weights = prof$weights, lr_factor = prof$lr_factor)
}

# ---------------------------------------------------------------------
# Purpose: the complete procedure. Screen with C(k), refine each peak,
#   and declare a common break when the concentration at the refined
#   date exceeds kappa, the declared minimum break energy per unit
#   (in long-run signal-to-noise units).
# Used by: breaks_and_intervals(), 03_simulation.R.
# Feeds: Tables mc_dates, mc_diagnosis, mc_dynamic, mc_breakint, mc_intloc,
#        app_breaks, app_intervals, app_compare, app_country, app_sensitivity;
#        Figure app_scan.
# ---------------------------------------------------------------------
common_breaks <- function(panel, h, ell, kappa, max_peaks = 8, with_ci = TRUE) {
  C <- concentration_scan(panel, h, ell)
  peaks <- find_peaks(C, h)
  peaks <- peaks[seq_len(min(max_peaks, length(peaks)))]
  out <- data.frame()
  refined <- list()
  for (k in peaks) {
    if (C[k] <= kappa / 2) next                 # clearly below the threshold
    if (with_ci) {
      r <- refine_break(panel, k, h)
    } else {
      half <- floor(h / 2)
      prof <- local_profile(panel, k, h, (k - half):(k + half))
      r <- list(k_hat = prof$cands[which.min(prof$S)], lambda = NA, scale = NA,
                lower = NA, upper = NA)
    }
    if (is.na(C[r$k_hat]) || C[r$k_hat] <= kappa) next      # diagnosis rule
    if (nrow(out) > 0 && min(abs(out$k_hat - r$k_hat)) < ell) next
    out <- rbind(out, data.frame(k_screen = k, k_hat = r$k_hat, C = C[r$k_hat],
                                 lambda = r$lambda, scale = r$scale,
                                 lower = r$lower, upper = r$upper))
    refined[[length(refined) + 1]] <- r
  }
  if (nrow(out) > 0) {
    o <- order(out$k_hat); out <- out[o, ]; refined <- refined[o]
  }
  list(breaks = out, scan = C, refined = refined)
}

# =====================================================================
# Step 3: break intervals. A break interval is a short period over which
# many units change their slopes at different dates. Deleting the
# periods of the interval and joining the h periods before it to the h
# periods after it turns the interval into one common break at the
# joining point, so the concentration scan above can be applied there.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: can the interval [a, b] be compressed? Both blocks must lie
#   in the sample, and every declared common break must lie at least
#   ell + h/8 periods outside [a, b]: outside the tent of the scan at
#   the ends of the interval, and at least h/8 periods beyond the outer
#   candidate steps a - ell and b + ell, so that a partialled step and
#   the candidate steps are separately identified.
# Used by: interval_bank().
# Feeds: Tables mc_breakint, mc_intloc, app_intervals, app_compare,
#        app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
interval_admissible <- function(panel, a, b, h, ell, atoms) {
  if (a - h + 1 < panel$first || b + h > panel$T) return(FALSE)
  for (k in atoms) {
    if (k > a - ell - h / 8 && k < b + ell + h / 8) return(FALSE)
  }
  TRUE
}

# ---------------------------------------------------------------------
# Purpose: the compressed panel of the interval [a, b]: the h periods up
#   to a followed by the h periods after b (rows a+1, ..., b deleted).
#   A unit whose slopes change at dates in [a, b] jumps at the joining
#   point by its net change beta_{i,b+1} - beta_{i,a}. A declared common
#   break inside one of the two blocks is partialled out by adding
#   x_it * 1{t > k} to the stable regressors.
# Used by: compressed_concentration(), interval_participation() (04).
# Feeds: Tables mc_breakint, mc_intloc, app_intervals, app_compare,
#        app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
compressed_panel <- function(panel, a, b, h, atoms = c()) {
  cols <- c((a - h + 1):a, (b + 1):(b + h))
  sub <- list(y = panel$y[, cols, drop = FALSE], x = list(),
              csa = panel$csa[cols, , drop = FALSE], stable = list(),
              first = 1, N = panel$N, T = 2 * h, p = panel$p)
  for (j in 1:panel$p) sub$x[[j]] <- panel$x[[j]][, cols, drop = FALSE]
  for (j in seq_along(panel$stable)) sub$stable[[j]] <- panel$stable[[j]][, cols, drop = FALSE]
  for (k in atoms) {
    if (k > cols[1] + 2 && k < cols[2 * h] - 2) {
      step <- matrix(as.numeric(cols > k), panel$N, 2 * h, byrow = TRUE)
      for (j in 1:panel$p) sub$stable[[length(sub$stable) + 1]] <- sub$x[[j]] * step
    }
  }
  sub
}

# ---------------------------------------------------------------------
# Purpose: compressed concentration G(a, b): the scan statistic of
#   concentration_scan() evaluated at the joining point h of the
#   compressed panel, G = lr_factor * [S(h - ell) + S(h + ell) - 2 S(h)]
#   / (2 ell N). G(k, k) equals C(k).
# Used by: interval_bank().
# Feeds: Tables mc_breakint, mc_intloc, app_intervals, app_compare,
#        app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
compressed_concentration <- function(panel, a, b, h, ell, atoms = c()) {
  sub <- compressed_panel(panel, a, b, h, atoms)
  prof <- local_profile(sub, h, h, c(h - ell, h, h + ell))
  prof$lr_factor * (prof$S[1] + prof$S[3] - 2 * prof$S[2]) / (2 * ell * prof$used)
}

# ---------------------------------------------------------------------
# Purpose: G(a, a + D) for every start a and every length D = 0, ..., Dmax
#   (column D + 1). Column 1 is the scan C itself; inadmissible pairs
#   are NA.
# Used by: breaks_and_intervals().
# Feeds: Tables mc_breakint, mc_intloc, app_intervals, app_compare,
#        app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
interval_bank <- function(panel, scan, h, ell, Dmax, atoms = c()) {
  G <- matrix(NA, panel$T, Dmax + 1)
  G[, 1] <- scan
  for (a in 1:panel$T) for (D in 1:Dmax) {
    if (interval_admissible(panel, a, a + D, h, ell, atoms)) {
      G[a, D + 1] <- compressed_concentration(panel, a, a + D, h, ell, atoms)
    }
  }
  G
}

# ---------------------------------------------------------------------
# Purpose: greedy selection of break intervals from the bank G.
#   (1) Take the pair with 1 <= b - a <= Dmax and the largest G; stop if
#       it is not above kappa.
#   (2) Shrink it to the shortest sub-interval [t1, t2], t2 - t1 >= 1,
#       whose G keeps a share 1 - alpha of the largest value and still
#       exceeds kappa.
#   (3) The compressed date t* is the date that splits the energy of
#       [t1, t2] in half: G(t1, t) closest to G(t, t2).
#   (4) Drop every pair within ell of [t1, t2] and repeat.
#   An interval whose scan exceeds kappa at some date (a concentration
#   suppressed by the separation rule of common_breaks()) is labelled
#   "peak"; otherwise "dispersed".
# Used by: breaks_and_intervals().
# Feeds: Tables mc_breakint, mc_intloc, app_intervals, app_compare,
#        app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
find_intervals <- function(G, scan, kappa, ell, alpha = 0.1, max_int = 8) {
  TT <- nrow(G); Dmax <- ncol(G) - 1
  free <- !is.na(G); free[, 1] <- FALSE        # D = 0 is left to the common breaks
  out <- data.frame()
  for (it in 1:max_int) {
    top <- -Inf; a_top <- NA; D_top <- NA
    for (a in 1:TT) for (D in 1:Dmax) {
      if (free[a, D + 1] && G[a, D + 1] > top) { top <- G[a, D + 1]; a_top <- a; D_top <- D }
    }
    if (is.na(a_top) || top <= kappa) break
    level <- max((1 - alpha) * top, kappa)
    t1 <- a_top; t2 <- a_top + D_top
    for (len in 1:D_top) {
      g_best <- -Inf
      for (s in a_top:(a_top + D_top - len)) {
        g <- G[s, len + 1]
        if (!is.na(g) && g > level && g > g_best) { g_best <- g; t1 <- s; t2 <- s + len }
      }
      if (g_best > -Inf) break
    }
    gap <- rep(Inf, t2 - t1 + 1)
    for (t in t1:t2) {
      left <- G[t1, t - t1 + 1]; right <- G[t, t2 - t + 1]
      if (!is.na(left) && !is.na(right)) gap[t - t1 + 1] <- abs(left - right)
    }
    tstar <- (t1:t2)[which.min(gap)]
    peak <- max(scan[t1:t2], na.rm = TRUE)
    out <- rbind(out, data.frame(t1 = t1, t2 = t2, tstar = tstar, G = G[t1, t2 - t1 + 1],
                                 G_max = top, peak = peak,
                                 type = ifelse(peak > kappa, "peak", "dispersed")))
    for (a in 1:TT) for (D in 0:Dmax) {
      if (a <= t2 + ell && a + D >= t1 - ell) free[a, D + 1] <- FALSE
    }
  }
  if (nrow(out) > 0) out <- out[order(out$t1), ]
  out
}

# ---------------------------------------------------------------------
# Purpose: the complete three-way procedure. Common breaks by
#   common_breaks() (unchanged), then break intervals from the bank of
#   compressed concentrations with the common breaks partialled out.
# Used by: 03_simulation.R, 04_application.R.
# Feeds: Tables mc_breakint, mc_intloc, app_breaks, app_intervals,
#        app_compare, app_country, app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
breaks_and_intervals <- function(panel, h, ell, kappa, Dmax, alpha = 0.1, with_ci = TRUE) {
  res <- common_breaks(panel, h, ell, kappa, with_ci = with_ci)
  res$bank <- interval_bank(panel, res$scan, h, ell, Dmax, res$breaks$k_hat)
  res$intervals <- find_intervals(res$bank, res$scan, kappa, ell, alpha)
  res
}

# ---------------------------------------------------------------------
# Purpose: category of every date: 1 inside the 95% confidence interval
#   of a declared common break, 2 inside a break interval, 3 otherwise
#   (NA where the scan is not defined).
# Used by: write_app_tables() (05).
# Feeds: Table app_intervals (note).
# ---------------------------------------------------------------------
classify_dates <- function(scan, breaks, intervals) {
  cls <- rep(3, length(scan)); cls[is.na(scan)] <- NA
  for (q in seq_len(nrow(intervals))) cls[intervals$t1[q]:intervals$t2[q]] <- 2
  for (j in seq_len(nrow(breaks))) {
    lo <- breaks$lower[j]; hi <- breaks$upper[j]
    if (is.na(lo)) { lo <- breaks$k_hat[j]; hi <- breaks$k_hat[j] }
    cls[lo:hi] <- 1
  }
  cls
}
