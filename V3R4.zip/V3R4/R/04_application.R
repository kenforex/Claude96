# =====================================================================
# 04_application.R
# UK local-authority house prices (349 LADs, 2004m1-2025m12), the data
# used by Pang and Chaudhuri (v9_8). Dynamic price equation: the lagged
# price is a stable regressor, the slopes on log sales and log
# employment may change, and the CCEX proxies are the averages of the
# two regressors, the lagged average price and three lags of each
# (Chudik and Pesaran, 2015).
# Dates: k is the last month of the old regime; tables report the first
# month of the new regime (k + 1), the convention of v9_8.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: read v9_8_data.csv and build N x T matrices in LAD order.
# Used by: run_application().
# Feeds: Tables app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
read_housing <- function(root) {
  d <- read.csv(file.path(root, "data", "v9_8_data.csv"), stringsAsFactors = FALSE)
  year <- as.integer(sub("m.*", "", d$mdate))
  month <- as.integer(sub(".*m", "", d$mdate))
  d$t <- (year - 2004) * 12 + month
  d <- d[order(d$fid, d$t), ]
  N <- length(unique(d$fid)); TT <- max(d$t)
  stopifnot(nrow(d) == N * TT)
  codes <- d$areacode[d$t == 1]
  group <- rep("Wales", N)
  group[substr(codes, 1, 1) == "S"] <- "Scotland"
  group[substr(codes, 1, 1) == "E"] <- "England excl. London"
  group[substr(codes, 1, 3) == "E09"] <- "London"
  list(price = matrix(d$realp, N, TT, byrow = TRUE),
       sales = matrix(d$lnsales, N, TT, byrow = TRUE),
       employ = matrix(d$lnemploy, N, TT, byrow = TRUE),
       group = group, N = N, T = TT)
}

# ---------------------------------------------------------------------
# Purpose: month label of the first month of the new regime, k + 1.
# Used by: 05_output.R.
# Feeds: Tables app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
month_label <- function(k) {
  t <- k + 1
  sprintf("%d-%02d", 2004 + (t - 1) %/% 12, (t - 1) %% 12 + 1)
}

# ---------------------------------------------------------------------
# Purpose: panel object of the dynamic price equation. Stable regressor:
#   the lagged price. Proxies: sbar_t, ebar_t, ybar_{t-1} and q further
#   lags of each (q = 3 = floor(48^(1/3))).
# Used by: run_application().
# Feeds: Tables app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
housing_panel <- function(h_data, q = 3) {
  TT <- h_data$T
  lag_vec <- function(v, L) c(rep(NA, L), v[1:(length(v) - L)])
  sbar <- colMeans(h_data$sales); ebar <- colMeans(h_data$employ)
  ybar_lag <- lag_vec(colMeans(h_data$price), 1)
  price_lag <- cbind(NA, h_data$price[, 1:(TT - 1)])
  csa <- cbind(sbar, ebar, ybar_lag)
  for (L in 1:q) csa <- cbind(csa, lag_vec(sbar, L), lag_vec(ebar, L), lag_vec(ybar_lag, L))
  make_panel_data(h_data$price, list(h_data$sales, h_data$employ), csa,
                  stable = list(price_lag), first = q + 2)
}

# ---------------------------------------------------------------------
# Purpose: share of LADs in each country group whose own jump is
#   significant at 5% (HAC Wald statistic above the chi-square critical
#   value), and their mean long-run signal-to-noise jump energy.
#   `jumps` is the list of unit jump fits from break_scale() or
#   interval_participation().
# Used by: run_application().
# Feeds: Table app_country.
# ---------------------------------------------------------------------
participation_by_group <- function(jumps, weights, lr_factor, groups, p) {
  crit <- qchisq(0.95, p)
  wald <- rep(NA, length(groups)); energy <- rep(NA, length(groups))
  for (i in seq_along(groups)) {
    f <- jumps[[i]]
    if (is.null(f) || is.na(weights[i])) next
    wald[i] <- sum(f$b * solve(f$V, f$b))
    energy[i] <- lr_factor * weights[i] * sum(f$b * (f$Q %*% f$b))
  }
  out <- data.frame()
  for (g in c("England excl. London", "London", "Scotland", "Wales")) {
    ix <- groups == g & !is.na(wald)
    out <- rbind(out, data.frame(group = g, n = sum(ix), share = mean(wald[ix] > crit),
                                 energy = mean(energy[ix])))
  }
  out
}

# ---------------------------------------------------------------------
# Purpose: unit jumps across a break interval [t1, t2]: in the compressed
#   panel (rows of the interval deleted, common breaks partialled out),
#   each LAD's net slope change is estimated with the step at the
#   joining point, with the HAC covariance of unit_jump().
# Used by: run_application().
# Feeds: Table app_country.
# ---------------------------------------------------------------------
interval_participation <- function(panel, t1, t2, h, atoms) {
  sub <- compressed_panel(panel, t1, t2, h, atoms)
  rows <- 1:(2 * h)
  prof <- local_profile(sub, h, h, h)
  jumps <- vector("list", panel$N)
  for (i in 1:panel$N) {
    if (is.na(prof$weights[i])) next
    jumps[[i]] <- unit_jump(sub, i, rows, h)
  }
  list(jumps = jumps, weights = prof$weights, lr_factor = prof$lr_factor)
}

# ---------------------------------------------------------------------
# Purpose: run the whole application: common breaks and break intervals
#   of the dynamic equation, participation by country group, window
#   sensitivity and the four benchmarks. Results stay in memory.
# Used by: run_all.R.
# Feeds: Tables app_breaks, app_intervals, app_compare, app_country,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
run_application <- function(root, h = 24, ell = 6, kappa = 0.15, Dmax = 12, alpha = 0.1) {
  h_data <- read_housing(root)
  panel <- housing_panel(h_data)
  message("Application: common breaks and break intervals, h = ", h)
  main <- breaks_and_intervals(panel, h, ell, kappa, Dmax, alpha, with_ci = TRUE)
  # participation in each common break and each break interval
  country <- data.frame()
  for (j in seq_len(nrow(main$breaks))) {
    r <- main$refined[[j]]
    cp <- participation_by_group(r$jumps, r$weights, r$lr_factor, h_data$group, panel$p)
    country <- rbind(country, data.frame(type = "break", k = main$breaks$k_hat[j], k2 = NA, cp))
  }
  for (q in seq_len(nrow(main$intervals))) {
    iv <- main$intervals[q, ]
    r <- interval_participation(panel, iv$t1, iv$t2, h, main$breaks$k_hat)
    cp <- participation_by_group(r$jumps, r$weights, r$lr_factor, h_data$group, panel$p)
    country <- rbind(country, data.frame(type = "interval", k = iv$t1, k2 = iv$t2, cp))
  }
  # other window half-widths
  sens <- list()
  for (hh in c(18, 36)) {
    message("Application: sensitivity, h = ", hh)
    sens[[as.character(hh)]] <- breaks_and_intervals(panel, hh, ell, kappa, Dmax, alpha, with_ci = FALSE)
  }
  sens[[as.character(h)]] <- main
  message("Application: benchmarks")
  bench <- benchmark_m_dates(panel, 4, 24)
  list(main = main, sensitivity = sens, country = country, bench = bench, group = h_data$group,
       settings = list(h = h, ell = ell, kappa = kappa, Dmax = Dmax, alpha = alpha),
       v98 = c(47, 79, 146, 201))                # v9_8: 2007-12, 2010-08, 2016-03, 2020-10
}
