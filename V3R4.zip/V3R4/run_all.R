# =====================================================================
# run_all.R
# Reproduces every table (Tables/*.tex) and the figure (Figures/*.pdf)
# of the paper from data/v9_8_data.csv and the seeds set in the code.
# Usage from this folder:  Rscript --vanilla run_all.R --cores=4
# Base R only (stats, graphics, grDevices, parallel).
# =====================================================================
invisible(Sys.setlocale("LC_TIME", "C"))
RNGkind("Mersenne-Twister", "Inversion", "Rejection")

# number of cores from the command line (default 1)
args <- commandArgs(trailingOnly = TRUE)
cores <- 1
for (a in args) if (substr(a, 1, 8) == "--cores=") cores <- as.integer(substr(a, 9, nchar(a)))

# folder of this script
root <- getwd()
for (a in commandArgs()) if (substr(a, 1, 7) == "--file=") root <- dirname(normalizePath(substr(a, 8, nchar(a))))

source(file.path(root, "R", "01_estimators.R"))
source(file.path(root, "R", "02_benchmarks.R"))
source(file.path(root, "R", "03_simulation.R"))
source(file.path(root, "R", "04_application.R"))
source(file.path(root, "R", "05_output.R"))
dir.create(file.path(root, "Tables"), showWarnings = FALSE)
dir.create(file.path(root, "Figures"), showWarnings = FALSE)

# Monte Carlo settings (Section 6 of the paper)
settings <- list(T = 180, k0 = 90, h = 24, ell = 6, kappa = 0.15, d = 0.5, share = 0.5,
                 trim = 27, N_grid = c(50, 100, 200), R = 100,
                 T_ci = 180, k0_ci = 90, h_ci = 24, ell_ci = 12, d_ci = c(0.2, 0.3),
                 N_ci = c(100, 200), N_dyn = 100,
                 k0_bi = 60, int_dates = 115:126, int_share = 0.4, d_bg = 0.3, Dmax = 12, alpha = 0.1,
                 N_bi = c(100, 200))

mc <- run_mc(settings, cores)
app <- run_application(root, h = 24, ell = 6, kappa = settings$kappa, Dmax = settings$Dmax,
                       alpha = settings$alpha)
write_tables(root, mc, app, settings)
write_figures(root, app)
message("Done: tables in Tables/, figure in Figures/.")
