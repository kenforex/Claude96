# V3R3 复现包

论文：*Common Breaks under Individual-Break Interference in Heterogeneous Factor Panels*（V3R3，2026 年 9 月；以 V3R2_2 为底稿）。

## 1. 包内文件

```
V3R3/
├── README.md            本说明
├── DATA_SOURCES.md      复现数据来源清单
├── data/v9_8_data.csv   唯一的输入数据（v9_8 冻结面板）
├── run_all.R            主程序：只生成 Tables/*.tex 和 Figures/*.pdf
├── R/
│   ├── 01_estimators.R  本文的两步估计量：扫描统计量、局部精估、诊断、区间
│   ├── 02_benchmarks.R  四个比较方法：BFK、Dai、DKW、OW
│   ├── 03_simulation.R  蒙特卡洛数据生成与逐次重复
│   ├── 04_application.R 英国房价实证
│   └── 05_output.R      唯一写文件的模块：写表和图
├── Tables/              8 个表，每表一个 .tex（由 run_all.R 生成）
├── Figures/app_scan.pdf 唯一的图（由 run_all.R 生成）
├── main.tex  appendix.tex  preamble.tex  references.tex
├── build.sh             由 tex、Tables、Figures 编译两份 PDF
├── main.pdf  appendix.pdf
```

## 2. 复现步骤

```sh
Rscript --vanilla run_all.R --cores=2   # 生成全部表和图
sh build.sh                              # 编译 main.pdf 和 appendix.pdf
```

- 软件：R ≥ 4.0，只用基础包（stats、graphics、grDevices、parallel），在 R 4.3.3 下测试；pdfLaTeX（TeX Live 2023 测试通过）。
- 运行时间：在 2 核云主机上 `--cores=2` 共约 2 小时 15 分钟，单核约 4.5 小时，几乎全部用于蒙特卡洛（2,700 个模拟面板）。Windows 上 `--cores` 无效，自动单核运行。
- 每次重复都有自己的固定种子，结果与核数无关。
- `run_all.R` 只写 `Tables/` 下 8 个 `.tex` 和 `Figures/app_scan.pdf`，不写任何中间文件、日志或数据。模拟结果和实证结果只保存在内存里。
- 重新运行后，8 个表与包内版本逐字节相同；图的内容相同，只有 R 的 `pdf()` 自动写入的创建时间戳不同。

## 3. 表、图与代码的对应

| 输出 | 正文位置 | 生成函数（05_output.R） | 计算来源 |
|---|---|---|---|
| `Tables/mc_dates.tex` | 表 1 | `write_tables()` | `run_mc()` → `one_replication()`（03） |
| `Tables/mc_diagnosis.tex` | 表 2 | `write_tables()` | 同上，`declared` 列 |
| `Tables/mc_interval.tex` | 表 3 | `write_tables()` | `interval_replication()`（03）→ `refine_break()`（01） |
| `Tables/mc_dynamic.tex` | 表 4 | `write_tables()` | `dynamic_replication()`（03） |
| `Tables/app_breaks.tex` | 表 5 | `write_tables()` | `run_application()`（04）→ `common_breaks()`（01） |
| `Tables/app_compare.tex` | 表 6 | `write_tables()` | `benchmark_dates()`（04）→ 02 中各方法 |
| `Tables/app_country.tex` | 表 7 | `write_tables()` | `country_participation()`（04） |
| `Tables/app_sensitivity.tex` | 表 8 | `write_tables()` | `run_application()` 中 h = 18、36 |
| `Figures/app_scan.pdf` | 图 1 | `write_figures()` | `concentration_scan()`（01） |

R 代码中每个函数前都有注释，写明三件事：作用（Purpose）、在包内被谁调用（Used by）、最终贡献于哪些表和图（Feeds）。

## 4. tex 修订标记

- V3R2_2 中删除的段落没有真正删去，而是在行首加 `%%` 隐藏，便于对照。
- 新增段落为绿色：单独段落用 `\textcolor{revisiongreen}{...}`；新增的整节、定理和公式环境放在 `\begingroup\color{revisiongreen} ... \endgroup` 中。`revisiongreen` 在 `preamble.tex` 中定义。
- 附录保留了 V3R2_2 中仍然需要的引理：投影尾界、完整单元比较、区块能量、单单元日期实验、同步引理和信息界证明。其余内容用 `%%` 隐藏。
- `main.tex` 和 `appendix.tex` 通过 `xr-hyper` 互相引用，因此 `build.sh` 交替编译五次。
