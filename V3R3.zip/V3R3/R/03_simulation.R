# =====================================================================
# 03_simulation.R
# Monte Carlo designs. Every replication draws a new panel from its own
# seed, applies the proposed estimator and the benchmarks to the same
# panel, and returns one row of results. Nothing is written to disk.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: simulate one heterogeneous panel with a CCE factor structure,
#   one common break at k0 and optional individual breaks.
#   y_it = alpha_i + phi_i y_i,t-1 + beta_it x_it + gamma_i f_t + e_it
#   x_it = a_i + Gamma_i f_t + v_it
#   beta_it = beta_i + Delta_i 1{t > k0} + theta_i 1{t > s_i}
# Used by: one_replication(), interval_replication(), dynamic_replication().
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic.
# ---------------------------------------------------------------------
simulate_panel <- function(N, TT, k0, sign = "same", d = 0.3, share = 0.5,
                           indiv = "none", d_ind = 0.3, dynamic = FALSE, seed = 1) {
  set.seed(seed)
  burn <- 50; TB <- TT + burn
  f <- rep(0, TB); for (t in 2:TB) f[t] <- 0.5 * f[t - 1] + sqrt(0.75) * rnorm(1)
  a <- runif(N); Gam <- runif(N, 0.5, 1.5); alpha <- rnorm(N); gam <- runif(N, 0.5, 1.5)
  sig <- sqrt(runif(N, 0.5, 1.5)); beta <- runif(N, 0.5, 1.5)
  phi <- if (dynamic) runif(N, 0.3, 0.7) else rep(0, N)
  v <- matrix(0, N, TB)
  for (t in 2:TB) v[, t] <- 0.5 * v[, t - 1] + sqrt(0.75) * rnorm(N)
  x <- a + outer(Gam, f) + v
  # coefficient paths (dates refer to the sample after the burn-in)
  B <- matrix(beta, N, TT)
  Delta <- rep(0, N)
  if (sign != "none") {
    part <- sample(N, floor(share * N))
    s <- if (sign == "same") rep(1, length(part)) else rep(c(1, -1), length.out = length(part))
    Delta[part] <- d * s
    B <- B + outer(Delta, as.numeric(1:TT > k0))
  }
  if (indiv == "dispersed") {                 # one break per unit, anywhere
    dates <- setdiff(ceiling(0.1 * TT):floor(0.9 * TT), k0)
    for (i in 1:N) {
      s_i <- dates[sample(length(dates), 1)]
      B[i, ] <- B[i, ] + d_ind * sample(c(-1, 1), 1) * as.numeric(1:TT > s_i)
    }
  }
  if (indiv == "cluster") {                   # 40% of the units, 25-64 periods after k0
    for (i in sample(N, floor(0.4 * N))) {
      s_i <- k0 + sample(25:64, 1)
      B[i, ] <- B[i, ] + d_ind * sample(c(-1, 1), 1) * as.numeric(1:TT > s_i)
    }
  }
  B <- cbind(matrix(beta, N, burn), B)
  y <- matrix(0, N, TB)
  eps <- matrix(rnorm(N * TB), N, TB) * sig
  for (t in 1:TB) {
    y_lag <- if (t > 1) y[, t - 1] else rep(0, N)
    y[, t] <- alpha + phi * y_lag + B[, t] * x[, t] + gam * f[t] + eps[, t]
  }
  keep <- (burn + 1):TB
  list(y = y[, keep], x = x[, keep], y_lag = y[, keep - 1], k0 = k0)
}

# ---------------------------------------------------------------------
# Purpose: build the static panel object (CCEX proxy = xbar) or the
#   dynamic one (lagged y as stable regressor; CSA proxies xbar_t and
#   lags 1..q of xbar and ybar, as in Chudik and Pesaran, 2015).
# Used by: one_replication(), interval_replication(), dynamic_replication().
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic.
# ---------------------------------------------------------------------
sim_panel_object <- function(sim, dynamic = FALSE, q = 2) {
  xbar <- colMeans(sim$x)
  if (!dynamic) return(make_panel_data(sim$y, list(sim$x), cbind(xbar)))
  ybar_lag <- colMeans(sim$y_lag)
  TT <- ncol(sim$y)
  csa <- cbind(xbar, ybar_lag)
  for (L in 1:q) csa <- cbind(csa, c(rep(NA, L), xbar[1:(TT - L)]),
                              c(rep(NA, L), ybar_lag[1:(TT - L)]))
  make_panel_data(sim$y, list(sim$x), csa, stable = list(sim$y_lag), first = q + 1)
}

# ---------------------------------------------------------------------
# Purpose: single-break estimates of the four benchmarks on one panel.
# Used by: one_replication(), dynamic_replication().
# Feeds: Tables mc_dates, mc_dynamic.
# ---------------------------------------------------------------------
run_benchmarks <- function(panel, trim, with_ow = TRUE) {
  cands <- trim:(panel$T - trim)
  a <- panel$first - 1; b <- panel$T
  dfac <- defactor_ccex(panel)
  out <- c(BFK = cands[which.min(bfk_profile(panel, a, b, cands))],
           Dai = cands[which.min(dai_profile(dfac, a, b, cands))],
           DKW = cands[which.min(dkw_profile(dfac, a, b, cands))])
  if (with_ow) {
    ow <- ow_fit(dfac, G = 3, m = 1, min_len = trim, T_first = panel$first)
    out <- c(out, OW = ow$breaks$k[which.max(ow$breaks$energy)])
  }
  out
}

# ---------------------------------------------------------------------
# Purpose: one replication of a date-accuracy design (static DGP).
#   Returns the date of every method, and the number of common breaks
#   declared by the proposed diagnosis rule.
# Used by: run_mc().
# Feeds: Tables mc_dates, mc_diagnosis.
# ---------------------------------------------------------------------
one_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T, settings$k0, job$sign, settings$d,
                        settings$share, job$indiv, job$d_ind, FALSE, job$seed)
  panel <- sim_panel_object(sim)
  res <- common_breaks(panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  proposed <- NA
  if (nrow(res$breaks) > 0) proposed <- res$breaks$k_hat[which.max(res$breaks$C)]
  bench <- if (job$sign == "none") c(BFK = NA, Dai = NA, DKW = NA, OW = NA) else
    run_benchmarks(panel, settings$trim)
  data.frame(design = job$design, N = job$N, rep = job$rep,
             Proposed = proposed, t(bench), declared = nrow(res$breaks))
}

# ---------------------------------------------------------------------
# Purpose: one replication of the small-break design used to check the
#   95% date interval implied by the argmax limit.
# Used by: run_mc().
# Feeds: Table mc_interval.
# ---------------------------------------------------------------------
interval_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T_ci, settings$k0_ci, "same", job$d,
                        settings$share, "none", 0, FALSE, job$seed)
  panel <- sim_panel_object(sim)
  C <- concentration_scan(panel, settings$h_ci, settings$ell_ci)
  k_tilde <- which.max(C)
  r <- refine_break(panel, k_tilde, settings$h_ci)
  data.frame(design = job$design, N = job$N, rep = job$rep, d = job$d,
             k_hat = r$k_hat, lower = r$lower, upper = r$upper,
             cover = r$lower <= settings$k0_ci && settings$k0_ci <= r$upper,
             length = r$upper - r$lower + 1)
}

# ---------------------------------------------------------------------
# Purpose: one replication of the dynamic design. Compares the static
#   and dynamic (CS-ARDL) versions of the proposed estimator with the
#   BFK and Dai benchmarks estimated on the dynamic specification.
# Used by: run_mc().
# Feeds: Table mc_dynamic.
# ---------------------------------------------------------------------
dynamic_replication <- function(job, settings) {
  sim <- simulate_panel(job$N, settings$T, settings$k0, job$sign, settings$d,
                        settings$share, job$indiv, job$d_ind, TRUE, job$seed)
  static_panel <- sim_panel_object(sim, dynamic = FALSE)
  dyn_panel <- sim_panel_object(sim, dynamic = TRUE, q = 2)
  pick <- function(res) if (nrow(res$breaks) > 0) res$breaks$k_hat[which.max(res$breaks$C)] else NA
  r_static <- common_breaks(static_panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  r_dyn <- common_breaks(dyn_panel, settings$h, settings$ell, settings$kappa, with_ci = FALSE)
  bench <- run_benchmarks(dyn_panel, settings$trim, with_ow = FALSE)
  data.frame(design = job$design, N = job$N, rep = job$rep,
             Static = pick(r_static), Dynamic = pick(r_dyn), BFK = bench["BFK"],
             Dai = bench["Dai"], declared_static = nrow(r_static$breaks),
             declared_dynamic = nrow(r_dyn$breaks))
}

# ---------------------------------------------------------------------
# Purpose: run every Monte Carlo design. Seeds are fixed per replication
#   so results do not depend on the number of cores.
# Used by: run_all.R.
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic.
# ---------------------------------------------------------------------
run_mc <- function(settings, cores = 1) {
  apply_jobs <- function(jobs, fun) {
    job_list <- split(jobs, seq_len(nrow(jobs)))
    if (cores > 1 && .Platform$OS.type != "windows") {
      res <- parallel::mclapply(job_list, fun, settings = settings,
                                mc.cores = cores, mc.set.seed = FALSE)
    } else {
      res <- lapply(job_list, fun, settings = settings)
    }
    do.call(rbind, res)
  }
  # date-accuracy and diagnosis designs
  designs <- data.frame(
    design = c("same_none", "mixed_none", "same_dispersed", "mixed_dispersed",
               "same_cluster", "mixed_cluster", "null_dispersed"),
    sign = c("same", "mixed", "same", "mixed", "same", "mixed", "none"),
    indiv = c("none", "none", "dispersed", "dispersed", "cluster", "cluster", "dispersed"),
    d_ind = settings$d * c(1, 1, 1, 1, 1.5, 1.5, 1), stringsAsFactors = FALSE)
  jobs <- data.frame()
  for (j in 1:nrow(designs)) for (N in settings$N_grid) for (r in 1:settings$R) {
    jobs <- rbind(jobs, data.frame(designs[j, ], N = N, rep = r,
                                   seed = 1000000 * j + 1000 * N + r))
  }
  message("Monte Carlo: ", nrow(jobs), " date-accuracy panels")
  dates <- apply_jobs(jobs, one_replication)
  # interval design
  jobs <- data.frame()
  for (d in settings$d_ci) for (N in settings$N_ci) for (r in 1:settings$R) {
    jobs <- rbind(jobs, data.frame(design = "interval", N = N, rep = r, d = d,
                                   seed = 8000000 + round(1000 * d) * 1000 + N * 7 + r))
  }
  message("Monte Carlo: ", nrow(jobs), " interval panels")
  intervals <- apply_jobs(jobs, interval_replication)
  # dynamic design
  jobs <- data.frame()
  for (sg in c("same", "mixed")) for (N in settings$N_dyn) for (r in 1:settings$R) {
    jobs <- rbind(jobs, data.frame(design = paste0(sg, "_dispersed"), sign = sg,
                                   indiv = "dispersed", d_ind = settings$d, N = N, rep = r,
                                   seed = 9000000 + (sg == "mixed") * 100000 + N * 100 + r,
                                   stringsAsFactors = FALSE))
  }
  message("Monte Carlo: ", nrow(jobs), " dynamic panels")
  dynamic <- apply_jobs(jobs, dynamic_replication)
  list(dates = dates, intervals = intervals, dynamic = dynamic)
}
