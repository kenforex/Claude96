# =====================================================================
# 04_application.R
# UK local-authority house prices (349 LADs, 2004m1-2025m12), the data
# used by Pang and Chaudhuri (v9_8). Price equation with changing slopes
# on log sales and log employment; CCEX proxies are the cross-sectional
# averages of the two regressors. The dynamic version adds the lagged
# price and lags of the averages (Chudik and Pesaran, 2015).
# Dates: k is the last month of the old regime; tables report the first
# month of the new regime (k + 1), the convention of v9_8.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: read v9_8_data.csv and build N x T matrices in LAD order.
# Used by: run_application().
# Feeds: Tables app_breaks, app_compare, app_sensitivity, app_country;
#        Figure app_scan.
# ---------------------------------------------------------------------
read_housing <- function(root) {
  d <- read.csv(file.path(root, "data", "v9_8_data.csv"), stringsAsFactors = FALSE)
  year <- as.integer(sub("m.*", "", d$mdate))
  month <- as.integer(sub(".*m", "", d$mdate))
  d$t <- (year - 2004) * 12 + month
  d <- d[order(d$fid, d$t), ]
  N <- length(unique(d$fid)); TT <- max(d$t)
  stopifnot(nrow(d) == N * TT)
  codes <- d$areacode[d$t == 1]
  group <- ifelse(substr(codes, 1, 3) == "E09", "London",
           ifelse(substr(codes, 1, 1) == "E", "England excl. London",
           ifelse(substr(codes, 1, 1) == "S", "Scotland", "Wales")))
  list(price = matrix(d$realp, N, TT, byrow = TRUE),
       sales = matrix(d$lnsales, N, TT, byrow = TRUE),
       employ = matrix(d$lnemploy, N, TT, byrow = TRUE),
       group = group, N = N, T = TT)
}

# ---------------------------------------------------------------------
# Purpose: month label of the first month of the new regime, k + 1.
# Used by: 05_output.R.
# Feeds: Tables app_breaks, app_compare, app_sensitivity, app_country;
#        Figure app_scan.
# ---------------------------------------------------------------------
month_label <- function(k) {
  t <- k + 1
  sprintf("%d-%02d", 2004 + (t - 1) %/% 12, (t - 1) %% 12 + 1)
}

# ---------------------------------------------------------------------
# Purpose: static and dynamic panel objects for the price equation.
#   Static : CCEX proxies (sbar_t, ebar_t).
#   Dynamic: lagged price as a stable regressor; proxies sbar_t, ebar_t,
#            ybar_{t-1} and q further lags of each (q = 3 = floor(48^(1/3))).
# Used by: run_application().
# Feeds: Tables app_breaks, app_compare, app_sensitivity, app_country;
#        Figure app_scan.
# ---------------------------------------------------------------------
housing_panels <- function(h_data, q = 3) {
  TT <- h_data$T
  sbar <- colMeans(h_data$sales); ebar <- colMeans(h_data$employ)
  lag_vec <- function(v, L) c(rep(NA, L), v[1:(length(v) - L)])
  price_lag <- cbind(NA, h_data$price[, 1:(TT - 1)])
  ybar_lag <- lag_vec(colMeans(h_data$price), 1)
  static <- make_panel_data(h_data$price, list(h_data$sales, h_data$employ),
                            cbind(sbar, ebar))
  csa <- cbind(sbar, ebar, ybar_lag)
  for (L in 1:q) csa <- cbind(csa, lag_vec(sbar, L), lag_vec(ebar, L), lag_vec(ybar_lag, L))
  dynamic <- make_panel_data(h_data$price, list(h_data$sales, h_data$employ), csa,
                             stable = list(price_lag), first = q + 2)
  list(static = static, dynamic = dynamic)
}

# ---------------------------------------------------------------------
# Purpose: m = 4 common break dates from each benchmark, estimated on
#   the whole sample with a minimum regime length of 24 months (v9_8).
# Used by: run_application().
# Feeds: Table app_compare.
# ---------------------------------------------------------------------
benchmark_dates <- function(panel, m = 4, min_len = 24) {
  dfac <- defactor_ccex(panel)
  first <- panel$first; last <- panel$T
  out <- list(
    BFK = sequential_breaks(function(a, b, c) bfk_profile(panel, a, b, c), first, last, m, min_len),
    Dai = sequential_breaks(function(a, b, c) dai_profile(dfac, a, b, c), first, last, m, min_len),
    DKW = sequential_breaks(function(a, b, c) dkw_profile(dfac, a, b, c), first, last, m, min_len))
  ow <- ow_fit(dfac, G = 3, m = m, min_len = min_len, T_first = first)
  big <- ow$breaks[ow$breaks$size == max(ow$breaks$size), ]
  out$OW <- sort(big$k)                          # dates of the largest group
  out
}

# ---------------------------------------------------------------------
# Purpose: participation by country group at a declared common break:
#   share of LADs whose own jump Wald statistic (HAC) exceeds the 5%
#   chi-square critical value, and the mean long-run signal-to-noise
#   jump energy.
# Used by: run_application().
# Feeds: Table app_country.
# ---------------------------------------------------------------------
country_participation <- function(refined, weights, groups, p) {
  out <- data.frame()
  crit <- qchisq(0.95, p)
  wald <- energy <- rep(NA, length(groups))
  for (i in seq_along(groups)) {
    f <- refined$jumps[[i]]
    if (is.null(f) || is.na(weights[i])) next
    wald[i] <- sum(f$b * solve(f$V, f$b))
    energy[i] <- refined$lr_factor * weights[i] * sum(f$b * (f$Q %*% f$b))
  }
  for (g in c("England excl. London", "London", "Scotland", "Wales")) {
    ix <- groups == g & !is.na(wald)
    out <- rbind(out, data.frame(group = g, n = sum(ix), share = mean(wald[ix] > crit),
                                 energy = mean(energy[ix])))
  }
  out
}

# ---------------------------------------------------------------------
# Purpose: run the whole application: the proposed estimator for the
#   static and dynamic equations, window sensitivity, benchmarks and
#   country participation. Results stay in memory.
# Used by: run_all.R.
# Feeds: Tables app_breaks, app_compare, app_sensitivity, app_country;
#        Figure app_scan.
# ---------------------------------------------------------------------
run_application <- function(root, h = 24, ell = 6, kappa = 0.15) {
  h_data <- read_housing(root)
  panels <- housing_panels(h_data)
  main <- list(); sens <- data.frame(); country <- data.frame(); bench <- list()
  for (spec in c("static", "dynamic")) {
    message("Application: ", spec, " equation")
    res <- common_breaks(panels[[spec]], h, ell, kappa, with_ci = TRUE)
    main[[spec]] <- res
    for (j in seq_len(nrow(res$breaks))) {
      cp <- country_participation(res$refined[[j]], res$refined[[j]]$weights,
                                  h_data$group, panels[[spec]]$p)
      country <- rbind(country, data.frame(spec = spec, k = res$breaks$k_hat[j], cp))
    }
    for (hh in c(18, 36)) {
      r <- common_breaks(panels[[spec]], hh, ell, kappa, with_ci = FALSE)
      sens <- rbind(sens, data.frame(spec = spec, h = hh,
                                     dates = paste(month_label(r$breaks$k_hat), collapse = ", ")))
    }
    sens <- rbind(sens, data.frame(spec = spec, h = h,
                                   dates = paste(month_label(res$breaks$k_hat), collapse = ", ")))
    message("Application: benchmarks, ", spec, " equation")
    bench[[spec]] <- benchmark_dates(panels[[spec]])
  }
  list(main = main, sensitivity = sens, country = country, bench = bench,
       settings = list(h = h, ell = ell, kappa = kappa),
       v98 = c(47, 79, 146, 201))                # v9_8: 2007-12, 2010-08, 2016-03, 2020-10
}
