# =====================================================================
# 01_estimators.R
# The proposed two-step estimator of common break dates:
#   Step 1 (global screening): the concentration scan C(k) over all dates.
#   Step 2 (local refinement): the pooled least-squares date inside a
#           window of half-width h around each screened candidate, the
#           diagnosis rule, and the confidence interval.
# All functions work on a "panel" list built by make_panel_data():
#   y      N x T matrix of the dependent variable
#   x      list of p N x T matrices whose slopes may break
#   stable list of N x T matrices with stable unit-specific slopes
#          (empty in the static model, the lagged dependent variable
#          in the dynamic model)
#   csa    T x q matrix of cross-sectional averages (CCEX proxies)
#   first  first period that can be used (after lags)
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: collect everything a unit-by-unit window regression needs.
# Used by: 03_simulation.R (simulated panels) and 04_application.R
#          (housing panels).
# Feeds: every table and figure (all estimators start from this list).
# ---------------------------------------------------------------------
make_panel_data <- function(y, x, csa, stable = list(), first = 1) {
  list(y = y, x = x, csa = as.matrix(csa), stable = stable,
       first = first, N = nrow(y), T = ncol(y), p = length(x))
}

# ---------------------------------------------------------------------
# Purpose: regressor matrices of unit i on the rows of one window.
#   B = stable part (intercept, x, stable regressors, CSA proxies),
#   X = the p regressors whose slopes are allowed to break.
# Used by: local_profile(), unit_jump().
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic, app_breaks,
#        app_sensitivity, app_country; Figure app_scan.
# ---------------------------------------------------------------------
window_design <- function(panel, i, rows) {
  X <- matrix(0, length(rows), panel$p)
  for (j in 1:panel$p) X[, j] <- panel$x[[j]][i, rows]
  B <- cbind(1, X)
  if (length(panel$stable) > 0) {
    for (j in seq_along(panel$stable)) B <- cbind(B, panel$stable[[j]][i, rows])
  }
  B <- cbind(B, panel$csa[rows, , drop = FALSE])
  list(B = B, X = X)
}

# ---------------------------------------------------------------------
# Purpose: Bartlett long-run variance of a series, with the Newey-West
#   lag rule floor(4 (n/100)^(2/9)).
# Used by: break_scale().
# Feeds: Tables mc_interval, app_breaks.
# ---------------------------------------------------------------------
long_run_variance <- function(u) {
  n <- length(u)
  L <- floor(4 * (n / 100)^(2 / 9))
  lrv <- mean(u^2)
  if (L > 0) for (l in 1:L) lrv <- lrv + 2 * (1 - l / (L + 1)) * mean(u[-(1:l)] * u[1:(n - l)])
  lrv
}

# ---------------------------------------------------------------------
# Purpose: Bartlett long-run covariance matrix of the rows of S (n x p),
#   same lag rule as long_run_variance().
# Used by: unit_jump().
# Feeds: Tables mc_interval, app_breaks, app_country.
# ---------------------------------------------------------------------
long_run_cov <- function(S) {
  S <- as.matrix(S); n <- nrow(S)
  L <- floor(4 * (n / 100)^(2 / 9))
  V <- crossprod(S) / n
  if (L > 0) for (l in 1:L) {
    G <- crossprod(S[-(1:l), , drop = FALSE], S[1:(n - l), , drop = FALSE]) / n
    V <- V + (1 - l / (L + 1)) * (G + t(G))
  }
  V
}

# ---------------------------------------------------------------------
# Purpose: residual sums of squares of one unit's window regression with
#   a slope step after each candidate date (Frisch-Waugh form: y and the
#   step regressors are first residualised on the stable part B).
#   Also returns, for the fit with the step at `center`, the residual
#   variance (unit weight 1 / sigma2) and the first-order residual
#   autocorrelation (used to express C(k) in long-run units).
# Used by: local_profile().
# Feeds: same tables and figures as local_profile().
# ---------------------------------------------------------------------
unit_ssr <- function(y, B, X, rows, cands, center) {
  qb <- qr(B, tol = 1e-9)
  y_res <- qr.resid(qb, y)
  df <- length(rows) - qb$rank - ncol(X)
  ssr <- rep(NA, length(cands)); sigma2 <- NA; rho <- NA
  for (j in seq_along(cands)) {
    H <- X * as.numeric(rows > cands[j])       # step regressors x * 1{t > k}
    H_res <- qr.resid(qb, H)
    G <- crossprod(H_res)
    if (rcond(G) < 1e-8) next                    # step not identified
    g <- crossprod(H_res, y_res)
    b <- solve(G, g)
    ssr[j] <- sum(y_res^2) - sum(g * b)
    if (cands[j] == center) {
      u <- as.vector(y_res - H_res %*% b)
      sigma2 <- sum(u^2) / df
      rho <- sum(u[-1] * u[-length(u)]) / sum(u^2)
    }
  }
  list(ssr = ssr, sigma2 = sigma2, rho = rho)
}

# ---------------------------------------------------------------------
# Purpose: pooled local profile S(k) = sum_i pi_i SSR_i(k) on the window
#   (center - h, center + h], with weights pi_i = 1 / sigma_i^2 taken
#   from the fit with the step at the window centre. lr_factor =
#   (1 - rho)/(1 + rho), rho = median residual autocorrelation (floored
#   at zero), converts short-run into long-run signal-to-noise units.
# Used by: concentration_scan(), refine_break().
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic, app_breaks,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
local_profile <- function(panel, center, h, cands) {
  rows <- (center - h + 1):(center + h)
  ssr <- matrix(NA, panel$N, length(cands))
  w <- rep(NA, panel$N); rho <- rep(NA, panel$N)
  for (i in 1:panel$N) {
    d <- window_design(panel, i, rows)
    fit <- unit_ssr(panel$y[i, rows], d$B, d$X, rows, cands, center)
    if (any(is.na(fit$ssr)) || is.na(fit$sigma2) || fit$sigma2 <= 0) next   # unidentified unit
    ssr[i, ] <- fit$ssr
    w[i] <- 1 / fit$sigma2
    rho[i] <- fit$rho
  }
  ok <- !is.na(w)
  rho_bar <- max(0, median(rho[ok]))
  list(S = colSums(ssr[ok, , drop = FALSE] * w[ok]), cands = cands,
       weights = w, used = sum(ok), lr_factor = (1 - rho_bar) / (1 + rho_bar))
}

# ---------------------------------------------------------------------
# Purpose: Step 1, the global concentration scan
#   C(k) = lr_factor * [S(k - l) + S(k + l) - 2 S(k)] / (2 l N),
#   computed on a window of half-width h centred at every date k.
#   C(k) is the average long-run signal-to-noise break energy located at
#   date k: of order one at a common break, negligible when only
#   dispersed individual breaks are present.
# Used by: common_breaks().
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic, app_breaks,
#        app_sensitivity; Figure app_scan.
# ---------------------------------------------------------------------
concentration_scan <- function(panel, h, ell) {
  C <- rep(NA, panel$T)
  first_k <- panel$first + h - 1
  for (k in first_k:(panel$T - h)) {
    prof <- local_profile(panel, k, h, c(k - ell, k, k + ell))
    C[k] <- prof$lr_factor * (prof$S[1] + prof$S[3] - 2 * prof$S[2]) / (2 * ell * prof$used)
  }
  C
}

# ---------------------------------------------------------------------
# Purpose: greedy local maxima of a scan, at least `sep` periods apart.
# Used by: common_breaks().
# Feeds: Tables mc_dates, mc_diagnosis, app_breaks, app_sensitivity;
#        Figure app_scan.
# ---------------------------------------------------------------------
find_peaks <- function(stat, sep) {
  peaks <- c()
  for (k in order(stat, decreasing = TRUE)) {
    if (is.na(stat[k])) next
    if (length(peaks) == 0 || min(abs(k - peaks)) >= sep) peaks <- c(peaks, k)
  }
  peaks
}

# ---------------------------------------------------------------------
# Purpose: estimated jump, its HAC covariance, residuals and raw
#   regressor moment of unit i when the step is placed after date k.
# Used by: break_scale().
# Feeds: Tables mc_interval, app_breaks, app_country.
# ---------------------------------------------------------------------
unit_jump <- function(panel, i, rows, k) {
  d <- window_design(panel, i, rows)
  qb <- qr(d$B, tol = 1e-9)
  y_res <- qr.resid(qb, panel$y[i, rows])
  H_res <- qr.resid(qb, d$X * as.numeric(rows > k))
  G <- crossprod(H_res)
  if (rcond(G) < 1e-8) return(NULL)
  b <- solve(G, crossprod(H_res, y_res))
  u <- as.vector(y_res - H_res %*% b)
  n <- length(rows); df <- n - qb$rank - ncol(d$X)
  Gi <- solve(G)
  V <- Gi %*% (n * long_run_cov(H_res * u)) %*% Gi * n / df   # HAC covariance
  list(b = as.vector(b), V = V, u = u, X = d$X, Q = crossprod(d$X) / n)
}

# ---------------------------------------------------------------------
# Purpose: debiased break energy lambda, long-run variance omega of the
#   aggregated score
#   xi_t = sum_i pi_i (Delta_i' x_it) u_it, and the argmax scale
#   L = lambda^2 / omega at date k, using
#   the refinement window centred at `center`.
#   The scale of the date limit is (lambda^2/omega)(k_hat - k0).
# Used by: refine_break().
# Feeds: Tables mc_interval, app_breaks, app_country.
# ---------------------------------------------------------------------
break_scale <- function(panel, k, h, weights, center = k) {
  rows <- (center - h + 1):(center + h); n <- length(rows)
  lam <- 0; bias <- 0; xi <- rep(0, n)
  jumps <- vector("list", panel$N)
  for (i in 1:panel$N) {
    if (is.na(weights[i])) next
    f <- unit_jump(panel, i, rows, k)
    if (is.null(f)) next
    jumps[[i]] <- f
    lam  <- lam + weights[i] * sum(f$b * (f$Q %*% f$b))
    bias <- bias + weights[i] * sum(diag(f$Q %*% f$V))
    xi   <- xi + weights[i] * as.vector(f$X %*% f$b) * f$u   # aggregated score
  }
  om <- long_run_variance(xi)            # long-run variance of the aggregated score
  # the drift lambda is debiased for the estimation noise in the jumps;
  # omega is not, because that noise is part of the finite-window profile
  lam_d <- max(lam - bias, 1e-8)
  list(lambda = lam_d, omega = om, scale = lam_d^2 / om, jumps = jumps)
}

# ---------------------------------------------------------------------
# Purpose: distribution function of argmax_v {W(v) - |v|/2} for x > 0
#   (Bai, 1997), and its two-sided quantile used for date intervals.
# Used by: refine_break(), 05_output.R (interval table note).
# Feeds: Tables mc_interval, app_breaks.
# ---------------------------------------------------------------------
argmax_cdf <- function(x) {
  1 + sqrt(x / (2 * pi)) * exp(-x / 8) - 0.5 * (x + 5) * pnorm(-sqrt(x) / 2) +
    1.5 * exp(x) * pnorm(-1.5 * sqrt(x))
}
argmax_quantile <- function(level = 0.95) {
  uniroot(function(x) argmax_cdf(x) - (1 + level) / 2, c(0.01, 200))$root
}

# ---------------------------------------------------------------------
# Purpose: Step 2, local refinement around a screened candidate:
#   the pooled least-squares date inside the window, and a 95% interval
#   k_hat +/- floor(q / L_hat) based on the argmax limit.
# Used by: common_breaks(), 03_simulation.R (interval design).
# Feeds: Tables mc_interval, app_breaks, app_country.
# ---------------------------------------------------------------------
refine_break <- function(panel, k_tilde, h) {
  half <- floor(h / 2)
  cands <- (k_tilde - half):(k_tilde + half)
  prof <- local_profile(panel, k_tilde, h, cands)
  k_hat <- cands[which.min(prof$S)]
  sc <- break_scale(panel, k_hat, h, prof$weights, center = k_tilde)
  half_width <- floor(argmax_quantile(0.95) / sc$scale)   # |k_hat - k0| is an integer
  list(k_hat = k_hat, lambda = sc$lambda / prof$used, scale = sc$scale,
       lower = k_hat - half_width, upper = k_hat + half_width,
       profile = prof$S - min(prof$S), cands = cands, jumps = sc$jumps,
       weights = prof$weights, lr_factor = prof$lr_factor)
}

# ---------------------------------------------------------------------
# Purpose: the complete procedure. Screen with C(k), refine each peak,
#   and declare a common break when the concentration at the refined
#   date exceeds kappa, the declared minimum break energy per unit
#   (in long-run signal-to-noise units).
# Used by: 03_simulation.R, 04_application.R.
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic, app_breaks,
#        app_sensitivity, app_country; Figure app_scan.
# ---------------------------------------------------------------------
common_breaks <- function(panel, h, ell, kappa, max_peaks = 8, with_ci = TRUE) {
  C <- concentration_scan(panel, h, ell)
  peaks <- find_peaks(C, h)
  peaks <- peaks[seq_len(min(max_peaks, length(peaks)))]
  out <- data.frame()
  refined <- list()
  for (k in peaks) {
    if (C[k] <= kappa / 2) next                 # clearly below the threshold
    if (with_ci) {
      r <- refine_break(panel, k, h)
    } else {
      half <- floor(h / 2)
      prof <- local_profile(panel, k, h, (k - half):(k + half))
      r <- list(k_hat = prof$cands[which.min(prof$S)], lambda = NA, scale = NA,
                lower = NA, upper = NA)
    }
    if (is.na(C[r$k_hat]) || C[r$k_hat] <= kappa) next      # diagnosis rule
    if (nrow(out) > 0 && min(abs(out$k_hat - r$k_hat)) < ell) next
    out <- rbind(out, data.frame(k_screen = k, k_hat = r$k_hat, C = C[r$k_hat],
                                 lambda = r$lambda, scale = r$scale,
                                 lower = r$lower, upper = r$upper))
    refined[[length(refined) + 1]] <- r
  }
  if (nrow(out) > 0) {
    o <- order(out$k_hat); out <- out[o, ]; refined <- refined[o]
  }
  list(breaks = out, scan = C, refined = refined)
}
