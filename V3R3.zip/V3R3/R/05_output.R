# =====================================================================
# 05_output.R
# The only module that writes files: one .tex file per table in Tables/
# and one .pdf file per figure in Figures/.
# =====================================================================

# ---------------------------------------------------------------------
# Purpose: format numbers, with "--" for missing values.
# Used by: every table writer below.
# Feeds: all tables.
# ---------------------------------------------------------------------
fmt <- function(x, digits = 2) {
  ifelse(is.na(x), "--", formatC(x, format = "f", digits = digits))
}

# ---------------------------------------------------------------------
# Purpose: write one LaTeX table (booktabs) with a caption, label, header
#   rows, body rows and a note.
# Used by: write_tables().
# Feeds: all tables.
# ---------------------------------------------------------------------
write_tex_table <- function(root, file, caption, label, align, header, body, note) {
  lines <- c("\\begin{table}[htbp]", "\\centering", "\\small",
             paste0("\\caption{", caption, "}\\label{", label, "}"),
             paste0("\\begin{tabular}{", align, "}"), "\\toprule", header, "\\midrule",
             body, "\\bottomrule", "\\end{tabular}",
             paste0("\\par\\smallskip\\begin{minipage}{.95\\linewidth}\\footnotesize ",
                    note, "\\end{minipage}"),
             "\\end{table}")
  writeLines(lines, file.path(root, "Tables", paste0(file, ".tex")))
}

# ---------------------------------------------------------------------
# Purpose: readable names of the Monte Carlo designs.
# Used by: write_tables().
# Feeds: Tables mc_dates, mc_diagnosis, mc_dynamic.
# ---------------------------------------------------------------------
design_name <- c(same_none = "Same sign, none", mixed_none = "Mixed sign, none",
                 same_dispersed = "Same sign, dispersed", mixed_dispersed = "Mixed sign, dispersed",
                 same_cluster = "Same sign, clustered", mixed_cluster = "Mixed sign, clustered",
                 null_dispersed = "No common break, dispersed")

# ---------------------------------------------------------------------
# Purpose: write every table of the paper.
# Used by: run_all.R.
# Feeds: Tables mc_dates, mc_diagnosis, mc_interval, mc_dynamic,
#        app_breaks, app_compare, app_sensitivity, app_country.
# ---------------------------------------------------------------------
write_tables <- function(root, mc, app, settings) {
  k0 <- settings$k0
  methods <- c("Proposed", "BFK", "Dai", "DKW", "OW")
  # ---- Table mc_dates: exact date and date within two periods --------
  d <- mc$dates[mc$dates$design != "null_dispersed", ]
  body <- c()
  for (panel in c("exact", "within")) {
    label <- if (panel == "exact") "A. Estimated date equals $k_0$" else
      "B. Estimated date within two periods of $k_0$"
    body <- c(body, paste0("\\multicolumn{7}{@{}l}{\\textit{", label, "}}\\\\"))
    for (des in unique(d$design)) for (N in settings$N_grid) {
      z <- d[d$design == des & d$N == N, ]
      vals <- sapply(methods, function(m) {
        e <- z[[m]] - k0
        if (panel == "exact") mean(!is.na(e) & e == 0) else mean(!is.na(e) & abs(e) <= 2)
      })
      body <- c(body, paste0(design_name[des], " & ", N, " & ",
                             paste(fmt(vals), collapse = " & "), "\\\\"))
    }
  }
  write_tex_table(root, "mc_dates",
    "Monte Carlo: accuracy of the common break date",
    "tab:mc-dates", "@{}llccccc@{}",
    "Design & $N$ & Proposed & BFK & Dai & DKW & OW\\\\", body,
    paste0(settings$R, " replications per cell; $T=", settings$T, "$, $k_0=", k0,
           "$, one common break shared by half of the units, jump magnitude ", settings$d,
           ". Individual breaks: none; dispersed (one per unit, uniform over the sample); ",
           "clustered (40\\% of the units, jump magnitude ", 1.5 * settings$d,
           ", dates 25--64 periods after $k_0$). Proposed: $h=", settings$h, "$, $\\ell=",
           settings$ell, "$, $\\kappa=", settings$kappa, "$; a replication without a declared ",
           "common break counts as a failure. Benchmarks estimate one break on the full sample."))
  # ---- Table mc_diagnosis: number of declared common breaks ----------
  body <- c()
  for (des in unique(mc$dates$design)) {
    target <- if (des == "null_dispersed") 0 else 1
    cells <- c()
    for (N in settings$N_grid) {
      z <- mc$dates[mc$dates$design == des & mc$dates$N == N, ]
      cells <- c(cells, fmt(mean(z$declared == target)), fmt(mean(z$declared)))
    }
    body <- c(body, paste0(design_name[des], " & ", paste(cells, collapse = " & "), "\\\\"))
  }
  write_tex_table(root, "mc_diagnosis",
    "Monte Carlo: diagnosis of the number of common breaks",
    "tab:mc-diagnosis", "@{}lcccccc@{}",
    paste0(" & \\multicolumn{2}{c}{$N=", settings$N_grid[1], "$} & \\multicolumn{2}{c}{$N=",
           settings$N_grid[2], "$} & \\multicolumn{2}{c}{$N=", settings$N_grid[3], "$}\\\\",
           " Design & Correct & Mean & Correct & Mean & Correct & Mean\\\\"), body,
    paste0("Correct: frequency with which the rule declares exactly the true number of common ",
           "breaks (one, or zero in the last design). Mean: average number declared. ",
           "Same designs and settings as Table~\\ref{tab:mc-dates}."))
  # ---- Table mc_interval: 95% date intervals in the small-break design
  body <- c()
  for (N in settings$N_ci) for (dd in settings$d_ci) {
    z <- mc$intervals[mc$intervals$N == N & mc$intervals$d == dd, ]
    ok <- abs(z$k_hat - settings$k0_ci) <= floor(settings$h_ci / 2)
    body <- c(body, paste0(N, " & ", dd, " & ", fmt(mean(ok)), " & ",
                           fmt(mean(z$k_hat == settings$k0_ci)), " & ",
                           fmt(mean(z$cover)), " & ", fmt(mean(z$cover[ok])), " & ",
                           fmt(mean(z$length), 1), "\\\\"))
  }
  write_tex_table(root, "mc_interval",
    "Monte Carlo: 95\\% intervals for the common break date",
    "tab:mc-interval", "@{}cccccccc@{}",
    "$N$ & Jump & Located & Exact & Coverage & Coverage$\\mid$located & Length\\\\", body,
    paste0(settings$R, " replications per cell; $T=", settings$T_ci, "$, $k_0=",
           settings$k0_ci, "$, half of the units break, no individual breaks; $h=",
           settings$h_ci, "$, $\\ell=", settings$ell_ci, "$. Located: the refined date lies ",
           "within $h/2$ of $k_0$. Intervals are $\\hat k\\pm\\lfloor q_{.975}/\\hat L\\rfloor$ with ",
           "$q_{.975}=", fmt(argmax_quantile(0.95)), "$ from the argmax distribution."))
  # ---- Table mc_dynamic ----------------------------------------------
  body <- c()
  for (des in unique(mc$dynamic$design)) {
    z <- mc$dynamic[mc$dynamic$design == des, ]
    vals <- sapply(c("Static", "Dynamic", "BFK", "Dai"), function(m) {
      e <- z[[m]] - k0
      c(mean(!is.na(e) & e == 0), mean(!is.na(e) & abs(e) <= 2))
    })
    body <- c(body, paste0(design_name[des], " & ",
                           paste(paste0(fmt(vals[1, ]), "/", fmt(vals[2, ])), collapse = " & "),
                           " & ", fmt(mean(z$declared_static == 1)), " & ",
                           fmt(mean(z$declared_dynamic == 1)), "\\\\"))
  }
  write_tex_table(root, "mc_dynamic",
    "Monte Carlo: dynamic panels",
    "tab:mc-dynamic", "@{}lcccccc@{}",
    paste0(" & \\multicolumn{4}{c}{Exact / within two periods} & ",
           "\\multicolumn{2}{c}{One break declared}\\\\ ",
           "Design & Static & Dynamic & BFK & Dai & Static & Dynamic\\\\"), body,
    paste0(settings$R, " replications, $N=", settings$N_dyn, "$, $T=", settings$T,
           "$; $y_{it}$ has a unit-specific autoregressive coefficient drawn from $U(0.3,0.7)$. ",
           "Entries: exact / within two periods. Static and Dynamic: the proposed estimator ",
           "without and with the lagged dependent variable and two lags of the averages. ",
           "BFK and Dai use the dynamic specification. One break declared: frequency with ",
           "which exactly one common break is declared."))
  # ---- Table app_breaks ------------------------------------------------
  body <- c()
  for (spec in c("static", "dynamic")) {
    b <- app$main[[spec]]$breaks
    body <- c(body, paste0("\\multicolumn{6}{@{}l}{\\textit{", ifelse(spec == "static",
      "A. Static price equation", "B. Dynamic price equation"), "}}\\\\"))
    for (j in seq_len(nrow(b))) {
      near <- app$v98[which.min(abs(app$v98 - b$k_hat[j]))]
      ref <- if (abs(near - b$k_hat[j]) <= 12) month_label(near) else "--"
      ci <- if (b$lower[j] == b$upper[j]) month_label(b$k_hat[j]) else
        paste(month_label(b$lower[j]), "to", month_label(b$upper[j]))
      body <- c(body, paste0(month_label(b$k_screen[j]), " & ", month_label(b$k_hat[j]), " & ",
                             ci, " & ",
                             fmt(b$C[j]), " & ", fmt(b$lambda[j]), " & ", ref, "\\\\"))
    }
  }
  write_tex_table(root, "app_breaks",
    "Common breaks in the UK house-price equation",
    "tab:app-breaks", "@{}llcccc@{}",
    "Screened & Refined & 95\\% interval & $\\hat C(\\hat k)$ & $\\hat\\lambda/N$ & PC date\\\\",
    body,
    paste0("349 LADs, 2004m1--2025m12. Dates are the first month of the new regime. ",
           "Changing slopes on log sales and log employment; CCEX proxies are the averages of ",
           "both regressors. The dynamic equation adds the lagged price and three lags of the ",
           "averages and of the lagged average price. $h=", app$settings$h, "$, $\\ell=",
           app$settings$ell, "$, $\\kappa=", app$settings$kappa, "$. $\\hat C$ is in long-run ",
           "signal-to-noise units; $\\hat\\lambda/N$ is the debiased break energy per LAD. ",
           "PC date: the nearest common date of Pang and Chaudhuri (2026) within twelve months."))
  # ---- Table app_compare -----------------------------------------------
  body <- c()
  for (spec in c("static", "dynamic")) {
    body <- c(body, paste0("\\multicolumn{2}{@{}l}{\\textit{", ifelse(spec == "static",
      "A. Static price equation", "B. Dynamic price equation"), "}}\\\\"))
    body <- c(body, paste0("Proposed (diagnosed) & ",
                           paste(month_label(app$main[[spec]]$breaks$k_hat), collapse = ", "), "\\\\"))
    for (m in c("BFK", "Dai", "DKW", "OW")) {
      body <- c(body, paste0(m, " & ", paste(month_label(app$bench[[spec]][[m]]), collapse = ", "), "\\\\"))
    }
  }
  body <- c(body, "\\midrule", paste0("Pang and Chaudhuri (2026), spatial & ",
                                      paste(month_label(app$v98), collapse = ", "), "\\\\"))
  write_tex_table(root, "app_compare",
    "Common break dates: proposed estimator and existing methods",
    "tab:app-compare", "@{}ll@{}",
    "Method & Dates (first month of the new regime)\\\\", body,
    paste0("Benchmarks estimate four common breaks on the full sample with a minimum regime ",
           "length of 24 months, by sequential splitting with repartition. BFK: unit slopes, ",
           "averages of prices and regressors with regime-specific loadings. Dai: CCEX removed ",
           "on the full sample, unit slopes (spatial lag omitted). DKW: CCEX removed, pooled slopes. ",
           "OW: three groups with group-specific breaks; dates of the largest group."))
  # ---- Table app_sensitivity ------------------------------------------
  s <- app$sensitivity[order(app$sensitivity$spec != "static", app$sensitivity$h), ]
  body <- paste0(ifelse(s$spec == "static", "Static", "Dynamic"), " & ", s$h, " & ",
                 ifelse(nchar(s$dates) > 0, s$dates, "--"), "\\\\")
  write_tex_table(root, "app_sensitivity",
    "Diagnosed common breaks for different window half-widths",
    "tab:app-sensitivity", "@{}lcl@{}",
    "Equation & $h$ & Diagnosed common breaks\\\\", body,
    paste0("Same data and specification as Table~\\ref{tab:app-breaks}; $\\ell=",
           app$settings$ell, "$ and $\\kappa=", app$settings$kappa, "$."))
  # ---- Table app_country ----------------------------------------------
  cc <- app$country; body <- c()
  for (spec in c("static", "dynamic")) for (k in unique(cc$k[cc$spec == spec])) {
    z <- cc[cc$spec == spec & cc$k == k, ]
    body <- c(body, paste0(ifelse(spec == "static", "Static", "Dynamic"), " & ",
                           month_label(k), " & ",
                           paste(paste0(fmt(z$share), " (", fmt(z$energy), ")"), collapse = " & "),
                           "\\\\"))
  }
  write_tex_table(root, "app_country",
    "Participation in each common break by country group",
    "tab:app-country", "@{}llcccc@{}",
    "Equation & Break & England excl.\\ London & London & Scotland & Wales\\\\", body,
    paste0("Share of LADs whose own HAC jump Wald statistic in the refinement window exceeds the ",
           "5\\% $\\chi^2_2$ critical value; mean long-run signal-to-noise jump energy in parentheses. ",
           "LAD counts: ", paste(paste0(cc$group[1:4], " ", cc$n[1:4]), collapse = ", "), "."))
}

# ---------------------------------------------------------------------
# Purpose: Figure app_scan, the concentration scan C(k) of the static and
#   dynamic equations with the threshold kappa, the diagnosed breaks and
#   the common dates of Pang and Chaudhuri (2026), i.e. v9_8.
# Used by: run_all.R.
# Feeds: Figure app_scan.
# ---------------------------------------------------------------------
write_figures <- function(root, app) {
  pdf(file.path(root, "Figures", "app_scan.pdf"), width = 7.2, height = 5.2)
  par(mfrow = c(2, 1), mar = c(3, 4, 1.8, 0.8), mgp = c(2.1, 0.6, 0), cex = 0.8)
  for (spec in c("static", "dynamic")) {
    C <- app$main[[spec]]$scan
    k <- seq_along(C)
    date <- 2004 + k / 12                      # first month of the new regime
    plot(date, C, type = "l", col = "#1B6CA8", lwd = 1.2, xlab = "",
         ylab = expression(hat(C)(k)), ylim = range(C, na.rm = TRUE) * c(1, 1.3),
         main = ifelse(spec == "static", "Static price equation", "Dynamic price equation"))
    abline(h = app$settings$kappa, lty = 2, col = "grey40")
    abline(v = 2004 + app$v98 / 12, lty = 3, col = "#B35806")
    b <- app$main[[spec]]$breaks
    points(2004 + b$k_hat / 12, b$C, pch = 19, col = "#1B6CA8", cex = 0.9)
    if (spec == "static") legend("top", c(expression(hat(C)(k)), expression(kappa),
                                          "Pang-Chaudhuri dates", "diagnosed breaks"),
                                 col = c("#1B6CA8", "grey40", "#B35806", "#1B6CA8"),
                                 lty = c(1, 2, 3, NA), pch = c(NA, NA, NA, 19), bg = "white",
                                 box.col = "white", ncol = 2, cex = 0.85)
  }
  invisible(dev.off())
}
