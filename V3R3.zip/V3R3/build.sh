#!/bin/sh
# Build main.pdf and appendix.pdf from the tex files, Tables/ and Figures/.
# Intermediate LaTeX files stay in a temporary directory that is removed on exit.
set -eu
cd "$(dirname "$0")"
project_dir="$(pwd)"
build_dir="$(mktemp -d)"
trap 'rm -rf "$build_dir"' EXIT
cp main.tex appendix.tex preamble.tex references.tex "$build_dir/"
ln -s "$project_dir/Tables" "$build_dir/Tables"
ln -s "$project_dir/Figures" "$build_dir/Figures"
cd "$build_dir"
# main and appendix cross-reference each other (xr-hyper), so they are compiled alternately
for paper in main appendix main appendix main; do
  pdflatex -interaction=nonstopmode -halt-on-error "$paper.tex" > "$paper.build-log" 2>&1 || {
    tail -50 "$paper.build-log"
    exit 1
  }
done
cp main.pdf appendix.pdf "$project_dir/"
printf 'Built main.pdf and appendix.pdf\n'
