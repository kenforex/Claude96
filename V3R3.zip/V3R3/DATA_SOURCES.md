# 复现数据来源清单

## 1. 数据文件

`data/v9_8_data.csv` 是 Pang and Chaudhuri (2026)（v9_8）使用的冻结面板，按原样收录，未作任何修改。

- 规模：349 个地方政府辖区（LAD）× 264 个月（2004-01 至 2025-12），共 92,136 行。
- 国别构成：英格兰 295（其中伦敦 33）、苏格兰 32、威尔士 22。北爱尔兰因无法构成平衡面板而不在样本中。
- SHA-256：`6350230d25758f0eb9babdfc334779e13c3c759ad65c9f3fa16f996375b90344`（与 v9 系列原始面板一致）。

| 列名 | 含义 | 是否被代码使用 |
|---|---|---|
| `area` | LAD 名称 | 否 |
| `areacode` | ONS LAD 编码。首字母 E/S/W 区分国别，E09 为伦敦 | 是（国别分组） |
| `mdate` | 月份，格式 `2004m1` | 是 |
| `fid` | LAD 排序编号 | 是（排序） |
| `realp` | 季调后对数实际房价 log(HPI/CPI) | 是（被解释变量 y） |
| `lnsales` | 季调后对数成交量 | 是（回归元 s） |
| `lnemploy` | 16–64 岁对数就业率 | 是（回归元 e） |
| `realp_nsa` | 未季调对数实际房价 | 否 |
| `lnsales_nsa` | 未季调对数成交量 | 否 |

最后两列是原文件自带的未季调版本，本文不使用。为使文件与 v9_8 的哈希值一致，保留原样。

## 2. 原始来源

| 变量 | 来源 | 地址 |
|---|---|---|
| 房价指数、成交量 | HM Land Registry, UK House Price Index | https://www.gov.uk/government/collections/uk-house-price-index-reports |
| 消费者价格指数（平减） | ONS, CPI INDEX 00: ALL ITEMS 2015=100（D7BT） | https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/d7bt/mm23 |
| 16–64 岁就业率 | ONS Annual Population Survey，经 Nomis 获取 | https://www.nomisweb.co.uk/ |
| LAD 地理口径 | ONS 2024 年 12 月 LAD 边界与编码 | https://geoportal.statistics.gov.uk/ |

## 3. 构造方法（沿用 v9_8 附录 A）

- **实际房价**：realp = log(房价 / CPI)。
- **季节调整**：用稳健周期性 STL（Cleveland et al. 1990）逐 LAD 调整房价和成交量，扣除去均值后的季节项，从而保留每个 LAD 的样本均值。就业没有重复出现的月度模式，不做调整。
- **就业插值**：APS 按滚动 12 个月期间发布。每个期间放在中间月份，再插值为月度。因此就业不是独立观测的月度序列。
- **因子代理**：代码中由 `lnsales` 和 `lnemploy` 的截面均值构造。动态设定另加滞后的平均价格及其滞后项。这些量都在 R 中生成，不另存文件。

## 4. 与 v9_8 的差异

- 不含空间滞后，也就不需要空间权重矩阵和 LAD 坐标文件。强截面相关由共同因子代理吸收（正文第 1.1 节）。
- 国别分组只依据 `areacode` 的首字母和 E09 前缀，因此无需地区对照表。v9_8 用的是五个地区组；本文改用四个国别组（英格兰除伦敦、伦敦、苏格兰、威尔士）。
- 日期约定与 v9_8 一致：表中日期为新区制的第一个月。

## 5. 模拟数据

蒙特卡洛数据全部由 `R/03_simulation.R` 按固定种子即时生成，不另存文件。种子规则如下：

- 日期设计：`1e6*j + 1000*N + r`
- 区间设计：`8e6 + 1000*round(1000*d) + 7*N + r`
- 动态设计：`9e6 + 1e5*(混合符号) + 100*N + r`

其中 j 为设计编号，r 为重复编号。
