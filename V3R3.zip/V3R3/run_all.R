# =====================================================================
# run_all.R
# Reproduces every table (Tables/*.tex) and figure (Figures/*.pdf) of
# the paper from data/v9_8_data.csv and the seeds set in the code.
# Usage from this folder:  Rscript --vanilla run_all.R --cores=2
# Base R only (stats, graphics, grDevices, parallel).
# =====================================================================
invisible(Sys.setlocale("LC_TIME", "C"))
RNGkind("Mersenne-Twister", "Inversion", "Rejection")

args <- commandArgs(trailingOnly = TRUE)
cores <- 1
if (any(grepl("^--cores=", args))) cores <- as.integer(sub("^--cores=", "", args[grepl("^--cores=", args)][1]))
file_arg <- commandArgs()[grepl("^--file=", commandArgs())]
root <- if (length(file_arg) > 0) dirname(normalizePath(sub("^--file=", "", file_arg[1]))) else getwd()

for (f in c("01_estimators.R", "02_benchmarks.R", "03_simulation.R",
            "04_application.R", "05_output.R")) source(file.path(root, "R", f))
dir.create(file.path(root, "Tables"), showWarnings = FALSE)
dir.create(file.path(root, "Figures"), showWarnings = FALSE)

# Monte Carlo settings (see Section 6 of the paper)
settings <- list(T = 180, k0 = 90, h = 24, ell = 6, kappa = 0.15, d = 0.5, share = 0.5,
                 trim = 27, N_grid = c(50, 100, 200), R = 100,
                 T_ci = 180, k0_ci = 90, h_ci = 24, ell_ci = 12, d_ci = c(0.2, 0.3),
                 N_ci = c(100, 200), N_dyn = 100)

mc <- run_mc(settings, cores)
app <- run_application(root, h = 24, ell = 6, kappa = settings$kappa)
write_tables(root, mc, app, settings)
write_figures(root, app)
message("Done: tables in Tables/, figures in Figures/.")
