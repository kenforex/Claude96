# 06_estimation_annual.R -- estimation for Section 6 ("From event days to years")
#
# WHAT THIS SCRIPT DOES
#   Takes `dd` (daily) and `mm` (monthly) from 05_data_annual.R and produces
#   the list `ann` with every number reported in Tables 8-10, A3-A5 and
#   Figures 5-6. There are six blocks:
#     1. annual decomposition s = b + q and the renminbi's beta to the dollar
#     2. a daily regression for the dollar leg (what moved the dollar)
#     3. a daily regression for the renminbi against the basket
#     4. monthly regressions: fixing stance, carry and settlement flows
#     5. the attribution of each year's move to factor groups, and shares
#     6. descriptive checks by year and by episode (flows, policy, carry,
#        option skew, balance of payments, event-day responses)
#
# WHERE IT IS CALLED
#   Sourced once from R/00_run_all.R after 05_data_annual.R. Needs `dd`, `mm`,
#   `WIN`, `value_at()` and `ecb_sbq` from 05, and `wts` from 01.
#
# WHICH OUTPUTS DEPEND ON IT
#   07_tables_annual.R (Tables 8, 9, 10, A3, A4, A5) and
#   08_figures_annual.R (Figures 5 and 6) read only from `ann`.

ann <- list()

# ================================================================ helpers
# Newey-West (HAC) standard errors for a fitted lm(), Bartlett kernel, `lag` lags.
# Called by: block 2, block 3, block 4. Contributes to: Tables 9, A5 (t-statistics).
nw_se <- function(fit, lag = 5) {
  X <- model.matrix(fit); u <- residuals(fit); n <- nrow(X)
  S <- crossprod(X * u)                                  # lag 0
  for (L in 1:lag) {
    w <- 1 - L / (lag + 1)
    G <- crossprod(X[(L + 1):n, , drop = FALSE] * u[(L + 1):n], X[1:(n - L), , drop = FALSE] * u[1:(n - L)])
    S <- S + w * (G + t(G))
  }
  XtXi <- solve(crossprod(X))
  V <- XtXi %*% S %*% XtXi
  sqrt(diag(V))
}
# change of a daily series over one of the four windows, in log percent
win_change <- function(df, col, w) 100 * (value_at(df, col, WIN[[w]][2]) - value_at(df, col, WIN[[w]][1]))
YEARS <- names(WIN)

# ================================================================ 1. annual decomposition
# Contributes to: Table 8, Figure 5.
dec <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(dec$year == w)
  dec$s[i] <- win_change(dd, "s", w); dec$b[i] <- win_change(dd, "b", w); dec$q[i] <- win_change(dd, "q", w)
  dec$s_ecb[i] <- win_change(ecb_sbq, "s_ecb", w); dec$b_ecb[i] <- win_change(ecb_sbq, "b_ecb", w); dec$q_ecb[i] <- win_change(ecb_sbq, "q_ecb", w)
  dec$usdcny_start[i] <- exp(value_at(dd, "s", WIN[[w]][1])); dec$usdcny_end[i] <- exp(value_at(dd, "s", WIN[[w]][2]))
  for (k in c("EUR", "JPY", "KRW", "GBP", "AUD", "MYR", "THB", "TWD", "INR"))
    dec[[paste0("vs_usd_", k)]][i] <- -win_change(dd, paste0("x_", k), w)   # + = that currency appreciated vs USD
}
ann$dec <- dec

# Daily changes, in percent, used in blocks 2 and 3
dd$db <- c(NA, 100 * diff(dd$b)); dd$dq <- c(NA, 100 * diff(dd$q)); dd$ds <- c(NA, 100 * diff(dd$s))
dd$d2y <- c(NA, diff(dd$us2y)); dd$dvix <- c(NA, 100 * diff(log(dd$vix))); dd$doil <- c(NA, 100 * diff(log(dd$brent)))
dd$dcarry <- c(NA, diff(dd$carry3m))
lag1 <- function(x) c(NA, x[-length(x)])
dd$db_L <- lag1(dd$db); dd$d2y_L <- lag1(dd$d2y); dd$dvix_L <- lag1(dd$dvix); dd$doil_L <- lag1(dd$doil)
# event dummies by episode
EPI <- c(ev_1819 = "2018-19", ev_2024 = "2020-24", ev_2025 = "2025", ev_2026 = "2026")   # dummy name -> episode
for (nm in names(EPI)) dd[[nm]] <- dd$ev_sign * (dd$episode == EPI[nm])
# a post-2022 shift in the VIX coefficient (the dollar's safe-haven beta is larger after 2022)
dd$post22 <- as.numeric(dd$date >= as.Date("2022-01-01"))
dd$dvix_post <- dd$dvix * dd$post22; dd$dvix_L_post <- dd$dvix_L * dd$post22
# regression sample: 2017-01-04 to 2026-08-31; missing regressors (holidays) set to zero
reg <- dd[dd$date >= as.Date("2017-01-04") & dd$date <= as.Date("2026-08-31"), ]
REGS <- c("d2y", "d2y_L", "dvix", "dvix_L", "dvix_post", "dvix_L_post", "doil", "doil_L", "dcarry",
          "ev_1819", "ev_2024", "ev_2025", "ev_2026", "db", "db_L")
for (v in REGS) reg[[v]][is.na(reg[[v]])] <- 0
reg <- reg[!is.na(reg$db) & !is.na(reg$dq), ]

# The renminbi's beta to the dollar leg (1 + theta), by year: Contributes to Table 8.
beta_year <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(beta_year$year == w)
  sub <- reg[reg$date > as.Date(WIN[[w]][1]) & reg$date <= as.Date(WIN[[w]][2]), ]
  fd <- lm(dq ~ db + db_L, data = sub)                     # daily, with one lag
  beta_year$theta_daily[i] <- sum(coef(fd)[c("db", "db_L")])
  # weekly (Wednesday to Wednesday) changes
  wk <- sub[format(sub$date, "%u") == "3", c("date", "b", "q")]
  wk$db <- c(NA, 100 * diff(wk$b)); wk$dq <- c(NA, 100 * diff(wk$q))
  fw <- lm(dq ~ db, data = wk)
  beta_year$theta_weekly[i] <- coef(fw)["db"]; beta_year$theta_weekly_se[i] <- summary(fw)$coef["db", 2]
}
beta_year$beta_daily <- 1 + beta_year$theta_daily; beta_year$beta_weekly <- 1 + beta_year$theta_weekly
ann$beta_year <- beta_year

# ================================================================ 2. the dollar leg, daily
# db_t = a1 d2y_t + a2 d2y_{t-1} + VIX terms + oil terms + episode x event dummies (no constant)
# Contributes to: Table 9 panel A (coefficients and attribution), Table 10, Figure 6.
fb <- lm(db ~ 0 + d2y + d2y_L + dvix + dvix_L + dvix_post + dvix_L_post + doil + doil_L +
           ev_1819 + ev_2024 + ev_2025 + ev_2026, data = reg)
ann$fb <- data.frame(term = names(coef(fb)), coef = coef(fb), se = nw_se(fb, 5))
ann$fb$t <- ann$fb$coef / ann$fb$se
beta_2y <- sum(coef(fb)[c("d2y", "d2y_L")])                 # % dollar move per pp of U.S. 2-year yield
ann$beta_2y <- beta_2y
# joint NW s.e. of the sum of the two 2y coefficients
{
  X <- model.matrix(fb); u <- residuals(fb); n <- nrow(X); S <- crossprod(X * u)
  for (L in 1:5) { w <- 1 - L / 6; G <- crossprod(X[(L + 1):n, ] * u[(L + 1):n], X[1:(n - L), ] * u[1:(n - L)]); S <- S + w * (G + t(G)) }
  XtXi <- solve(crossprod(X)); V <- XtXi %*% S %*% XtXi; r <- as.numeric(colnames(X) %in% c("d2y", "d2y_L"))
  ann$beta_2y_se <- sqrt(as.numeric(t(r) %*% V %*% r))
}
# contribution of a group of regressors to the fitted change over a window
contrib <- function(fit, df, cols, w) {
  sub <- df[df$date > as.Date(WIN[[w]][1]) & df$date <= as.Date(WIN[[w]][2]), ]
  sum(sapply(cols, function(cc) coef(fit)[cc] * sum(sub[[cc]])))
}
# relative monetary policy: beta_2y x (change in U.S. policy rate - trade-weighted change abroad)
pol <- read.csv("data/policy_rate_changes.csv", stringsAsFactors = FALSE)
POLW <- c(EUR = 0.1634, JPY = 0.1153, KRW = 0.1077, AUD = 0.0440, GBP = 0.0316, CAD = 0.0215)  # CFETS 2017 weights
attr_b <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(attr_b$year == w); p <- pol[pol$window == as.integer(w), ]
  us <- p$change_pp[p$currency == "USD"]
  fo <- sum(POLW * p$change_pp[match(names(POLW), p$currency)]) / sum(POLW)
  attr_b$d_policy_us[i] <- us; attr_b$d_policy_foreign[i] <- fo; attr_b$d_policy_rel[i] <- us - fo
  attr_b$total[i]   <- dec$b[dec$year == w]
  attr_b$policy[i]  <- beta_2y * (us - fo)
  attr_b$vix[i]     <- contrib(fb, reg, c("dvix", "dvix_L", "dvix_post", "dvix_L_post"), w)
  attr_b$oil[i]     <- contrib(fb, reg, c("doil", "doil_L"), w)
  attr_b$tariff[i]  <- contrib(fb, reg, c("ev_1819", "ev_2024", "ev_2025", "ev_2026"), w)
  attr_b$us2y_total[i] <- contrib(fb, reg, c("d2y", "d2y_L"), w)   # for reference: all 2y moves, not only policy
  attr_b$d_us2y[i]  <- value_at(dd, "us2y", WIN[[w]][2]) - value_at(dd, "us2y", WIN[[w]][1])
}
attr_b$other <- attr_b$total - attr_b$policy - attr_b$vix - attr_b$oil - attr_b$tariff
ann$attr_b <- attr_b

# The dollar's beta to the VIX, year by year (safe-haven check, hypothesis B8). Contributes to Table A3.
vix_beta <- data.frame(year = 2017:2026)
for (y in 2017:2026) {
  sub <- reg[reg$year == y, ]
  f <- lm(db ~ d2y + d2y_L + dvix + dvix_L + doil + doil_L, data = sub)
  vix_beta$beta[vix_beta$year == y] <- 100 * sum(coef(f)[c("dvix", "dvix_L")])   # % dollar move per 100% VIX move
}
ann$vix_beta <- vix_beta

# ================================================================ 3. the renminbi against the basket, daily
# dq_t = theta_y (db_t + db_{t-1}) + VIX + oil + episode x event dummies, with theta varying by year
# Contributes to: Table 9 panel B, Table 10, Figure 6.
for (y in 2017:2026) { reg[[paste0("db_", y)]] <- reg$db * (reg$year == y); reg[[paste0("dbL_", y)]] <- reg$db_L * (reg$year == y) }
fq_formula <- as.formula(paste("dq ~ 0 +", paste(c(paste0("db_", 2017:2026), paste0("dbL_", 2017:2026)), collapse = " + "),
                               "+ dvix + doil + ev_1819 + ev_2024 + ev_2025 + ev_2026"))
fq <- lm(fq_formula, data = reg)
ann$fq <- data.frame(term = names(coef(fq)), coef = coef(fq), se = nw_se(fq, 5)); ann$fq$t <- ann$fq$coef / ann$fq$se
theta <- setNames(sapply(2017:2026, function(y) sum(coef(fq)[c(paste0("db_", y), paste0("dbL_", y))])), 2017:2026)
ann$theta <- theta

# ================================================================ 4. monthly regressions
# q* removes the mechanical dollar tracking from q: dq*_t = dq_t - theta_year x db_t, cumulated daily
dd$theta_y <- theta[as.character(dd$year)]
dd$theta_y[is.na(dd$theta_y)] <- 0          # December 2016 (only used for lags) has no estimated theta
dd$dqstar <- ifelse(is.na(dd$dq), 0, dd$dq - dd$theta_y * ifelse(is.na(dd$db), 0, dd$db))
dd$qstar <- cumsum(dd$dqstar) / 100
qstar_eom <- tapply(dd$qstar, dd$ym, function(x) x[length(x)])   # month-end value
mm$qstar <- as.numeric(qstar_eom[mm$ym])
mm$dqstar <- c(NA, 100 * diff(mm$qstar))
# month dummies as controls
for (k in 2:12) mm[[paste0("m", k)]] <- as.numeric(mm$month == k)
MD <- paste0("m", 2:12)
# (a) dq* on flows, fixing stance, carry, VIX and oil. Contributes to Table A5 columns 1-2.
f_m1 <- lm(dqstar ~ net_goods + net_nongoods + dstance + dcarry + dvix + dbrent, data = mm)
mm$net_goods_L <- lag1(mm$net_goods); mm$net_nongoods_L <- lag1(mm$net_nongoods)
f_m2 <- lm(dqstar ~ net_goods_L + net_nongoods_L + dstance + dcarry + dvix + dbrent, data = mm)
ann$f_m1 <- data.frame(term = names(coef(f_m1)), coef = coef(f_m1), se = nw_se(f_m1, 3))
ann$f_m2 <- data.frame(term = names(coef(f_m2)), coef = coef(f_m2), se = nw_se(f_m2, 3))
ann$f_m1$t <- ann$f_m1$coef / ann$f_m1$se; ann$f_m2$t <- ann$f_m2$coef / ann$f_m2$se
ann$r2_m1 <- summary(f_m1)$r.squared; ann$r2_m2 <- summary(f_m2)$r.squared; ann$n_m <- nobs(f_m1)
delta_stance <- coef(f_m1)["dstance"]; delta_carry <- coef(f_m1)["dcarry"]

# (b) IV: net goods settlement instrumented by the customs trade balance. Contributes to Table A5 columns 3-5.
# Two-stage least squares written out by hand.
iv_dat <- mm[complete.cases(mm[, c("dqstar", "net_goods", "cus_bal", "dcarry", "dvix", "dbrent")]), ]
CTRL <- c("dcarry", "dvix", "dbrent", MD)
Xend <- cbind(1, as.matrix(iv_dat[, c("net_goods", CTRL)]))                 # regressors (endogenous first)
Z    <- cbind(1, as.matrix(iv_dat[, c("cus_bal", CTRL)]))                   # instruments
y    <- iv_dat$dqstar
first <- lm(as.formula(paste("net_goods ~ cus_bal +", paste(CTRL, collapse = " + "))), data = iv_dat)
ann$iv_first_coef <- coef(first)["cus_bal"]; ann$iv_first_t <- coef(first)["cus_bal"] / nw_se(first, 3)["cus_bal"]
ann$iv_first_F <- ann$iv_first_t^2
PZ   <- Z %*% solve(crossprod(Z), t(Z))                                     # projection on the instruments
b_iv <- solve(t(Xend) %*% PZ %*% Xend, t(Xend) %*% PZ %*% y)
u_iv <- y - Xend %*% b_iv
V_iv <- as.numeric(crossprod(u_iv) / (nrow(Xend) - ncol(Xend))) * solve(t(Xend) %*% PZ %*% Xend)
gamma_iv <- b_iv[2]; gamma_iv_se <- sqrt(V_iv[2, 2])
ols_same <- lm(as.formula(paste("dqstar ~ net_goods +", paste(CTRL, collapse = " + "))), data = iv_dat)
rf       <- lm(as.formula(paste("dqstar ~ cus_bal +", paste(CTRL, collapse = " + "))), data = iv_dat)
ann$iv <- data.frame(stat = c("IV (2SLS)", "OLS", "Reduced form"),
                     coef = c(gamma_iv, coef(ols_same)["net_goods"], coef(rf)["cus_bal"]),
                     se = c(gamma_iv_se, summary(ols_same)$coef["net_goods", 2], nw_se(rf, 3)["cus_bal"]))
ann$iv$n <- nrow(iv_dat)

# (c) settlement follows past appreciation (hypothesis B5). Contributes to Table A5 column 6.
mm$past3 <- -(lag1(mm$ds) + lag1(lag1(mm$ds)) + lag1(lag1(lag1(mm$ds))))   # CNY appreciation vs USD over the previous 3 months, %
f_b5 <- lm(as.formula(paste("net_goods ~ cus_bal + past3 + carry +", paste(MD, collapse = " + "))), data = mm)
ann$f_b5 <- data.frame(term = names(coef(f_b5)), coef = coef(f_b5), se = nw_se(f_b5, 3)); ann$f_b5$t <- ann$f_b5$coef / ann$f_b5$se
ann$n_b5 <- nobs(f_b5)

# ================================================================ 5. attribution of each year
# Contributes to: Table 9 panel B, Table 10, Figure 6.
GAMMA <- c(low = coef(ols_same)[["net_goods"]], central = gamma_iv, high = -0.02)   # % per USD bn
KAPPA <- c(low = 0.25, central = 0.5, high = 1.0)                                   # pass-through of the fixing stance
mean_goods <- mean(mm$net_goods, na.rm = TRUE); mean_nongoods <- mean(mm$net_nongoods, na.rm = TRUE)
attr_q <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(attr_q$year == w); yr <- as.integer(w)
  ms <- mm[mm$ym > substr(WIN[[w]][1], 1, 7) & mm$ym <= substr(WIN[[w]][2], 1, 7), ]
  m0 <- mm[mm$ym == substr(WIN[[w]][1], 1, 7), ]
  attr_q$total[i]     <- dec$q[dec$year == w]
  attr_q$theta[i]     <- theta[w]
  attr_q$tracking[i]  <- theta[w] * dec$b[dec$year == w]
  attr_q$stance0[i]   <- 100 * m0$stance; attr_q$stance1[i] <- 100 * ms$stance[nrow(ms)]
  attr_q$fixing[i]    <- KAPPA["central"] * (attr_q$stance1[i] - attr_q$stance0[i])
  attr_q$carry0[i]    <- m0$carry; attr_q$carry1[i] <- ms$carry[nrow(ms)]
  attr_q$carry[i]     <- delta_carry * (attr_q$carry1[i] - attr_q$carry0[i])
  attr_q$excess_goods[i]    <- sum(ms$net_goods) - mean_goods * nrow(ms)        # flows above the sample mean
  attr_q$excess_nongoods[i] <- sum(ms$net_nongoods) - mean_nongoods * nrow(ms)
  attr_q$flows_goods[i]     <- GAMMA["central"] * attr_q$excess_goods[i]
  attr_q$flows_nongoods[i]  <- GAMMA["central"] * attr_q$excess_nongoods[i]
  attr_q$tariff[i]    <- contrib(fq, reg, c("ev_1819", "ev_2024", "ev_2025", "ev_2026"), w)
  attr_q$riskoil[i]   <- contrib(fq, reg, c("dvix", "doil"), w)
  # sensitivity ranges
  ex <- attr_q$excess_goods[i] + attr_q$excess_nongoods[i]
  attr_q$flows_low[i] <- GAMMA["low"] * ex; attr_q$flows_high[i] <- GAMMA["high"] * ex
  attr_q$fixing_low[i] <- KAPPA["low"] * (attr_q$stance1[i] - attr_q$stance0[i]); attr_q$fixing_high[i] <- KAPPA["high"] * (attr_q$stance1[i] - attr_q$stance0[i])
}
attr_q$residual <- attr_q$total - with(attr_q, tracking + fixing + carry + flows_goods + flows_nongoods + tariff + riskoil)
ann$attr_q <- attr_q
ann$delta_stance <- delta_stance; ann$delta_carry <- delta_carry; ann$gamma <- GAMMA; ann$kappa <- KAPPA

# USD/CNY = (1 + theta) x dollar-leg items + renminbi-specific items (the tracking term is folded into the dollar items)
attr_s <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(attr_s$year == w); k <- 1 + theta[w]; qb <- attr_b[attr_b$year == w, ]; qq <- attr_q[attr_q$year == w, ]
  attr_s$total[i]        <- dec$s[dec$year == w]
  attr_s$usd_policy[i]   <- k * qb$policy
  attr_s$usd_other[i]    <- k * (qb$other + qb$vix + qb$oil)
  attr_s$tariff[i]       <- k * qb$tariff + qq$tariff
  attr_s$carry[i]        <- qq$carry
  attr_s$flows_goods[i]  <- qq$flows_goods
  attr_s$flows_other[i]  <- qq$flows_nongoods
  attr_s$fixing[i]       <- qq$fixing
  attr_s$riskoil[i]      <- qq$riskoil
  attr_s$residual[i]     <- qq$residual
}
GROUPS <- c("usd_policy", "usd_other", "tariff", "carry", "flows_goods", "flows_other", "fixing", "riskoil", "residual")
attr_s$check <- rowSums(attr_s[, GROUPS])                           # must equal `total`
stopifnot(max(abs(attr_s$check - attr_s$total)) < 1e-6)
share_s <- attr_s; for (g in GROUPS) share_s[[g]] <- 100 * abs(attr_s[[g]]) / rowSums(abs(attr_s[, GROUPS]))
ann$attr_s <- attr_s; ann$share_s <- share_s
QG <- c("tracking", "fixing", "carry", "flows_goods", "flows_nongoods", "tariff", "riskoil", "residual")
share_q <- attr_q; for (g in QG) share_q[[g]] <- 100 * abs(attr_q[[g]]) / rowSums(abs(attr_q[, QG]))
ann$share_q <- share_q
# range of the flow and fixing shares under the low/high parameters (reported in the notes of Table 10)
rng <- data.frame(year = YEARS)
for (w in YEARS) {
  i <- which(rng$year == w); a <- attr_s[attr_s$year == w, ]; q <- attr_q[attr_q$year == w, ]
  for (g in c("low", "high")) {
    fl <- q[[paste0("flows_", g)]]; fx <- q[[paste0("fixing_", g)]]
    res <- a$total - (a$usd_policy + a$usd_other + a$tariff + a$carry + a$riskoil + fl + fx)
    tot <- sum(abs(c(a$usd_policy, a$usd_other, a$tariff, a$carry, a$riskoil, fl, fx, res)))
    rng[[paste0("flows_share_", g)]][i] <- 100 * abs(fl) / tot
    rng[[paste0("fixing_share_", g)]][i] <- 100 * abs(fx) / tot
  }
}
ann$share_range <- rng

# ================================================================ 6. descriptive checks
# (a) trade and settlement flows by year. Contributes to Table A3 panel A.
sfk <- read.csv("data/safe_receipts_payments_monthly.csv", stringsAsFactors = FALSE)
flow_year <- function(y, months = 12) {
  j <- jsh[jsh$year == y & jsh$month <= months, ]; k <- sfk[sfk$year == y & sfk$month <= months, ]; cc <- cus[cus$year == y & cus$month <= months, ]
  data.frame(year = if (months == 12) as.character(y) else paste0(y, " Jan-", month.abb[months]),
             customs_surplus = sum(cc$balance_usd_bn), exports = sum(cc$exports_usd_bn),
             net_settle_goods = sum(j$js_goods - j$ss_goods) / 10,
             SR = sum(j$js_goods) / sum(k$rec_goods), PR = sum(j$ss_goods) / sum(k$pay_goods),
             rmb_share_rec = sum(k$rec_rmb) / sum(k$rec_all), rmb_share_pay = sum(k$pay_rmb) / sum(k$pay_all),
             cfets_client_net = sum(cc$cfets_client_sell_fx_usd_bn - cc$cfets_client_buy_fx_usd_bn),
             net_fwd = sum(j$fwd_sign_js - j$fwd_sign_ss) / 10)
}
ann$flows <- rbind(flow_year(2017), flow_year(2018), flow_year(2019), flow_year(2024), flow_year(2025), flow_year(2026, 8))
# (b) fixing stance and the daily follow-through of the fixing, by year. Contributes to Table A3 panel B.
pol_year <- data.frame(year = 2017:2026)
for (y in 2017:2026) {
  i <- which(pol_year$year == y); sub <- dd[dd$year == y & !is.na(dd$stance), ]
  pol_year$stance_mean_bp[i] <- 1e4 * mean(sub$stance)
  pol_year$stance_dec_bp[i]  <- 1e4 * mean(sub$stance[format(sub$date, "%m") == ifelse(y == 2026, "08", "12")])
  # rho: how much of yesterday's market move (vs the previous fixing) is passed into today's fixing
  sub$df <- c(NA, diff(sub$f)); sub$gap <- sub$s_lag - c(NA, sub$f[-nrow(sub)])
  pol_year$rho[i] <- coef(lm(df ~ gap, data = sub))["gap"]
}
ann$pol_year <- pol_year
# (c) carry by year. Contributes to Table A3 panel C.
dep <- read.csv("data/pboc_usd_deposit_rates.csv", stringsAsFactors = FALSE)
carry_year <- data.frame(year = 2017:2026)
for (y in carry_year$year) {
  i <- which(carry_year$year == y); sub <- dd[dd$year == y, ]
  carry_year$shibor3m[i] <- mean(sub$shibor3m, na.rm = TRUE); carry_year$us3m[i] <- mean(sub$us3m, na.rm = TRUE)
  carry_year$carry3m[i] <- carry_year$shibor3m[i] - carry_year$us3m[i]
  s1y <- tapply(sub$shibor1y, sub$ym, mean, na.rm = TRUE); d1y <- dep$usd_dep_1y[match(names(s1y), dep$month)]
  carry_year$carry1y_dep[i] <- mean(s1y - d1y, na.rm = TRUE)       # Shibor 1Y minus PBoC large USD deposit rate 1Y
}
ann$carry_year <- carry_year
# (d) option skew (derived from licensed data) and balance of payments. Contributes to Table A3 panels C-D.
ann$rr <- read.csv("data/cnh_rr25_annual.csv", stringsAsFactors = FALSE)
ann$bop <- read.csv("data/bop_annual_usd_bn.csv", stringsAsFactors = FALSE, row.names = 1)
# (e) event-day responses by episode (two-day window, signed by the direction of the news). Contributes to Table A4.
evr <- data.frame()
for (i in seq_len(nrow(ev_all))) {
  if (ev_all$sign[i] == 0) next
  j <- match(ev_all$rdate[i], dd$date); if (is.na(j) || j + 1 > nrow(dd)) next
  sg <- ev_all$sign[i]
  evr <- rbind(evr, data.frame(episode = ev_all$war[i],
    db = sg * 100 * (dd$b[j + 1] - dd$b[j - 1]), dq = sg * 100 * (dd$q[j + 1] - dd$q[j - 1]), ds = sg * 100 * (dd$s[j + 1] - dd$s[j - 1]),
    d2y = sg * 100 * (dd$us2y[j + 1] - dd$us2y[j - 1]), dvix = sg * 100 * (log(dd$vix[j + 1]) - log(dd$vix[j - 1]))))
}
summ <- function(x) c(mean = mean(x, na.rm = TRUE), t = mean(x, na.rm = TRUE) / sd(x, na.rm = TRUE) * sqrt(sum(!is.na(x))))
ann$evr <- do.call(rbind, lapply(split(evr, evr$episode), function(e) data.frame(episode = e$episode[1], n = nrow(e),
  db = summ(e$db)["mean"], db_t = summ(e$db)["t"], ds = summ(e$ds)["mean"], ds_t = summ(e$ds)["t"], dq = summ(e$dq)["mean"], dq_t = summ(e$dq)["t"],
  d2y = summ(e$d2y)["mean"], d2y_t = summ(e$d2y)["t"], dvix = summ(e$dvix)["mean"], dvix_t = summ(e$dvix)["t"])))
# (f) a few dated windows quoted in the text
windows <- list(`Liberation Day, 1-21 Apr 2025` = c("2025-04-01", "2025-04-21"), `Iran war, 27 Feb-31 Mar 2026` = c("2026-02-27", "2026-03-31"),
                `Jun-Aug 2018 escalation` = c("2018-06-14", "2018-08-03"), `Aug 2019 break of 7` = c("2019-08-01", "2019-09-03"))
ann$windows <- do.call(rbind, lapply(names(windows), function(n) { a <- windows[[n]]
  data.frame(window = n, db = 100 * (value_at(dd, "b", a[2]) - value_at(dd, "b", a[1])), dq = 100 * (value_at(dd, "q", a[2]) - value_at(dd, "q", a[1])),
             ds = 100 * (value_at(dd, "s", a[2]) - value_at(dd, "s", a[1])), d2y_bp = 100 * (value_at(dd, "us2y", a[2]) - value_at(dd, "us2y", a[1])),
             dvix = value_at(dd, "vix", a[2]) - value_at(dd, "vix", a[1])) }))
