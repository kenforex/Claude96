# 01_data.R -- build the daily exchange-rate panel and the event-window data set
#
# WHAT THIS SCRIPT DOES
#   Reads four data files and builds three objects that every later script uses:
#     `daily` : one row per ECB business day (2017-01 to 2026-08) with the log
#               USD/CNY rate s, the dollar leg b (three basket versions) and the
#               renminbi against the basket q = s - b
#     `ev`    : the 68 retained tariff-news events with their codes and intensity
#     `win`   : one row per event and horizon h = 1..10 with the change of every
#               outcome over the event window, plus overlap clusters
#   It also defines `wts` (basket weights) and `basket_w()`, reused in 05.
#
# WHERE IT IS CALLED
#   Sourced first from R/00_run_all.R. Nothing is written to disk.
#
# WHICH OUTPUTS DEPEND ON IT
#   Every table and figure: Tables 1-5 and A1-A2 directly, Tables 6-7 through
#   02_estimation.R, Figures 1-3 and A1-A2 through 04_figures.R; the ECB
#   cross-check rows of Table 8 through 05_data_annual.R.
#
# Inputs : data/ecb_eurofxref_hist.csv, data/cfets_basket_weights.csv,
#          data/events.csv, data/us_china_trade.csv

# ---------------------------------------------------------------- exchange rates
ecb <- fread("data/ecb_eurofxref_hist.csv", na.strings = c("N/A", ""))
ecb <- ecb[, !grepl("^V[0-9]+$", names(ecb)), with = FALSE]
ecb[, Date := as.IDate(Date)]
setorder(ecb, Date)
ecb <- ecb[Date >= as.IDate("2017-01-01") & Date <= as.IDate("2026-08-31")]   # v2: extended to Aug 2026 (used only by Section 6)

# Currencies of the non-dollar CFETS basket that the ECB quotes. Dollar pegs
# (HKD, SAR, AED, MOP) are part of the dollar leg and are excluded; RUB is
# excluded because the ECB suspended its quotation on 1 March 2022.
BASKET  <- c("EUR", "JPY", "KRW", "AUD", "MYR", "SGD", "GBP", "THB", "CAD",
             "ZAR", "CHF", "MXN", "TRY", "PLN", "SEK", "NZD", "DKK", "HUF", "NOK")
# Wider cross-section used only to estimate the latent dollar factor
FACTOR  <- c(BASKET, "CZK", "ILS", "INR", "IDR", "PHP", "BRL")

# per_usd(k): log units of currency k per U.S. dollar (the ECB quotes units of k
# per euro, so we divide by the euro-dollar rate). Called only in this script,
# once per currency, to build `daily`. Feeds every exchange-rate outcome.
per_usd <- function(k) if (k == "EUR") -log(ecb$USD) else log(ecb[[k]]) - log(ecb$USD)
daily <- data.table(date = ecb$Date, s = per_usd("CNY"))
for (k in FACTOR) daily[, (paste0("x_", k)) := per_usd(k)]
stopifnot(!anyNA(daily))

# basket weights: non-dollar CFETS weights renormalised over BASKET
wts <- fread("data/cfets_basket_weights.csv")
# basket_w(v): the CFETS weights of vintage v, restricted to BASKET and
# renormalised to sum to one. Called here for the 2017 and 2026 vintages;
# the same logic is repeated for the 16-currency H.10 basket in 05_data_annual.R.
# Feeds the dollar leg b (Tables 2-5, Figures 1-3) and Table A2.
basket_w <- function(v) {
  w <- wts[vintage == v & currency %in% BASKET]
  stopifnot(nrow(w) == length(BASKET))
  setNames(w$weight / sum(w$weight), w$currency)
}
W17 <- basket_w(2017)        # baseline: vintage in force in 2018-19, held fixed
W26 <- basket_w(2026)        # robustness: latest fully published vintage
W3  <- c(EUR = 1/3, JPY = 1/3, KRW = 1/3)
# bleg(w): the dollar leg, a weighted average of log dollar prices with weights w.
# Called three times below (2017 basket, 2026 basket, equal-weighted EUR/JPY/KRW).
# Feeds b, q and their robustness versions (Tables 3-5, Figures 1-3).
bleg <- function(w) as.vector(as.matrix(daily[, paste0("x_", names(w)), with = FALSE]) %*% w)
daily[, b    := bleg(W17)]   # dollar leg: log basket units per USD
daily[, b26  := bleg(W26)]
daily[, b3   := bleg(W3)]
daily[, q    := s - b]       # RMB-specific: log CNY per basket unit
daily[, q26  := s - b26]
daily[, q3   := s - b3]

# ---------------------------------------------------------------- events
ev <- fread("data/events.csv")
ev[, event_date := as.IDate(event_date)]
ev <- ev[retained == TRUE]
stopifnot(nrow(ev) == 68, ev[war == "2018-19", .N] == 30, ev[war == "2025", .N] == 38)
setorder(ev, event_date, event_id)

trade <- fread("data/us_china_trade.csv")
bil_trade <- trade[, .(year, total_bn = (us_exports_to_china_usd_mn + us_imports_from_china_usd_mn) / 1000)]
ev[, base_year := ifelse(war == "2018-19", 2017L, 2024L)]
ev <- merge(ev, bil_trade, by.x = "base_year", by.y = "year", all.x = TRUE, sort = FALSE)
setorder(ev, event_date, event_id)
# headline tariff intensity: announced change in taxed bilateral trade, % of bilateral trade
ev[, dose := 100 * taxed_value_usd_bn / total_bn]
ev[, sdose := sign(dose) * log1p(abs(dose))]
ev[, actor := fifelse(l_bil < 0, "De-escalation",
               fifelse(l_bil > 0 & category == "china_retaliation", "China retaliation",
               fifelse(l_bil > 0 & category == "mixed_package", "Joint package",
               fifelse(l_bil > 0, "U.S. escalation", "No bilateral news"))))]

# ---------------------------------------------------------------- windows
# The window opens at the last ECB fixing (14:10 CET) strictly before the event
# date and closes at the h-th fixing after it, so it contains the whole event
# day in Washington and Beijing whatever the (unrecorded) release time.
H    <- c(1L, 2L, 3L, 5L, 10L)
HALL <- 1:10
dates <- daily$date
win <- rbindlist(lapply(HALL, function(h) {
  ev[, {
    i0 <- findInterval(event_date - 1L, dates)           # last date < event_date
    i1 <- findInterval(event_date, dates) + h             # h-th date > event_date
    .(event_id, war, event_date, l_bil, l_row, dose, sdose, actor, category,
      h = h, t_pre = dates[i0], t_h = dates[i1], i0 = i0, i1 = i1)
  }]
}))
stopifnot(!anyNA(win$t_h))
OUT <- c("s", "b", "q", "b26", "q26", "b3", "q3")
for (v in OUT) win[, (v) := 1e4 * (daily[[v]][i1] - daily[[v]][i0])]

# later bilateral news inside the window (future-shock control)
win[, f_bil := mapply(function(id, d, th, w) ev[war == w & event_date > d & event_date <= th, sum(l_bil)],
                      event_id, event_date, t_h, war)]

# overlap clusters by horizon: chains of events whose windows overlap
win[, cluster := {
  o <- order(t_pre); cl <- integer(.N); k <- 0L; end <- as.IDate(NA)
  for (i in o) { if (is.na(end) || t_pre[i] >= end) k <- k + 1L; cl[i] <- k
                 end <- if (is.na(end) || t_pre[i] >= end) t_h[i] else max(end, t_h[i]) }
  paste0(war, "-", cl)
}, by = .(h, war)]
