# 00_run_all.R -- reproduces every table and figure of JIE_v2.tex
#
# Run from the package root:   Rscript R/00_run_all.R
# Requires R >= 4.1 with data.table, ggplot2 and scales. Nothing else.
#
# The eight scripts run in order and pass objects in memory; the only things
# written to disk are the .tex files in tables/ and the .pdf files in figures/.
#
#   01_data.R                daily ECB panel, events, event windows      (Sections 4-5)
#   02_estimation.R          local projections, bootstrap, robustness    (Sections 5)
#   03_tables.R              Tables 1-7, A1, A2
#   04_figures.R             Figures 1-4, A1, A2
#   05_data_annual.R         daily H.10 panel and monthly flows          (Section 6, new in v2)
#   06_estimation_annual.R   annual decomposition, attribution, checks   (Section 6, new in v2)
#   07_tables_annual.R       Tables 8-10, A3-A6
#   08_figures_annual.R      Figures 5-6
suppressPackageStartupMessages({ library(data.table); library(ggplot2) })
SEED  <- 20260924L   # all random draws
B_WCB <- 9999L       # wild cluster bootstrap replications
R_RI  <- 2000L       # randomisation-inference draws
t0 <- Sys.time()
source("R/01_data.R")
source("R/02_estimation.R")
source("R/03_tables.R")
source("R/04_figures.R")
source("R/05_data_annual.R")
source("R/06_estimation_annual.R")
source("R/07_tables_annual.R")
source("R/08_figures_annual.R")
cat(sprintf("Done in %.1f minutes: %d tables in tables/, %d figures in figures/\n",
            as.numeric(difftime(Sys.time(), t0, units = "mins")),
            length(list.files("tables", "\\.tex$")), length(list.files("figures", "\\.pdf$"))))
