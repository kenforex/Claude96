# 05_data_annual.R -- data for the new Section 6 ("From event days to years")
#
# WHAT THIS SCRIPT DOES
#   Builds two plain data frames that the rest of the Section 6 code uses:
#     `dd`  : one row per trading day, 2016-12 to 2026-08, with the bilateral
#             rate s, the dollar leg b, the renminbi-vs-basket q (both from the
#             Fed H.10 noon rates and, for cross-checking, from the ECB rates),
#             the central parity, U.S. and Chinese interest rates, VIX, Brent
#             and the tariff-event dummies.
#     `mm`  : one row per month, 2017-01 to 2026-08, with exchange-rate changes,
#             the fixing stance, the carry, and SAFE bank settlement flows.
#
# WHERE IT IS CALLED
#   Sourced once from R/00_run_all.R, after 01-04 (the event-study part) and
#   before 06_estimation_annual.R. It needs `ev` (events) and `daily` (the ECB
#   panel) from 01_data.R and the helper `basket_w()` defined there.
#
# WHICH OUTPUTS DEPEND ON IT
#   Everything in Tables 8-10, A3-A5 and Figures 5-6, through 06-08.
#
# STYLE NOTE
#   Written with base R data frames and simple loops so that every step can be
#   followed line by line. No file is written here; objects stay in memory.

# ---------------------------------------------------------------- 1. Fed H.10 exchange rates
# Fed H.10 noon buying rates in New York, units of foreign currency per USD.
# Noon New York on calendar day t is about 00:00-01:00 Beijing on day t+1, i.e.
# BEFORE the 09:15 central parity of day t+1. We use that timing below.
h10 <- read.csv("data/fed_h10_daily.csv", stringsAsFactors = FALSE)
h10$date <- as.Date(h10$date)
h10 <- h10[order(h10$date), ]

# The H.10 basket: the 2017 CFETS currencies that the Fed quotes, minus the
# dollar pegs (HKD, SAR, AED belong to the dollar leg) and minus the four
# currencies the Fed does not quote (RUB, TRY, PLN, HUF). Weights are the 2017
# CFETS weights renormalised over these 16 currencies, exactly as 01_data.R
# does for the 19-currency ECB basket.
H10_BASKET <- c("EUR", "JPY", "KRW", "AUD", "MYR", "SGD", "GBP", "THB", "CAD",
                "ZAR", "CHF", "MXN", "SEK", "NZD", "DKK", "NOK")
w16 <- wts[wts$vintage == 2017 & wts$currency %in% H10_BASKET, ]
w16 <- setNames(w16$weight / sum(w16$weight), w16$currency)

# log price of the dollar in each currency
lx <- log(h10[, H10_BASKET])
dd <- data.frame(date = h10$date,
                 s = log(h10$CNY),                               # log USD/CNY
                 b = as.vector(as.matrix(lx) %*% w16[H10_BASKET])) # dollar leg
dd$q <- dd$s - dd$b                                               # renminbi vs basket
# keep only days on which the Fed quotes the renminbi and every basket currency
keep <- !is.na(dd$s) & !is.na(dd$b)
h10 <- h10[keep, ]; dd <- dd[keep, ]; rownames(dd) <- NULL
# a few bilateral rates for the "other currencies" columns of Table 8
for (k in c("EUR", "JPY", "KRW", "GBP", "AUD", "MYR", "THB", "TWD", "INR"))
  dd[[paste0("x_", k)]] <- log(h10[[k]])

# ---------------------------------------------------------------- 2. ECB cross-check series
# `daily` (from 01_data.R) already holds s, b, q from the ECB rates with the
# 19-currency basket. We only need them at a few year-end dates.
ecb_sbq <- data.frame(date = as.Date(daily$date), s_ecb = daily$s, b_ecb = daily$b, q_ecb = daily$q)

# ---------------------------------------------------------------- 3. central parity and the fixing stance
fix <- read.csv("data/cny_fixing_daily.csv", stringsAsFactors = FALSE)
fix$date <- as.Date(fix$date)
dd$f <- log(fix$fixing_usdcny[match(dd$date, fix$date)])
# Fixing stance: log fixing on day t minus the log H.10 rate of day t-1 (the
# last market price before the fixing). Negative = fixing stronger for the
# renminbi than the market, i.e. the PBoC leans against depreciation.
dd$s_lag <- c(NA, dd$s[-nrow(dd)])
dd$stance <- dd$f - dd$s_lag

# ---------------------------------------------------------------- 4. interest rates, VIX, oil
# helper: attach a daily series by date, then carry the last value forward
# over gaps of up to 5 trading days (U.S. or Chinese holidays)
attach_series <- function(df, src, src_date, src_value, name) {
  v <- src[[src_value]][match(df$date, as.Date(src[[src_date]]))]
  v <- suppressWarnings(as.numeric(v))
  for (i in 2:length(v)) if (is.na(v[i]) && !is.na(v[i - 1])) {
    # fill forward only if the gap is short
    gap <- 1; j <- i
    while (j < length(v) && is.na(v[j]) && gap <= 5) { v[j] <- v[i - 1]; j <- j + 1; gap <- gap + 1 }
  }
  df[[name]] <- v
  df
}
fred   <- read.csv("data/fred_rates_daily.csv", stringsAsFactors = FALSE)
shibor <- read.csv("data/shibor_daily.csv", stringsAsFactors = FALSE)
vix    <- read.csv("data/vix_daily.csv", stringsAsFactors = FALSE)
brent  <- read.csv("data/brent_daily.csv", stringsAsFactors = FALSE)
dd <- attach_series(dd, fred,   "date", "DGS2",      "us2y")     # U.S. 2-year Treasury yield
dd <- attach_series(dd, fred,   "date", "DGS3MO",    "us3m")     # U.S. 3-month Treasury yield
dd <- attach_series(dd, shibor, "date", "M3",        "shibor3m") # Shibor 3 months
dd <- attach_series(dd, shibor, "date", "Y1",        "shibor1y") # Shibor 1 year
dd <- attach_series(dd, vix,    "date", "vix_close", "vix")
dd <- attach_series(dd, brent,  "date", "brent_usd", "brent")
dd$carry3m <- dd$shibor3m - dd$us3m   # Chinese minus U.S. 3-month rate, pp

# ---------------------------------------------------------------- 5. tariff events (all four episodes)
# The 68 events of 2018-19 and 2025 come from `ev` (01_data.R). The 2020-24 and
# 2026 events come from data/events_extension.csv (same coding rule).
ext <- read.csv("data/events_extension.csv", stringsAsFactors = FALSE)
ext <- ext[ext$retained == "True" | ext$retained == TRUE, ]
ev_all <- rbind(data.frame(event_date = as.Date(ev$event_date), war = ev$war, l_bil = ev$l_bil, l_row = ev$l_row),
                data.frame(event_date = as.Date(ext$event_date), war = ext$war, l_bil = ext$l_bil, l_row = ext$l_row))
ev_all$sign <- sign(ev_all$l_bil + ev_all$l_row)         # +1 escalation, -1 de-escalation, 0 none
# reaction day: the event date if it is a trading day, otherwise the next one
ev_all$rdate <- dd$date[findInterval(ev_all$event_date - 1, dd$date) + 1]
dd$ev_sign <- 0
for (i in seq_len(nrow(ev_all))) {
  j <- match(ev_all$rdate[i], dd$date)
  if (!is.na(j)) dd$ev_sign[j] <- max(-1, min(1, dd$ev_sign[j] + ev_all$sign[i]))
}
# episode labels used for the event dummies in 06
dd$year <- as.integer(format(dd$date, "%Y"))
dd$episode <- ifelse(dd$year <= 2019, "2018-19", ifelse(dd$year <= 2024, "2020-24", ifelse(dd$year == 2025, "2025", "2026")))

# ---------------------------------------------------------------- 6. monthly panel
# month-end values of the daily series
dd$ym <- format(dd$date, "%Y-%m")
last_in_month <- !duplicated(dd$ym, fromLast = TRUE)
mm <- data.frame(ym = dd$ym[last_in_month],
                 s = dd$s[last_in_month], b = dd$b[last_in_month], q = dd$q[last_in_month])
# monthly means of the stance and the carry (less noisy than month-end values)
mm$stance <- tapply(dd$stance, dd$ym, mean, na.rm = TRUE)[mm$ym]
mm$carry  <- tapply(dd$carry3m, dd$ym, mean, na.rm = TRUE)[mm$ym]
mm$vix    <- log(tapply(dd$vix, dd$ym, mean, na.rm = TRUE)[mm$ym])
mm$brent  <- log(tapply(dd$brent, dd$ym, mean, na.rm = TRUE)[mm$ym])
# first differences, in percent for the exchange rates
mm$ds <- c(NA, 100 * diff(mm$s)); mm$db <- c(NA, 100 * diff(mm$b)); mm$dq <- c(NA, 100 * diff(mm$q))
mm$dstance <- c(NA, 100 * diff(mm$stance)); mm$dcarry <- c(NA, diff(mm$carry))
mm$dvix <- c(NA, 100 * diff(mm$vix)); mm$dbrent <- c(NA, 100 * diff(mm$brent))

# SAFE bank settlement and sales (USD 100 million in the source; here USD billion)
jsh <- read.csv("data/safe_settlement_monthly.csv", stringsAsFactors = FALSE)
jsh$ym <- sprintf("%d-%02d", jsh$year, jsh$month)
jsh$net_goods    <- (jsh$js_goods - jsh$ss_goods) / 10            # net settlement, goods trade
jsh$net_nongoods <- (jsh$js_services - jsh$ss_services + jsh$js_capital - jsh$ss_capital) / 10
jsh$net_fwd      <- (jsh$fwd_sign_js - jsh$fwd_sign_ss) / 10      # net forward contracts signed
mm$net_goods    <- jsh$net_goods[match(mm$ym, jsh$ym)]
mm$net_nongoods <- jsh$net_nongoods[match(mm$ym, jsh$ym)]
mm$net_fwd      <- jsh$net_fwd[match(mm$ym, jsh$ym)]
# customs trade balance (instrument for net settlement) and CFETS client flows
cus <- read.csv("data/customs_cfets_monthly.csv", stringsAsFactors = FALSE)
cus$ym <- sprintf("%d-%02d", cus$year, cus$month)
mm$cus_bal <- cus$balance_usd_bn[match(mm$ym, cus$ym)]
mm$month <- as.integer(substr(mm$ym, 6, 7))
mm$year  <- as.integer(substr(mm$ym, 1, 4))
mm <- mm[mm$ym >= "2017-01" & mm$ym <= "2026-08", ]
rownames(mm) <- NULL

# ---------------------------------------------------------------- 7. the four annual windows
# Each window runs from the last trading day of the previous year to the last
# trading day of the year (2026: to 31 August 2026, the last month with SAFE data).
WIN <- list(`2018` = c("2017-12-29", "2018-12-31"), `2019` = c("2018-12-31", "2019-12-31"),
            `2025` = c("2024-12-31", "2025-12-31"), `2026` = c("2025-12-31", "2026-08-31"))
# value of a column of `df` on or before a date
value_at <- function(df, col, d) { x <- df[[col]][df$date <= as.Date(d)]; x <- x[!is.na(x)]; x[length(x)] }
