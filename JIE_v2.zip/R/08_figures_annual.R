# 08_figures_annual.R -- writes the two Section 6 figures into figures/
#
# WHAT THIS SCRIPT DOES
#   figures/fig_annual_decomp.pdf  Figure 5: the annual change in USD/CNY split into the
#                                  dollar leg and the renminbi against the basket, four years
#   figures/fig_attribution.pdf    Figure 6: contributions of the factor groups of Table 10
#                                  to the annual change in USD/CNY (stacked bars)
#
# WHERE IT IS CALLED
#   Sourced once from R/00_run_all.R after 07. Reads only `ann`, and reuses
#   `theme_paper`, `FONT` and `save()` from 04_figures.R.

# ---------------------------------------------------------------- Figure 5: annual decomposition
dec <- ann$dec
f5 <- rbind(data.frame(year = dec$year, series = "USD/CNY", value = dec$s),
            data.frame(year = dec$year, series = "Dollar leg", value = dec$b),
            data.frame(year = dec$year, series = "Renminbi against the basket", value = dec$q))
f5$year <- factor(YL[f5$year], levels = YL)
f5$series <- factor(f5$series, levels = c("USD/CNY", "Dollar leg", "Renminbi against the basket"))
p5 <- ggplot(f5, aes(year, value, fill = series)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_col(position = position_dodge(width = 0.75), width = 0.7) +
  scale_fill_manual(values = c("black", "#B8860B", "#8B1A1A")) +
  labs(x = NULL, y = "Log change over the window (%); positive = renminbi weaker / dollar stronger") + theme_paper
save(p5, "fig_annual_decomp.pdf", 6.5, 3.0)

# ---------------------------------------------------------------- Figure 6: attribution of USD/CNY
a <- ann$attr_s
lab <- c(usd_policy = "Dollar: relative monetary policy", usd_other = "Dollar: risk premium and other", tariff = "Tariff news (event days)",
         carry = "Interest differential (carry)", flows_goods = "Net FX settlement: goods trade", flows_other = "Net FX settlement: services and capital",
         fixing = "PBoC fixing stance", riskoil = "Risk sentiment and oil", residual = "Unexplained")
f6 <- do.call(rbind, lapply(names(lab), function(g) data.frame(year = a$year, group = unname(lab[g]), value = a[[g]])))
f6$year <- factor(YL[f6$year], levels = YL); f6$group <- factor(f6$group, levels = lab)
tot <- data.frame(year = factor(YL[a$year], levels = YL), total = a$total)
PAL <- c("#1F5A99", "#7FA8D8", "#B03A2E", "#B8860B", "#1A9E8A", "#8FD3C7", "#6A3D9A", "#CAB2D6", "grey70")
p6 <- ggplot(f6, aes(year, value, fill = group)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_col(width = 0.6) +
  geom_point(data = tot, aes(year, total), inherit.aes = FALSE, shape = 18, size = 3) +
  scale_fill_manual(values = PAL) +
  guides(fill = guide_legend(ncol = 3)) +
  labs(x = NULL, y = "Contribution to log change in USD/CNY (%)") + theme_paper
save(p6, "fig_attribution.pdf", 6.5, 3.8)
