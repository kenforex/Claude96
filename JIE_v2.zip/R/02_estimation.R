# 02_estimation.R -- event-window local projections, decomposition, inference
#
# WHAT THIS SCRIPT DOES
#   Estimates everything in Sections 5.2-5.7 and stores it in the list `est`:
#     est$lp       local projections by outcome and horizon        (Tables 2-3, Figure 2)
#     est$rob      robustness specifications                       (Table 4)
#     est$act      responses by type of news                       (Table 5, panel A)
#     est$dose     responses to headline tariff intensity          (Table 5, panel B)
#     est$ri       randomisation inference                         (Tables 2-3, Figure A1)
#     est$loo      leave-one-cluster-out estimates                 (Figure A2)
#     est$fix_*    central-parity support                          (Table 7, Figure 4)
#     est$fwd      forward-premium estimates (licensed data)       (Table 6)
#
# WHERE IT IS CALLED
#   Sourced second from R/00_run_all.R, after 01_data.R. Nothing is written to disk.
#
# WHICH OUTPUTS DEPEND ON IT
#   03_tables.R (Tables 2-7) and 04_figures.R (Figures 2-4, A1, A2) read `est`.

WEBB <- c(-sqrt(1.5), -1, -sqrt(0.5), sqrt(0.5), 1, sqrt(1.5))

# wcb(y, X, cl, R): wild cluster bootstrap for one linear combination R'beta of
# the OLS coefficients of y on X, with clusters cl and Webb's six-point weights.
#   p-value : restricted bootstrap-t (null R'beta = 0 imposed, WCR)
#   interval: unrestricted symmetric percentile-t (WCU)
# The seed is reset in every call, so each result is reproducible on its own.
# Called by event_reg() (three times per regression: 2018-19 slope, 2025 slope,
# difference). Feeds every bootstrap p-value and interval in Tables 2-5 and 7
# and the error bars of Figure 2.
wcb <- function(y, X, cl, R, B = B_WCB, seed = SEED) {
  n <- length(y); k <- ncol(X)
  XtXi <- solve(crossprod(X))
  bh <- XtXi %*% crossprod(X, y); u <- as.vector(y - X %*% bh)
  a  <- as.vector(t(R) %*% XtXi %*% t(X))
  g  <- as.integer(factor(cl)); G <- max(g)
  cf <- G / (G - 1) * (n - 1) / (n - k)
  sef <- function(E) sqrt(cf * colSums(rowsum(a * E, g)^2))
  est <- sum(R * bh); se <- sef(matrix(u))
  RXR <- as.numeric(t(R) %*% XtXi %*% R)
  br <- bh - XtXi %*% R %*% (sum(R * bh) / RXR)
  ur <- as.vector(y - X %*% br)
  set.seed(seed)
  Wi <- matrix(sample(WEBB, G * B, replace = TRUE), G, B)[g, , drop = FALSE]
  sim <- function(beta, res, centre) {
    Ys <- as.vector(X %*% beta) + res * Wi
    Bs <- XtXi %*% crossprod(X, Ys)
    (colSums(R * Bs) - centre) / sef(Ys - X %*% Bs)
  }
  t0 <- est / se
  p  <- mean(abs(sim(br, ur, 0)) >= abs(t0))
  cr <- as.numeric(quantile(abs(sim(bh, u, est)), 0.95))
  list(est = est, se = se, lo = est - cr * se, hi = est + cr * se, p = p, n = n, G = G)
}

# design(d, regs): the regressor matrix of equation (3): a war intercept and a
# war-specific slope for each variable in `regs` (a column is dropped when it is
# identically zero, e.g. rest-of-world news in 2018-19). Called by event_reg(),
# ri() and the leave-one-out block. Feeds Tables 2-5 and 7, Figures 2, A1, A2.
design <- function(d, regs) {
  X <- cbind(`a:2018-19` = as.numeric(d$war == "2018-19"), `a:2025` = as.numeric(d$war == "2025"))
  for (r in regs) for (w in c("2018-19", "2025")) {
    col <- d[[r]] * (d$war == w)
    if (any(col != 0)) { X <- cbind(X, col); colnames(X)[ncol(X)] <- paste0(r, ":", w) }
  }
  X
}

# event_reg(d, y, regs, key, cl): runs equation (3) for outcome y on the event
# data d and returns the 2018-19 slope, the 2025 slope and their difference for
# the regressor `key`, each with wild-bootstrap inference. Called in blocks 1-3
# and 6 below. Feeds Tables 2-5 and 7 and Figure 2.
event_reg <- function(d, y, regs = c("l_bil", "l_row"), key = "l_bil", cl = d$cluster) {
  X <- design(d, regs); yy <- d[[y]]
  sel <- function(v) { R <- setNames(numeric(ncol(X)), colnames(X)); R[names(v)] <- v; R }
  k18 <- paste0(key, ":2018-19"); k25 <- paste0(key, ":2025")
  out <- list(
    w18  = wcb(yy, X, cl, sel(setNames(1, k18))),
    w25  = wcb(yy, X, cl, sel(setNames(1, k25))),
    diff = wcb(yy, X, cl, sel(setNames(c(-1, 1), c(k18, k25)))))
  out$G18 <- uniqueN(cl[d$war == "2018-19"]); out$G25 <- uniqueN(cl[d$war == "2025"])
  out
}
# flat(r, ...): turns the list returned by event_reg() into a three-row table
# (w18, w25, diff) with the labels passed in `...`. Called after every
# event_reg(). Feeds the same outputs as event_reg().
flat <- function(r, ...) {
  data.table(..., part = c("w18", "w25", "diff"),
             est = sapply(r[1:3], `[[`, "est"), lo = sapply(r[1:3], `[[`, "lo"),
             hi = sapply(r[1:3], `[[`, "hi"), p = sapply(r[1:3], `[[`, "p"),
             se = sapply(r[1:3], `[[`, "se"), n = r$w18$n, G18 = r$G18, G25 = r$G25)
}

est <- list()

# ---------------------------------------------------------------- 1. local projections
lp <- rbindlist(lapply(HALL, function(hh) {
  d <- win[h == hh]
  rbindlist(lapply(c("s", "b", "q"), function(v) flat(event_reg(d, v), h = hh, outcome = v)))
}))
est$lp <- lp

# ---------------------------------------------------------------- 2. robustness (h = 1, 5, 10)
# pc_neutral(): the latent dollar factor of Table 4, row 4. For each war it takes
# the first principal component of standardised daily changes of 25 currencies
# per dollar on non-event days and the renminbi's loading on it. Called once
# below. Feeds b_pc / q_pc in `win` and hence Table 4 (row 4) only.
pc_neutral <- function() {
  # latent dollar factor: first principal component of standardised daily
  # changes of 25 currencies per USD, estimated by war on non-event days
  dx <- daily[, lapply(.SD, function(x) c(NA, diff(x))), .SDcols = c("s", paste0("x_", FACTOR))]
  dx[, date := daily$date]
  hit <- unique(unlist(lapply(seq_len(nrow(ev)), function(i) {
    i0 <- findInterval(ev$event_date[i] - 1L, daily$date); (i0 + 1):(i0 + 2) })))
  per <- list(`2018-19` = c("2018-03-01", "2019-12-31"), `2025` = c("2025-01-02", "2025-12-31"))
  res <- list()
  for (w in names(per)) {
    idx <- which(dx$date >= as.IDate(per[[w]][1]) & dx$date <= as.IDate(per[[w]][2]))
    est_idx <- setdiff(idx, hit)
    Z <- as.matrix(dx[est_idx, paste0("x_", FACTOR), with = FALSE])
    mu <- colMeans(Z); sdv <- apply(Z, 2, sd)
    pc <- prcomp(scale(Z, mu, sdv), center = FALSE)
    v1 <- pc$rotation[, 1]; if (sum(v1) < 0) v1 <- -v1
    f_all <- as.vector(scale(as.matrix(dx[, paste0("x_", FACTOR), with = FALSE]), mu, sdv) %*% v1)
    lam <- coef(lm(dx$s[est_idx] ~ f_all[est_idx]))[2]
    res[[w]] <- list(f = f_all, lambda = unname(lam), share = pc$sdev[1]^2 / sum(pc$sdev^2),
                     n = length(est_idx))
  }
  res
}
PC <- pc_neutral()
est$pc <- data.table(war = names(PC), lambda = sapply(PC, `[[`, "lambda"),
                     share = sapply(PC, `[[`, "share"), n_days = sapply(PC, `[[`, "n"))
win[, fsum := mapply(function(a, b, w) sum(PC[[w]]$f[(a + 1):b]), i0, i1, war)]
win[, lam := sapply(war, function(w) PC[[w]]$lambda)]
win[, b_pc := lam * 1e4 * fsum]
win[, q_pc := s - b_pc]

# event-date aggregation: one observation per war and calendar date
agg <- win[, .(l_bil = sum(l_bil), l_row = sum(l_row), s = s[1], b = b[1], q = q[1],
               cluster = cluster[1]), by = .(h, war, event_date)]
win[, april := !(war == "2025" & event_date >= as.IDate("2025-04-02") & event_date <= as.IDate("2025-04-14"))]
win[, nomix := category != "mixed_package"]

rob_specs <- list(
  list(lab = "1. Baseline: CFETS 2017 basket",                       d = function(hh) win[h == hh], yq = "q",    yb = "b"),
  list(lab = "2. CFETS 2026 weights",                       d = function(hh) win[h == hh], yq = "q26",  yb = "b26"),
  list(lab = "3. Equal-weighted EUR, JPY, KRW",                      d = function(hh) win[h == hh], yq = "q3",   yb = "b3"),
  list(lab = "4. Latent dollar factor",       d = function(hh) win[h == hh], yq = "q_pc", yb = "b_pc"),
  list(lab = "5. Control for later news",       d = function(hh) win[h == hh], yq = "q",    yb = "b", regs = c("l_bil", "l_row", "f_bil")),
  list(lab = "6. Excluding joint packages",             d = function(hh) win[h == hh & nomix == TRUE], yq = "q", yb = "b"),
  list(lab = "7. One observation per date",                   d = function(hh) agg[h == hh], yq = "q",    yb = "b"),
  list(lab = "8. Excluding 2--14 April 2025",                        d = function(hh) win[h == hh & april == TRUE], yq = "q", yb = "b"))
rob <- rbindlist(lapply(seq_along(rob_specs), function(i) {
  sp <- rob_specs[[i]]
  rbindlist(lapply(c(1L, 5L, 10L), function(hh) {
    d <- sp$d(hh)
    regs <- if (is.null(sp$regs)) c("l_bil", "l_row") else sp$regs
    rbind(flat(event_reg(d, sp$yq, regs), row = i, label = sp$lab, h = hh, outcome = "q"),
          flat(event_reg(d, sp$yb, regs), row = i, label = sp$lab, h = hh, outcome = "b"))
  }))
}))
est$rob <- rob

# ---------------------------------------------------------------- 3. actors and intensity
win[, act := fifelse(actor %in% c("U.S. escalation", "Joint package"), "us",
             fifelse(actor == "China retaliation", "cn", fifelse(actor == "De-escalation", "de", "none")))]
for (a in c("us", "cn", "de")) win[, (paste0("L_", a)) := l_bil * (act == a)]
act <- rbindlist(lapply(c(1L, 5L), function(hh) {
  d <- win[h == hh]
  rbindlist(lapply(c("s", "b", "q"), function(v) rbindlist(lapply(c("us", "cn", "de"), function(a)
    flat(event_reg(d, v, regs = c("L_us", "L_cn", "L_de", "l_row"), key = paste0("L_", a)),
         h = hh, outcome = v, actor = a)))))
}))
est$act <- act
win[, dose10 := dose / 10]
dose <- rbindlist(lapply(c(1L, 5L, 10L), function(hh) {
  d <- win[h == hh]
  rbindlist(lapply(c("s", "b", "q"), function(v) rbind(
    flat(event_reg(d, v, regs = c("dose10", "l_row"), key = "dose10"), h = hh, outcome = v, spec = "linear"),
    flat(event_reg(d, v, regs = c("sdose", "l_row"), key = "sdose"), h = hh, outcome = v, spec = "log"))))
}))
est$dose <- dose

# ---------------------------------------------------------------- 4. randomisation inference
# Pseudo-event dates are drawn, within each war, from fixing dates at least
# five calendar days away from every retained event; the actual news vectors
# are assigned to them at random and the 2025-minus-2018-19 slope is recomputed.
# ri(outcomes, hs, R): randomisation inference. Draws R sets of pseudo-event
# dates per war, assigns the actual news vectors to them and recomputes the
# 2025-minus-2018-19 slope. Called once below. Feeds the "p (RI)" columns of
# Tables 2 and 3 and the histograms of Figure A1.
ri <- function(outcomes = c("s", "b", "q"), hs = c(1L, 5L, 10L), R = R_RI) {
  per <- list(`2018-19` = c("2018-03-01", "2019-12-31"), `2025` = c("2025-01-02", "2025-12-15"))
  pools <- lapply(names(per), function(w) {
    dd <- daily$date[daily$date >= as.IDate(per[[w]][1]) & daily$date <= as.IDate(per[[w]][2])]
    dd[sapply(dd, function(x) all(abs(as.integer(x - ev$event_date)) > 5))]
  }); names(pools) <- names(per)
  set.seed(SEED)
  draws <- lapply(names(per), function(w) replicate(R, sample(pools[[w]], ev[war == w, .N])))
  names(draws) <- names(per)
  res <- list()
  for (hh in hs) {
    d <- win[h == hh][order(war, event_date, event_id)]
    X <- design(d, c("l_bil", "l_row")); P <- solve(crossprod(X), t(X))
    rsel <- which(colnames(X) == "l_bil:2025"); rsel0 <- which(colnames(X) == "l_bil:2018-19")
    for (v in outcomes) {
      obs <- (P %*% d[[v]])[rsel] - (P %*% d[[v]])[rsel0]
      sims <- vapply(seq_len(R), function(r) {
        y <- unlist(lapply(c("2018-19", "2025"), function(w) {
          pd <- as.IDate(draws[[w]][, r])
          i0 <- findInterval(pd - 1L, daily$date); i1 <- findInterval(pd, daily$date) + hh
          1e4 * (daily[[v]][i1] - daily[[v]][i0]) }))
        bb <- P %*% y; bb[rsel] - bb[rsel0] }, numeric(1))
      res[[paste(v, hh)]] <- data.table(outcome = v, h = hh, obs = obs, p = mean(abs(sims) >= abs(obs)),
                                        sims = list(sims))
    }
  }
  rbindlist(res)
}
est$ri <- ri()

# ---------------------------------------------------------------- 5. leave one cluster out
loo <- rbindlist(lapply(c(1L, 10L), function(hh) {
  d <- win[h == hh]
  rbindlist(lapply(unique(d$cluster), function(c0) {
    dd <- d[cluster != c0]
    rbindlist(lapply(c("s", "b", "q"), function(v) {
      X <- design(dd, c("l_bil", "l_row")); bb <- solve(crossprod(X), crossprod(X, dd[[v]]))
      data.table(h = hh, outcome = v, dropped = c0, war_dropped = d[cluster == c0, war[1]],
                 diff = bb["l_bil:2025", 1] - bb["l_bil:2018-19", 1])
    }))
  }))
}))
est$loo <- loo

# ---------------------------------------------------------------- 6. central parity
fx <- fread("data/cny_fixing_events.csv")
fx <- merge(fx, ev[, .(event_id, war, l_bil, l_row, actor)], by = "event_id")
fx[, support := 1e4 * (log(cny_close_1630) - log(next_fixing))]        # >0: fixing stronger than close
fx[, weak_edge_dist := 1e4 * (log(1.02 * fixing_on_pre_close_date) - log(cny_close_1630))]
fx <- merge(fx, win[h == 1, .(event_id, cluster)], by = "event_id")
est$fix_reg <- flat(event_reg(fx, "support"), outcome = "support")
est$fix_desc <- fx[, .(n = .N, mean_support = mean(support), median_support = median(support),
                       share_pos = mean(support > 0), mean_dist = mean(weak_edge_dist),
                       median_dist = median(weak_edge_dist), min_dist = min(weak_edge_dist),
                       n_within50 = sum(weak_edge_dist < 50)), by = war]
est$fx <- fx

# ---------------------------------------------------------------- 7. forward premia (licensed)
est$fwd <- fread("data/forward_premium_estimates_v92.csv")
