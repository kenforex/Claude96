# 07_tables_annual.R -- writes the Section 6 tables (one .tex file per table)
#
# WHAT THIS SCRIPT DOES
#   Reads only the list `ann` built by 06_estimation_annual.R and writes:
#     tables/tab_annual_decomp.tex    Table 8   annual decomposition and the dollar beta
#     tables/tab_attribution_legs.tex Table 9   attribution of the dollar leg and the renminbi leg
#     tables/tab_usdcny_shares.tex    Table 10  contributions to USD/CNY and shares
#     tables/tab_flows_bop.tex        Table A3  trade, settlement and balance-of-payments flows
#     tables/tab_policy_carry.tex     Table A4  fixing stance, carry and option skew by year
#     tables/tab_episodes.tex         Table A5  event-day responses by episode and dated windows
#     tables/tab_regressions.tex      Table A6  the regressions behind the attribution
#
# WHERE IT IS CALLED
#   Sourced once from R/00_run_all.R after 06. Uses the small formatting helpers
#   num(), pv() and write_table() defined in 03_tables.R.
#
# WHICH OUTPUTS DEPEND ON IT
#   The seven table files above, which JIE_v2.tex \input's.

YL <- c(`2018` = "2018", `2019` = "2019", `2025` = "2025", `2026` = "2026 (Jan--Aug)")
cells <- function(x, d = 2) paste(num(x, d), collapse = " & ")
mnum  <- function(x, d = 2) formatC(round(x, d), format = "f", digits = d)   # a number for use INSIDE $...$

# ---------------------------------------------------------------- Table 8: annual decomposition
t8 <- function() {
  d <- ann$dec; b <- ann$beta_year
  rowA <- function(lab, v, dg = 2) sprintf("%s & %s \\\\", lab, cells(v, dg))
  pa <- c(sprintf("USD/CNY, start of window & %s \\\\", cells(d$usdcny_start, 3)),
          sprintf("USD/CNY, end of window & %s \\\\", cells(d$usdcny_end, 3)),
          "\\addlinespace\\multicolumn{5}{l}{\\textit{Panel A. Fed H.10 noon rates, 16-currency basket}}\\\\",
          rowA("\\quad $\\Delta s$: USD/CNY", d$s), rowA("\\quad $\\Delta b$: dollar leg", d$b), rowA("\\quad $\\Delta q$: renminbi vs basket", d$q),
          "\\addlinespace\\multicolumn{5}{l}{\\textit{ECB reference rates, 19-currency basket (cross-check)}}\\\\",
          rowA("\\quad $\\Delta s$", d$s_ecb), rowA("\\quad $\\Delta b$", d$b_ecb), rowA("\\quad $\\Delta q$", d$q_ecb),
          "\\addlinespace\\multicolumn{5}{l}{\\textit{The renminbi's beta to the dollar leg} ($1+\\theta$)}\\\\",
          rowA("\\quad Daily changes, with one lag", b$beta_daily), rowA("\\quad Weekly changes", b$beta_weekly),
          sprintf("\\quad \\quad (standard error) & %s \\\\", paste(sprintf("{\\footnotesize (%s)}", num(b$theta_weekly_se, 2)), collapse = " & ")))
  cur <- c(EUR = "Euro", JPY = "Yen", KRW = "Won", GBP = "Pound", AUD = "Australian dollar", MYR = "Ringgit", THB = "Baht", TWD = "New Taiwan dollar", INR = "Rupee")
  pb <- c("\\addlinespace\\multicolumn{5}{l}{\\textit{Panel B. Other currencies against the dollar, log change in \\% (positive = appreciation)}}\\\\",
          sapply(names(cur), function(k) rowA(paste0("\\quad ", cur[k]), d[[paste0("vs_usd_", k)]], 1)),
          rowA("\\quad Renminbi", -d$s, 1))
  write_table("tab_annual_decomp.tex", "Four years of the renminbi: the bilateral rate, the dollar leg and the renminbi against the basket",
    "tab:annual", "lcccc", sprintf("& %s \\\\", paste(YL, collapse = " & ")), c(pa, pb),
    paste("Log changes in percent over each window (positive = renminbi depreciation for $s$ and $q$, broad dollar appreciation for $b$); $\\Delta s = \\Delta b + \\Delta q$ exactly.",
          "Windows run from the last trading day of the previous year to 31 December, or to 31 August 2026 for the last column.",
          "The H.10 series use the Federal Reserve's noon buying rates in New York and the 2017 CFETS weights renormalised over the 16 basket currencies the Fed quotes (the ECB basket of Table~\\ref{tab:basket} minus TRY, PLN and HUF).",
          "The beta $1+\\theta$ is the coefficient of the daily (or Wednesday-to-Wednesday) change in USD/CNY on the change in the dollar leg within the window, so $\\theta$ is the coefficient of $\\Delta q$ on $\\Delta b$.",
          "Panel B uses the same H.10 rates."), size = "\\footnotesize")
}
t8()

# ---------------------------------------------------------------- Table 9: attribution of the two legs
t9 <- function() {
  ab <- ann$attr_b; aq <- ann$attr_q
  r <- function(lab, v, dg = 2) sprintf("%s & %s \\\\", lab, cells(v, dg))
  pa <- c("\\multicolumn{5}{l}{\\textit{Panel A. The dollar leg} $\\Delta b$}\\\\",
          r("Total change", ab$total),
          r("\\quad Relative monetary policy ($\\hat\\beta_{2y} \\times$ relative policy-rate change)", ab$policy),
          r("\\quad Risk sentiment (VIX)", ab$vix), r("\\quad Oil price", ab$oil),
          r("\\quad Tariff-news days", ab$tariff), r("\\quad Other dollar factors (residual)", ab$other),
          "\\addlinespace\\multicolumn{5}{l}{\\textit{Memo}}\\\\",
          r("\\quad Change in U.S. policy rate (pp)", ab$d_policy_us), r("\\quad Trade-weighted change abroad (pp)", ab$d_policy_foreign),
          r("\\quad Change in U.S. 2-year yield (pp)", ab$d_us2y), r("\\quad All U.S. 2-year yield moves, fitted", ab$us2y_total))
  pb <- c("\\addlinespace\\multicolumn{5}{l}{\\textit{Panel B. The renminbi against the basket} $\\Delta q$}\\\\",
          r("Total change", aq$total),
          r("\\quad Dollar tracking ($\\hat\\theta \\times \\Delta b$)", aq$tracking),
          r("\\quad Fixing stance ($\\kappa = 0.5$)", aq$fixing), r("\\quad Carry (Shibor minus U.S. 3-month)", aq$carry),
          r("\\quad Net settlement, goods trade", aq$flows_goods), r("\\quad Net settlement, services and capital", aq$flows_nongoods),
          r("\\quad Tariff-news days", aq$tariff), r("\\quad Risk sentiment and oil", aq$riskoil), r("\\quad Unexplained", aq$residual),
          "\\addlinespace\\multicolumn{5}{l}{\\textit{Memo}}\\\\",
          r("\\quad $\\hat\\theta$ (year-specific)", aq$theta),
          r("\\quad Fixing stance, start of window (\\%)", aq$stance0), r("\\quad Fixing stance, end of window (\\%)", aq$stance1),
          r("\\quad Carry, start of window (pp)", aq$carry0), r("\\quad Carry, end of window (pp)", aq$carry1),
          r("\\quad Net goods settlement above sample mean (USD bn)", aq$excess_goods, 0),
          r("\\quad Net other settlement above sample mean (USD bn)", aq$excess_nongoods, 0))
  write_table("tab_attribution_legs.tex", "What moved each leg: an accounting attribution of the annual changes", "tab:legs", "lcccc",
    sprintf("& %s \\\\", paste(YL, collapse = " & ")), c(pa, pb),
    paste("Log changes in percent; each panel's components add up to its total. Panel A: the daily regression of the dollar leg on the U.S. 2-year yield, the VIX, Brent and tariff-news days (Table~\\ref{tab:regs}, panel A)",
          "gives the VIX, oil and tariff rows as the sum of coefficient times regressor over the window. The policy row multiplies the estimated 2-year beta",
          sprintf("($\\hat\\beta_{2y} = %s$, s.e.\\ %s, percent per percentage point)", mnum(ann$beta_2y, 2), mnum(ann$beta_2y_se, 2)),
          "by the change in the U.S. policy rate minus the CFETS-weighted change in the policy rates of the euro area, Japan, Korea, Australia, the U.K. and Canada (\\texttt{data/policy\\_rate\\_changes.csv}).",
          "The residual contains all other dollar movements, including yield moves not driven by policy and changes in the dollar risk premium.",
          "Panel B: $\\hat\\theta$ is the year-specific coefficient of $\\Delta q$ on $\\Delta b$ (Table~\\ref{tab:annual}); the fixing row is $\\kappa$ times the change in the monthly fixing stance",
          sprintf("(log fixing minus the previous day's market rate); the carry row uses the monthly coefficient $%s$ (Table~\\ref{tab:regs}, panel C); the settlement rows multiply", mnum(ann$delta_carry, 2)),
          sprintf("net SAFE bank settlement in excess of its 2017--26 monthly mean by the instrumental-variables price impact of $%s$ percent per USD billion (panel D).", mnum(ann$gamma["central"], 4)),
          "Tariff and risk rows come from the daily regression of panel B of Table~\\ref{tab:regs}."), size = "\\footnotesize")
}
t9()

# ---------------------------------------------------------------- Table 10: USD/CNY contributions and shares
t10 <- function() {
  a <- ann$attr_s; s <- ann$share_s; rg <- ann$share_range
  lab <- c(usd_policy = "Dollar: relative monetary policy", usd_other = "Dollar: risk premium and other", tariff = "Tariff news (event days, both legs)",
           carry = "China--U.S. interest differential (carry)", flows_goods = "Net FX settlement: goods trade", flows_other = "Net FX settlement: services and capital",
           fixing = "PBoC fixing stance", riskoil = "Risk sentiment and oil (renminbi leg)", residual = "Unexplained")
  body <- unlist(lapply(names(lab), function(g) c(
    sprintf("%s & %s \\\\", lab[g], cells(a[[g]], 2)),
    sprintf(" & %s \\\\", paste(sprintf("{\\footnotesize (%s\\%%)}", formatC(s[[g]], format = "f", digits = 0)), collapse = " & ")))))
  body <- c(body, "\\midrule", sprintf("Total $= \\Delta s$ & %s \\\\", cells(a$total, 2)))
  write_table("tab_usdcny_shares.tex", "Contributions to the annual change in USD/CNY, with shares", "tab:shares", "lcccc",
    sprintf("& %s \\\\", paste(YL, collapse = " & ")), body,
    paste("Each entry is a contribution to the log change in USD/CNY in percent (positive = renminbi depreciation); shares in parentheses are the absolute value of the contribution divided by the sum of absolute contributions.",
          "Dollar-leg items are scaled by the renminbi's beta $1+\\hat\\theta$ (Table~\\ref{tab:annual}), so the dollar-tracking term of Table~\\ref{tab:legs} is folded into them; the renminbi-leg items are taken directly from Table~\\ref{tab:legs}.",
          "Sensitivity: with the OLS price impact of flows instead of the IV estimate, the settlement share falls to",
          sprintf("%s percent in the four years; with $-0.02$ percent per USD billion it rises to %s percent.",
                  paste(formatC(rg$flows_share_low, format = "f", digits = 0), collapse = ", "), paste(formatC(rg$flows_share_high, format = "f", digits = 0), collapse = ", ")),
          sprintf("With $\\kappa = 0.25$ or $1$ the fixing share is %s or %s percent.",
                  paste(formatC(rg$fixing_share_low, format = "f", digits = 0), collapse = ", "), paste(formatC(rg$fixing_share_high, format = "f", digits = 0), collapse = ", "))),
    size = "\\footnotesize")
}
t10()

# ---------------------------------------------------------------- Table A3: flows and the balance of payments
tA3 <- function() {
  f <- ann$flows; b <- ann$bop
  hdr <- sprintf("& %s \\\\", paste(f$year, collapse = " & "))
  r <- function(lab, v, dg = 0) sprintf("%s & %s \\\\", lab, cells(v, dg))
  pa <- c("\\multicolumn{7}{l}{\\textit{Panel A. Trade and bank settlement (USD billion unless noted)}}\\\\",
          r("Customs trade surplus", f$customs_surplus), r("Exports", f$exports), r("Net bank settlement, goods trade", f$net_settle_goods),
          r("\\quad Settlement ratio (goods settlement / goods receipts)", f$SR, 2), r("\\quad Purchase ratio (goods FX purchases / goods payments)", f$PR, 2),
          r("Renminbi share of all cross-border receipts", f$rmb_share_rec, 2), r("Renminbi share of all cross-border payments", f$rmb_share_pay, 2),
          r("CFETS client spot: net sales of FX to banks", f$cfets_client_net), r("Net forward settlement contracts signed", f$net_fwd))
  by <- c("2017", "2018", "2019", "2023", "2024", "2025"); bb <- b[, paste0("X", by)]
  rb <- function(lab, key) sprintf("%s & %s \\\\", lab, cells(as.numeric(bb[key, ]), 0))
  pb <- c("\\addlinespace\\multicolumn{7}{l}{\\textit{Panel B. Balance of payments (USD billion; BPM6 sign convention: positive = net inflow)}}\\\\",
          sprintf("& %s \\\\", paste(by, collapse = " & ")), "\\cmidrule(lr){2-7}",
          rb("Current account", "current_account"), rb("\\quad Goods", "goods"), rb("\\quad Services", "services"),
          rb("Financial account excluding reserves", "financial_account_nonreserve"),
          rb("\\quad Net acquisition of assets abroad", "fa_assets"), rb("\\quad Net incurrence of liabilities", "fa_liabilities"),
          rb("\\quad \\quad Inward direct investment", "fdi_liabilities"), rb("\\quad \\quad Portfolio liabilities", "portfolio_liabilities"),
          rb("Reserve assets", "reserve_assets"), rb("Net errors and omissions", "net_errors_omissions"))
  write_table("tab_flows_bop.tex", "Trade, settlement and capital flows in the four years", "tab:flows", "lcccccc", hdr, c(pa, pb),
    paste("Panel A: customs data (General Administration of Customs), SAFE bank settlement and sales by item, SAFE cross-border receipts and payments by currency, and CFETS client spot turnover;",
          "the 2026 column covers January to August. Panel B: SAFE balance of payments, annual, in USD billion; a negative asset entry is a net acquisition of foreign assets."),
    size = "\\footnotesize", colsep = 4)
}
tA3()

# ---------------------------------------------------------------- Table A4: fixing stance, carry, option skew
tA4 <- function() {
  p <- ann$pol_year; cy <- ann$carry_year; rr <- ann$rr
  hdr <- sprintf("& %s \\\\", paste(p$year, collapse = " & "))
  r <- function(lab, v, dg = 1) sprintf("%s & %s \\\\", lab, cells(v, dg))
  pa <- c("\\multicolumn{11}{l}{\\textit{Panel A. The central parity (basis points; negative = fixing stronger than the previous market rate)}}\\\\",
          r("Mean stance, whole year", p$stance_mean_bp), r("Mean stance, December (2026: August)", p$stance_dec_bp),
          r("Follow-through $\\rho$ of the market into the fixing", p$rho, 2))
  cv <- function(v) { out <- rep(NA, nrow(p)); out[match(cy$year, p$year)] <- v; out }
  rv <- function(ten) { out <- rep(NA, nrow(p)); x <- rr[rr$tenor == ten, ]; out[match(x$year, p$year)] <- x$rr25_mean_volpts; out }
  fmt <- function(v, dg) paste(ifelse(is.na(v), "--", num(v, dg)), collapse = " & ")
  pb <- c("\\addlinespace\\multicolumn{11}{l}{\\textit{Panel B. Interest differentials (percentage points, annual averages)}}\\\\",
          sprintf("Shibor 3M minus U.S. Treasury 3M & %s \\\\", fmt(cv(cy$carry3m), 2)),
          sprintf("Shibor 1Y minus large USD deposit rate 1Y & %s \\\\", fmt(cv(cy$carry1y_dep), 2)),
          "\\addlinespace\\multicolumn{11}{l}{\\textit{Panel C. Option skew: USD/CNH 25-delta risk reversal (vol points; positive = renminbi depreciation priced)}}\\\\",
          sprintf("1-month & %s \\\\", fmt(rv("1M"), 2)), sprintf("1-year & %s \\\\", fmt(rv("1Y"), 2)),
          "\\addlinespace\\multicolumn{11}{l}{\\textit{Panel D. The dollar's safe-haven beta (percent change in the dollar leg per 100 percent change in the VIX, by year)}}\\\\",
          sprintf("Beta to the VIX & %s \\\\", cells(ann$vix_beta$beta[match(p$year, ann$vix_beta$year)], 2)))
  write_table("tab_policy_carry.tex", "Fixing stance, interest differentials and option skew, 2017--2026", "tab:policy", "lcccccccccc", hdr, c(pa, pb),
    paste("Panel A: the fixing stance is the log central parity of day $t$ minus the log Fed H.10 noon rate of day $t-1$ (about 00:00 Beijing time of day $t$);",
          "$\\rho$ is the coefficient of the daily change in the fixing on the gap between the previous market rate and the previous fixing, estimated year by year.",
          "Panel B: Shibor (CFETS), U.S. Treasury yields (FRED) and the PBoC's reported average rate on large USD deposits (quarterly \\textit{Monetary Policy Report}, 2017--2026H1).",
          "Panel C: annual means of the 25-delta risk reversal from the licensed Bloomberg data behind Table~\\ref{tab:forward}, reproduced from \\texttt{data/cnh\\_rr25\\_annual.csv}; not available for 2021--23 or 2026 in that extract.",
          "Panel D: year-by-year regressions of the daily change in the dollar leg on the U.S. 2-year yield, the VIX and Brent (same day and one lag)."),
    size = "\\scriptsize", colsep = 2)
}
tA4()

# ---------------------------------------------------------------- Table A5: episodes and dated windows
tA5 <- function() {
  e <- ann$evr; e <- e[match(c("2018-19", "2020-24", "2025", "2026"), e$episode), ]
  w <- ann$windows
  cell <- function(m, t) sprintf("%s {\\footnotesize (%s)}", num(m, 2), num(t, 1))
  pa <- c("\\multicolumn{7}{l}{\\textit{Panel A. Two-day responses on tariff-news days, signed so that $+$ is an escalation; $t$-statistics in parentheses}}\\\\",
          "Episode & $n$ & Dollar leg (\\%) & USD/CNY (\\%) & RMB vs basket (\\%) & U.S. 2y (bp) & VIX (\\%) \\\\", "\\midrule",
          sprintf("%s & %d & %s & %s & %s & %s & %s \\\\", gsub("-", "--", e$episode), e$n, cell(e$db, e$db_t), cell(e$ds, e$ds_t), cell(e$dq, e$dq_t), cell(e$d2y, e$d2y_t), cell(e$dvix, e$dvix_t)))
  pb <- c("\\addlinespace\\multicolumn{7}{l}{\\textit{Panel B. Dated windows (raw changes)}}\\\\",
          "Window & & Dollar leg (\\%) & USD/CNY (\\%) & RMB vs basket (\\%) & U.S. 2y (bp) & VIX (pts) \\\\", "\\midrule",
          sprintf("%s & & %s & %s & %s & %s & %s \\\\", w$window, num(w$db, 2), num(w$ds, 2), num(w$dq, 2), num(w$d2y_bp, 0), num(w$dvix, 1)))
  write_table("tab_episodes.tex", "Tariff-news days and dated windows across the four episodes", "tab:episodes", "llccccc", "", c(pa, pb),
    paste("Panel A uses all retained events with bilateral or rest-of-world tariff content (88 events: the 68 of Table~\\ref{tab:events} plus 20 for 2020--24 and 2026 coded by the same rule, \\texttt{data/events\\_extension.csv}).",
          "Each response is the change from the trading day before the event to the trading day after it (Fed H.10 noon rates; FRED), multiplied by the sign of the news; $t$-statistics treat events as independent.",
          "Panel B reports raw changes over four windows discussed in the text."),
    size = "\\scriptsize", colsep = 3)
}
tA5()

# ---------------------------------------------------------------- Table A6: regressions behind the attribution
tA6 <- function() {
  fb <- ann$fb; fq <- ann$fq; m1 <- ann$f_m1; m2 <- ann$f_m2; iv <- ann$iv; b5 <- ann$f_b5
  ct <- function(df, term, dg = 3) { i <- match(term, df$term); sprintf("%s {\\footnotesize (%s)}", num(df$coef[i], dg), num(df$t[i], 1)) }
  pa <- c("\\multicolumn{4}{l}{\\textit{Panel A. Daily change in the dollar leg (\\%), Jan 2017--Aug 2026, no constant; Newey--West $t$ in parentheses}}\\\\",
          sprintf("U.S. 2-year yield, $\\Delta$ (pp): same day & %s & lagged one day & %s \\\\", ct(fb, "d2y", 2), ct(fb, "d2y_L", 2)),
          sprintf("VIX, $\\Delta\\log$ (\\%%): same day & %s & lagged & %s \\\\", ct(fb, "dvix", 4), ct(fb, "dvix_L", 4)),
          sprintf("\\quad additional after 2022: same day & %s & lagged & %s \\\\", ct(fb, "dvix_post", 4), ct(fb, "dvix_L_post", 4)),
          sprintf("Brent, $\\Delta\\log$ (\\%%): same day & %s & lagged & %s \\\\", ct(fb, "doil", 4), ct(fb, "doil_L", 4)),
          sprintf("Tariff-news day $\\times$ 2018--19 & %s & $\\times$ 2020--24 & %s \\\\", ct(fb, "ev_1819", 3), ct(fb, "ev_2024", 3)),
          sprintf("Tariff-news day $\\times$ 2025 & %s & $\\times$ 2026 & %s \\\\", ct(fb, "ev_2025", 3), ct(fb, "ev_2026", 3)))
  th <- ann$theta
  pb <- c("\\addlinespace\\multicolumn{4}{l}{\\textit{Panel B. Daily change in the renminbi vs basket (\\%); $\\hat\\theta$ by year (same-day plus lagged coefficient on $\\Delta b$)}}\\\\",
          sprintf("\\multicolumn{4}{l}{2017: %s; 2018: %s; 2019: %s; 2020: %s; 2021: %s} \\\\",
                  num(th["2017"], 2), num(th["2018"], 2), num(th["2019"], 2), num(th["2020"], 2), num(th["2021"], 2)),
          sprintf("\\multicolumn{4}{l}{2022: %s; 2023: %s; 2024: %s; 2025: %s; 2026: %s} \\\\",
                  num(th["2022"], 2), num(th["2023"], 2), num(th["2024"], 2), num(th["2025"], 2), num(th["2026"], 2)),
          sprintf("VIX, $\\Delta\\log$ & %s & Brent, $\\Delta\\log$ & %s \\\\", ct(fq, "dvix", 4), ct(fq, "doil", 4)),
          sprintf("Tariff-news day $\\times$ 2018--19 & %s & $\\times$ 2020--24 & %s \\\\", ct(fq, "ev_1819", 3), ct(fq, "ev_2024", 3)),
          sprintf("Tariff-news day $\\times$ 2025 & %s & $\\times$ 2026 & %s \\\\", ct(fq, "ev_2025", 3), ct(fq, "ev_2026", 3)))
  pc <- c(sprintf("\\addlinespace\\multicolumn{4}{l}{\\textit{Panel C. Monthly change in $q^{*}$ (renminbi vs basket net of dollar tracking, \\%%), %d months}}\\\\", ann$n_m),
          "& Contemporaneous flows & & Lagged flows \\\\",
          sprintf("Net goods settlement (USD bn) & %s & & %s \\\\", ct(m1, "net_goods", 4), ct(m2, "net_goods_L", 4)),
          sprintf("Net services and capital settlement (USD bn) & %s & & %s \\\\", ct(m1, "net_nongoods", 4), ct(m2, "net_nongoods_L", 4)),
          sprintf("$\\Delta$ fixing stance (\\%%) & %s & & %s \\\\", ct(m1, "dstance", 3), ct(m2, "dstance", 3)),
          sprintf("$\\Delta$ carry (pp) & %s & & %s \\\\", ct(m1, "dcarry", 3), ct(m2, "dcarry", 3)),
          sprintf("$\\Delta\\log$ VIX & %s & & %s \\\\", ct(m1, "dvix", 4), ct(m2, "dvix", 4)),
          sprintf("$\\Delta\\log$ Brent & %s & & %s \\\\", ct(m1, "dbrent", 4), ct(m2, "dbrent", 4)),
          sprintf("$R^2$ & %s & & %s \\\\", num(ann$r2_m1, 2), num(ann$r2_m2, 2)))
  pd <- c(sprintf("\\addlinespace\\multicolumn{4}{l}{\\textit{Panel D. Price impact of net goods settlement on $q^{*}$ (\\%% per USD bn); month dummies, carry, VIX, oil; %d months}}\\\\", iv$n[1]),
          sprintf("IV, instrument: customs trade balance & %s {\\footnotesize (s.e.\\ %s)} & First stage & %s {\\footnotesize ($t = %s$, $F = %s$)} \\\\",
                  num(iv$coef[1], 4), num(iv$se[1], 4), num(ann$iv_first_coef, 2), mnum(ann$iv_first_t, 1), mnum(ann$iv_first_F, 1)),
          sprintf("OLS & %s {\\footnotesize (s.e.\\ %s)} & Reduced form, trade balance & %s {\\footnotesize (s.e.\\ %s)} \\\\", num(iv$coef[2], 4), num(iv$se[2], 4), num(iv$coef[3], 4), num(iv$se[3], 4)))
  pe <- c(sprintf("\\addlinespace\\multicolumn{4}{l}{\\textit{Panel E. Net goods settlement (USD bn) on past appreciation; month dummies included; %d months}}\\\\", ann$n_b5),
          sprintf("RMB appreciation vs USD, previous 3 months (\\%%) & %s & Carry (pp) & %s \\\\", ct(b5, "past3", 2), ct(b5, "carry", 2)),
          sprintf("Customs trade balance (USD bn) & %s & & \\\\", ct(b5, "cus_bal", 2)))
  write_table("tab_regressions.tex", "The regressions behind the attribution", "tab:regs", "p{4.4cm}p{2.4cm}p{3.0cm}p{2.4cm}", "", c(pa, pb, pc, pd, pe),
    paste("Panels A and B are estimated on all trading days from 4 January 2017 to 31 August 2026 with Newey--West standard errors (5 lags); regressors that are missing on a holiday are set to zero.",
          "Panel A also includes the lagged changes; the post-2022 VIX terms let the dollar's safe-haven beta differ after 2022. Panel B includes year-specific same-day and lagged coefficients on $\\Delta b$.",
          "Panels C--E use months from January 2017 to August 2026 with Newey--West standard errors (3 lags). In panel D the instrument is the customs trade surplus of the same month;",
          "the IV estimate is used as the central price impact in Tables~\\ref{tab:legs} and \\ref{tab:shares}."),
    size = "\\scriptsize", colsep = 2)
}
tA6()
