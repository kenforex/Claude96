# 04_figures.R -- writes the figures into figures/ (PDF, fonts embedded via cairo)
#
# WHAT THIS SCRIPT DOES
#   Draws six figures from `daily`, `ev`, `win` and `est`:
#     figures/fig_paths.pdf          Figure 1   daily paths of s, b, q in both wars
#     figures/fig_responses.pdf      Figure 2   local-projection coefficients by horizon
#     figures/fig_events_day5.pdf    Figure 3   event-level decomposition at day 5
#     figures/fig_fixing.pdf         Figure 4   fixing support after tariff news
#     figures/fig_randomisation.pdf  Figure A1  randomisation-inference histograms
#     figures/fig_leave_one_out.pdf  Figure A2  leave-one-cluster-out estimates
#   The plot theme `theme_paper`, the font and the helper save() are reused by
#   08_figures_annual.R.
#
# WHERE IT IS CALLED
#   Sourced fourth from R/00_run_all.R, after 03_tables.R.
dir.create("figures", showWarnings = FALSE)
invisible(suppressWarnings(Sys.setlocale("LC_CTYPE", "C.UTF-8")))   # en dashes and minus signs in labels
COL  <- c("2018-19" = "#1F5A99", "2025" = "#2E8B57")
WLAB <- c("2018-19" = "2018–19 trade war", "2025" = "2025 trade war")
OLAB <- c(s = "Bilateral: USD/CNY", b = "Dollar leg: basket per USD", q = "Renminbi against the basket")
FONT <- "Liberation Sans"
theme_paper <- theme_minimal(base_size = 9, base_family = FONT) +
  theme(panel.grid.minor = element_blank(), panel.grid.major = element_line(linewidth = 0.25, colour = "grey88"),
        strip.text = element_text(face = "bold", hjust = 0), legend.position = "bottom",
        legend.title = element_blank(), axis.title = element_text(size = 8.5))
# save(p, file, w, h): writes ggplot p to figures/<file> as a w x h inch PDF.
# Called once per figure here and in 08_figures_annual.R.
save <- function(p, file, w, h) ggsave(file.path("figures", file), p, width = w, height = h, device = cairo_pdf)

# ---------------------------------------------------------------- Figure 1: daily paths
per <- list(`2018-19` = c("2018-03-01", "2019-12-31"), `2025` = c("2025-01-02", "2025-12-31"))
paths <- rbindlist(lapply(names(per), function(w) {
  d <- daily[date >= as.IDate(per[[w]][1]) & date <= as.IDate(per[[w]][2])]
  rbindlist(lapply(c("s", "b", "q"), function(v)
    data.table(war = w, date = as.Date(d$date), series = v, value = 100 * (d[[v]] - d[[v]][1]))))
}))
paths[, series := factor(OLAB[series], levels = OLAB)]
paths[, war := factor(WLAB[war], levels = WLAB)]
rug <- ev[, .(war = factor(WLAB[war], levels = WLAB), date = as.Date(event_date))]
p1 <- ggplot(paths, aes(date, value, colour = series, linetype = series)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_line(linewidth = 0.5) +
  geom_rug(data = rug, aes(x = date), inherit.aes = FALSE, sides = "b", linewidth = 0.3, colour = "grey30", length = unit(0.02, "npc")) +
  facet_wrap(~war, scales = "free_x") +
  scale_colour_manual(values = c("black", "#B8860B", "#8B1A1A")) +
  scale_linetype_manual(values = c("solid", "dashed", "solid")) +
  scale_x_date(date_labels = "%b\n%Y", date_breaks = "4 months") +
  labs(x = NULL, y = "Cumulative log change since start of window (%)") + theme_paper
save(p1, "fig_paths.pdf", 6.5, 3.4)

# ---------------------------------------------------------------- Figure 2: response paths
lpd <- est$lp[part != "diff"]
lpd[, war := factor(WLAB[ifelse(part == "w18", "2018-19", "2025")], levels = WLAB)]
lpd[, outcome := factor(OLAB[outcome], levels = OLAB)]
dodge <- position_dodge(width = 0.45)
p2 <- ggplot(lpd, aes(h, est, colour = war, shape = war)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0, linewidth = 0.35, position = dodge) +
  geom_line(linewidth = 0.45, position = dodge) + geom_point(size = 1.4, position = dodge) +
  facet_wrap(~outcome, nrow = 1) +
  scale_colour_manual(values = unname(COL)) + scale_shape_manual(values = c(16, 17)) +
  scale_x_continuous(breaks = 1:10) +
  labs(x = "Trading days after the event (ECB fixings)", y = "bp per unit of signed news") + theme_paper
save(p2, "fig_responses.pdf", 6.5, 2.9)

# ---------------------------------------------------------------- Figure 3: event-level decomposition
sc <- win[h == 5 & l_bil != 0, .(war = factor(WLAB[war], levels = WLAB), x = l_bil * b, y = l_bil * q, event_id)]
lim <- max(abs(c(sc$x, sc$y))) * 1.05
p3 <- ggplot(sc, aes(x, y, colour = war, shape = war)) +
  geom_hline(yintercept = 0, linewidth = 0.25, colour = "grey60") + geom_vline(xintercept = 0, linewidth = 0.25, colour = "grey60") +
  geom_abline(slope = -1, intercept = 0, linetype = "dashed", linewidth = 0.35, colour = "grey30") +
  geom_point(size = 1.8, alpha = 0.85) +
  annotate("text", x = lim * 0.62, y = -lim * 0.78, label = "USD/CNY unchanged", family = FONT, size = 2.8, colour = "grey30", angle = -45) +
  coord_equal(xlim = c(-lim, lim), ylim = c(-lim, lim)) +
  scale_colour_manual(values = unname(COL)) + scale_shape_manual(values = c(16, 17)) +
  labs(x = "Dollar leg, sign-adjusted (bp)", y = "Renminbi against the basket, sign-adjusted (bp)") + theme_paper
save(p3, "fig_events_day5.pdf", 4.2, 4.4)

# ---------------------------------------------------------------- Figure 4: central parity
fxp <- est$fx[, .(war = factor(WLAB[war], levels = WLAB), news = factor(l_bil, levels = c(-1, 0, 1), labels = c("De-escalation (−1)", "No bilateral news (0)", "Escalation (+1)")), support)]
p4 <- ggplot(fxp, aes(news, support, colour = war, shape = war)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_point(position = position_jitterdodge(jitter.width = 0.15, dodge.width = 0.6, seed = SEED), size = 1.6, alpha = 0.85) +
  stat_summary(fun = mean, geom = "crossbar", width = 0.45, linewidth = 0.3, position = position_dodge(width = 0.6), show.legend = FALSE) +
  scale_colour_manual(values = unname(COL)) + scale_shape_manual(values = c(16, 17)) +
  labs(x = NULL, y = "Fixing support: close minus next fixing (bp)") + theme_paper
save(p4, "fig_fixing.pdf", 5.2, 3.2)

# ---------------------------------------------------------------- Figure A1: randomisation inference
rid <- est$ri[h == 5, .(sims = unlist(sims)), by = .(outcome, obs)]
rid[, outcome := factor(OLAB[outcome], levels = OLAB)]
obs <- unique(rid[, .(outcome, obs)])
pA1 <- ggplot(rid, aes(sims)) + geom_histogram(bins = 50, fill = "grey70", colour = NA) +
  geom_vline(data = obs, aes(xintercept = obs), colour = "#8B1A1A", linewidth = 0.6) +
  facet_wrap(~outcome, nrow = 1) + scale_x_continuous(expand = expansion(mult = 0.1)) +
  labs(x = "2025 minus 2018–19 slope on pseudo-event dates, day 5 (bp)", y = "Draws") + theme_paper
save(pA1, "fig_randomisation.pdf", 6.5, 2.4)

# ---------------------------------------------------------------- Figure A2: leave one cluster out
lo <- copy(est$loo)
lo[, outcome := factor(OLAB[outcome], levels = OLAB)]
lo[, hl := factor(paste("Day", h), levels = c("Day 1", "Day 10"))]
lo[, war_dropped := factor(WLAB[war_dropped], levels = WLAB)]
full <- est$lp[part == "diff" & h %in% c(1, 10), .(outcome = factor(OLAB[outcome], levels = OLAB), hl = factor(paste("Day", h), levels = c("Day 1", "Day 10")), est)]
pA2 <- ggplot(lo, aes(diff, outcome, colour = war_dropped, shape = war_dropped)) +
  geom_vline(xintercept = 0, linewidth = 0.3, colour = "grey55") +
  geom_point(position = position_jitter(height = 0.12, width = 0, seed = SEED), size = 1.4, alpha = 0.8) +
  geom_point(data = full, aes(est, outcome), inherit.aes = FALSE, shape = 124, size = 5) +
  facet_wrap(~hl, scales = "free_x") +
  scale_colour_manual(values = unname(COL), labels = c("2018–19 cluster dropped", "2025 cluster dropped")) +
  scale_shape_manual(values = c(16, 17), labels = c("2018–19 cluster dropped", "2025 cluster dropped")) +
  scale_y_discrete(limits = rev) +
  labs(x = "2025 minus 2018–19 difference (bp)", y = NULL) + theme_paper
save(pA2, "fig_leave_one_out.pdf", 6.5, 2.6)
