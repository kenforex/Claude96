# 03_tables.R -- writes one LaTeX (booktabs) file per table into tables/
#
# WHAT THIS SCRIPT DOES
#   Formats the results in `est`, `ev`, `win` and `wts` into nine .tex files:
#     t1  -> tables/tab_events.tex             Table 1
#     t2  -> tables/tab_bilateral.tex          Table 2
#     t3  -> tables/tab_decomposition.tex      Table 3
#     t4  -> tables/tab_robustness.tex         Table 4
#     t5  -> tables/tab_actors_intensity.tex   Table 5
#     t7  -> tables/tab_forward.tex            Table 6 (licensed-data estimates)
#     t6  -> tables/tab_fixing.tex             Table 7
#     tA1 -> tables/tab_event_list.tex         Table A1
#     tA2 -> tables/tab_basket.tex             Table A2
#   The formatting helpers num(), ci(), pv(), tex_escape() and write_table()
#   defined at the top are also used by 07_tables_annual.R.
#
# WHERE IT IS CALLED
#   Sourced third from R/00_run_all.R, after 02_estimation.R.

dir.create("tables", showWarnings = FALSE)
# num(x, d): a number rounded to d decimals with a proper LaTeX minus sign.
# ci(lo, hi, d): "[lo, hi]". pv(p): a p-value with "<0.001" below that level.
# tex_escape(x): escapes %, &, #, _, $ in free text. Used by every table function
# here and in 07_tables_annual.R.
num <- function(x, d = 1) { s <- formatC(round(x, d), format = "f", digits = d)
  s <- sub("^-(0\\.0*)$", "\\1", s); gsub("-", "$-$", s, fixed = TRUE) }
ci  <- function(lo, hi, d = 1) sprintf("[%s, %s]", num(lo, d), num(hi, d))
pv  <- function(p) ifelse(p < 0.001, "$<$0.001", formatC(p, format = "f", digits = 3))
tex_escape <- function(x) { x <- gsub("\\\\", "", x); x <- gsub("([%&#_$])", "\\\\\\1", x); x }
WAR <- c("2018--19", "2025")

# write_table(file, caption, label, colspec, header, body, notes, size, colsep):
# wraps a header and body (vectors of LaTeX rows) into a complete table
# environment and writes it to tables/<file>. Called by every table function
# here and in 07_tables_annual.R.
write_table <- function(file, caption, label, colspec, header, body, notes, size = "\\small", colsep = 6) {
  out <- c("\\begin{table}[!htbp]", "\\centering", size, sprintf("\\setlength{\\tabcolsep}{%spt}", colsep),
           sprintf("\\caption{%s}", caption), sprintf("\\label{%s}", label),
           sprintf("\\begin{tabular}{%s}", colspec), "\\toprule", header, "\\midrule", body,
           "\\bottomrule", "\\end{tabular}",
           "\\par\\vspace{0.4em}\\begin{minipage}{0.97\\linewidth}\\footnotesize",
           paste0("\\textit{Notes:} ", notes), "\\end{minipage}", "\\end{table}")
  writeLines(out, file.path("tables", file))
}
# pick(dt, cond): returns the single row of dt that satisfies cond (stops if
# there is not exactly one). Called by t2-t6 to look up one estimate at a time.
pick <- function(dt, cond) { i <- eval(substitute(cond), dt, parent.frame()); r <- dt[which(i)]; stopifnot(nrow(r) == 1); r }

# ---------------------------------------------------------------- Table 1: events
t1 <- function() {
  cnt <- function(w, cond) ev[war == w & eval(cond), .N]
  row <- function(lab, f) sprintf("%s & %s & %s \\\\", lab, f("2018-19"), f("2025"))
  dose_stat <- function(w, fun) num(fun(ev[war == w & l_bil != 0, abs(dose)]), 1)
  body <- c(
    row("Retained events", function(w) cnt(w, quote(TRUE))),
    "\\addlinespace\\multicolumn{3}{l}{\\textit{Bilateral news} ($L^{BIL}_j$)}\\\\",
    row("\\quad U.S. escalation ($+1$)", function(w) cnt(w, quote(actor == "U.S. escalation"))),
    row("\\quad Chinese retaliation ($+1$)", function(w) cnt(w, quote(actor == "China retaliation"))),
    row("\\quad Joint U.S.--China package ($+1$)", function(w) cnt(w, quote(actor == "Joint package"))),
    row("\\quad De-escalation ($-1$)", function(w) cnt(w, quote(actor == "De-escalation"))),
    row("\\quad No bilateral tariff-level news (0)", function(w) cnt(w, quote(actor == "No bilateral news"))),
    row("Events with rest-of-world news ($L^{ROW}_j \\neq 0$)", function(w) cnt(w, quote(l_row != 0))),
    "\\addlinespace\\multicolumn{3}{l}{\\textit{Overlap clusters}}\\\\",
    row("\\quad Day-1 windows", function(w) win[h == 1 & war == w, uniqueN(cluster)]),
    row("\\quad Day-10 windows", function(w) win[h == 10 & war == w, uniqueN(cluster)]),
    "\\addlinespace\\multicolumn{3}{l}{\\textit{Headline tariff intensity of bilateral events} ($|I_j|$, \\% of bilateral trade)}\\\\",
    row("\\quad Mean", function(w) dose_stat(w, mean)),
    row("\\quad Median", function(w) dose_stat(w, median)),
    row("\\quad Maximum", function(w) dose_stat(w, max)))
  write_table("tab_events.tex", "The two samples of tariff-news events", "tab:events", "lcc",
    "& 2018--19 & 2025 \\\\", body,
    paste("Events are coded by the same narrative rule in both wars. $L^{BIL}_j$ is $+1$ for news that raises the expected level of bilateral U.S.--China tariffs,",
          "$-1$ for news that lowers it, and 0 for implementation of previously announced measures or news without bilateral content; $L^{ROW}_j$ codes tariff news",
          "towards the rest of the world. Overlap clusters join events whose event windows (from the last ECB fixing before the event date to the $h$-th fixing after it) overlap.",
          "Headline tariff intensity $I_j$ is the announced change in taxed bilateral trade (covered trade times the announced change in the ad valorem rate),",
          "in percent of U.S.--China goods trade in the year before each war (2017 and 2024); Appendix Table~\\ref{tab:eventlist} lists every event."))
}
t1()

# ---------------------------------------------------------------- Table 2: bilateral response
t2 <- function() {
  body <- unlist(lapply(H, function(hh) {
    g <- function(o, pt) pick(est$lp, h == hh & outcome == o & part == pt)
    a <- g("s", "w18"); b <- g("s", "w25"); d <- g("s", "diff")
    r <- est$ri[outcome == "s" & h == hh]
    c(sprintf("Day %d & %s & %s & %s & %s & %s & %d/%d \\\\", hh, num(a$est), num(b$est), num(d$est), pv(d$p),
              if (nrow(r)) pv(r$p) else "--", a$G18, a$G25),
      sprintf(" & {\\footnotesize %s} & {\\footnotesize %s} & {\\footnotesize %s} & & & \\\\", ci(a$lo, a$hi), ci(b$lo, b$hi), ci(d$lo, d$hi)))
  }))
  write_table("tab_bilateral.tex", "The bilateral response: USD/CNY after signed U.S.--China tariff news", "tab:bilateral",
    "lcccccc",
    "Horizon & 2018--19 & 2025 & Difference & $p$ (WCB) & $p$ (RI) & Clusters \\\\",
    body,
    paste("Coefficients $\\beta_{w,h}$ from equation~\\eqref{eq:lp}: the change in log USD/CNY (renminbi per dollar; positive = renminbi depreciation) from the last ECB reference fixing before the event date",
          "to the $h$-th fixing after it, in basis points, per unit of signed bilateral news, controlling for rest-of-world tariff news. 68 events (30 and 38).",
          "Brackets: 95\\% wild cluster bootstrap-$t$ intervals (Webb weights, 9,999 replications, overlap clusters).",
          "$p$ (WCB): restricted wild cluster bootstrap $p$-value for the difference. $p$ (RI): randomisation inference, 2,000 draws of pseudo-event dates at least five days from any retained event.",
          "Clusters: 2018--19/2025."))
}
t2()

# ---------------------------------------------------------------- Table 3: decomposition
t3 <- function() {
  lab <- c(s = "Bilateral USD/CNY", b = "\\quad $=$ Dollar leg", q = "\\quad $+$ Renminbi vs basket")
  body <- unlist(lapply(c(1L, 5L, 10L), function(hh) {
    c(sprintf("\\addlinespace\\multicolumn{6}{l}{\\textit{Day %d}}\\\\", hh),
      unlist(lapply(c("s", "b", "q"), function(o) {
        g <- function(pt) pick(est$lp, h == hh & outcome == o & part == pt)
        a <- g("w18"); b <- g("w25"); d <- g("diff"); r <- est$ri[outcome == o & h == hh]
        c(sprintf("%s & %s & %s & %s & %s & %s \\\\", lab[o], num(a$est), num(b$est), num(d$est), pv(d$p), pv(r$p)),
          sprintf(" & {\\footnotesize %s} & {\\footnotesize %s} & {\\footnotesize %s} & & \\\\", ci(a$lo, a$hi), ci(b$lo, b$hi), ci(d$lo, d$hi)))
      })))
  }))
  write_table("tab_decomposition.tex", "Where the bilateral response went: an exact decomposition into the dollar leg and the renminbi against the basket",
    "tab:decomp", "lccccc",
    "& 2018--19 & 2025 & Difference & $p$ (WCB) & $p$ (RI) \\\\", body,
    paste("The bilateral change is split exactly as $\\Delta s = \\Delta b + \\Delta q$ (equation~\\eqref{eq:identity}), where $b$ is the log price of the dollar in units of the fixed non-dollar CFETS basket",
          "(2017 weights renormalised over 19 currencies; positive = broad dollar appreciation) and $q = s - b$ is the log price of the basket in renminbi (positive = renminbi depreciation against the basket).",
          "Because the regressions are linear, the three rows add up exactly within each column. All series are ECB reference rates observed at the same moment (14:10 CET).",
          "Specification and inference as in Table~\\ref{tab:bilateral}."))
}
t3()

# ---------------------------------------------------------------- Table 4: robustness
t4 <- function() {
  body <- unlist(lapply(sort(unique(est$rob$row)), function(i) {
    r <- est$rob[row == i]
    cells <- unlist(lapply(c(1L, 5L, 10L), function(hh) lapply(c("b", "q"), function(o) pick(r, h == hh & outcome == o & part == "diff"))), recursive = FALSE)
    c(sprintf("%s & %s \\\\", r$label[1], paste(sapply(cells, function(x) num(x$est)), collapse = " & ")),
      sprintf(" & %s \\\\", paste(sapply(cells, function(x) sprintf("{\\footnotesize (%s)}", pv(x$p))), collapse = " & ")))
  }))
  write_table("tab_robustness.tex", "Robustness of the decomposition: 2025 minus 2018--19 differences", "tab:robust",
    "lcccccc",
    paste("& \\multicolumn{2}{c}{Day 1} & \\multicolumn{2}{c}{Day 5} & \\multicolumn{2}{c}{Day 10}\\\\",
          "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}",
          "& Dollar & Renminbi & Dollar & Renminbi & Dollar & Renminbi \\\\"),
    body,
    paste("Each entry is the 2025-minus-2018--19 difference in the response to signed bilateral news of the dollar leg (``Dollar'') or of the renminbi against the basket (``Renminbi''), in basis points;",
          "wild cluster bootstrap $p$-values in parentheses. Row 2 uses the most recent fully published CFETS weights (2026 vintage); row 3 an equal-weighted EUR, JPY and KRW basket.",
          "Row 4 replaces the basket by a latent dollar factor: the first principal component of daily changes in 25 currencies per dollar, estimated by war on days outside event windows,",
          "with the renminbi's estimated loading; the dollar component is the loading times the factor change, and the renminbi column is the remainder.",
          "Row 5 adds the sum of later signed bilateral news inside each window. Row 7 aggregates events that share a date. Row 8 drops the 14 events of 2--14 April 2025."),
    size = "\\footnotesize", colsep = 4)
}
t4()

# ---------------------------------------------------------------- Table 5: actors and intensity
t5 <- function() {
  alab <- c(us = "U.S. escalation", cn = "Chinese retaliation", de = "De-escalation")
  cellrow <- function(src, lab) {
    v <- unlist(lapply(c("s", "b", "q"), function(o) lapply(c("w18", "w25"), function(pt) src(o, pt))), recursive = FALSE)
    c(sprintf("%s & %s \\\\", lab, paste(sapply(v, function(x) num(x$est)), collapse = " & ")),
      sprintf(" & %s \\\\", paste(sapply(v, function(x) sprintf("{\\scriptsize %s}", ci(x$lo, x$hi, 0))), collapse = " & ")))
  }
  pa <- unlist(lapply(c("us", "cn", "de"), function(a)
    cellrow(function(o, pt) pick(est$act, h == 5 & actor == a & outcome == o & part == pt), alab[a])))
  pb <- unlist(lapply(list(list("linear", 1L, "Linear, day 1"), list("linear", 5L, "Linear, day 5"),
                           list("log", 1L, "Signed log, day 1"), list("log", 5L, "Signed log, day 5"),
                           list("log", 10L, "Signed log, day 10")), function(z)
    cellrow(function(o, pt) pick(est$dose, spec == z[[1]] & h == z[[2]] & outcome == o & part == pt), z[[3]])))
  write_table("tab_actors_intensity.tex", "Who moved the market, and per unit of what: responses by actor and by headline tariff intensity",
    "tab:actors", "lcccccc",
    paste("& \\multicolumn{2}{c}{Bilateral} & \\multicolumn{2}{c}{Dollar leg} & \\multicolumn{2}{c}{Renminbi vs basket}\\\\",
          "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}",
          "& 2018--19 & 2025 & 2018--19 & 2025 & 2018--19 & 2025 \\\\"),
    c("\\multicolumn{7}{l}{\\textit{Panel A. Day-5 response by type of bilateral news}}\\\\", pa,
      "\\addlinespace\\multicolumn{7}{l}{\\textit{Panel B. Response to headline tariff intensity $I_j$}}\\\\", pb),
    paste("Panel A interacts signed bilateral news with three mutually exclusive groups of events (Table~\\ref{tab:events}); de-escalation coefficients multiply $L^{BIL}_j = -1$",
          "and so report the response to an escalation-equivalent move. Panel B replaces $L^{BIL}_j$ by headline tariff intensity $I_j$ (percent of bilateral trade, per 10 points)",
          "(``Linear'') or by $\\operatorname{sign}(I_j)\\log(1+|I_j|)$ (``Signed log''). Events without a quantifiable ad valorem change have $I_j = 0$. U.S. escalation includes the two joint packages of 2018--19.",
          "95\\% wild cluster bootstrap-$t$ intervals in brackets."),
    size = "\\footnotesize", colsep = 3)
}
t5()

# ---------------------------------------------------------------- Table 6: central parity
t6 <- function() {
  r <- est$fix_reg; a <- pick(r, part == "w18"); b <- pick(r, part == "w25"); d <- pick(r, part == "diff")
  fd <- est$fix_desc; f <- function(w, v, dd = 1) num(fd[war == w][[v]], dd)
  row <- function(lab, v, dd = 1) sprintf("%s & %s & %s & \\\\", lab, f("2018-19", v, dd), f("2025", v, dd))
  body <- c("\\multicolumn{4}{l}{\\textit{Panel A. Response of fixing support to signed bilateral news}}\\\\",
    sprintf("Slope on $L^{BIL}_j$ (bp) & %s & %s & %s \\\\", num(a$est), num(b$est), num(d$est)),
    sprintf(" & {\\footnotesize %s} & {\\footnotesize %s} & {\\footnotesize %s} \\\\", ci(a$lo, a$hi), ci(b$lo, b$hi), ci(d$lo, d$hi)),
    sprintf("Wild cluster bootstrap $p$ & %s & %s & %s \\\\", pv(a$p), pv(b$p), pv(d$p)),
    "\\addlinespace\\multicolumn{4}{l}{\\textit{Panel B. Descriptive statistics}}\\\\",
    row("Mean fixing support (bp)", "mean_support"), row("Median fixing support (bp)", "median_support"),
    sprintf("Share of events with support $>0$ & %s & %s & \\\\", f("2018-19", "share_pos", 2), f("2025", "share_pos", 2)),
    row("Mean distance of close to weak edge of band (bp)", "mean_dist"),
    row("Minimum distance to weak edge (bp)", "min_dist"),
    sprintf("Events with close within 50 bp of weak edge & %d & %d & \\\\", fd[war == "2018-19", n_within50], fd[war == "2025", n_within50]))
  write_table("tab_fixing.tex", "The central parity leaned against depreciation in 2025", "tab:fixing", "lccc",
    "& 2018--19 & 2025 & Difference \\\\", body,
    paste("Fixing support $M_j = \\log(\\text{CNY close}_{t-1}) - \\log(\\text{fixing}_t)$, in basis points, compares the first official USD/CNY central parity after the event with the",
          "16:30 onshore close before it; a positive value is a fixing stronger than the market close. Distance to the weak edge is $\\log(1.02 \\times \\text{fixing}) - \\log(\\text{close})$ on the",
          "pre-event day, i.e.\\ how far the close stood from the depreciation limit of the $\\pm 2\\%$ daily band. Panel A regresses $M_j$ on signed bilateral and rest-of-world news by war with",
          "day-1 overlap clusters."))
}
t6()

# ---------------------------------------------------------------- Table 7: forward premia (licensed)
t7 <- function() {
  f <- est$fwd
  body <- unlist(lapply(c(1L, 5L, 10L), function(hh) c(sprintf("\\addlinespace\\multicolumn{5}{l}{\\textit{Day %d}}\\\\", hh),
    f[horizon == hh, sprintf("\\quad %s & %s & %s & %s & %s \\\\", tenor, num(1e4 * forward_premium),
      ci(1e4 * premium_ci_low, 1e4 * premium_ci_high), pv(premium_boot_p), pv(premium_rw_p))])))
  write_table("tab_forward.tex", "The forward curve did not price a delayed depreciation (offshore market, licensed data)", "tab:forward",
    "lcccc", "Maturity & Premium difference & 95\\% interval & $p$ & Romano--Wolf $p$ \\\\", body,
    paste("2025-minus-2018--19 difference in the response of the offshore forward premium (log CNH forward minus log CNH spot, in basis points) to signed bilateral news,",
          "path-inclusive, 68 events and 19 overlap clusters. A positive difference would indicate depreciation priced to arrive later. These estimates come from the companion",
          "licensed-data system (Bloomberg CNH spot and deliverable forwards, Hong Kong close) and are reproduced here from its output file",
          "\\texttt{data/forward\\_premium\\_estimates\\_v92.csv}; the underlying quotes cannot be redistributed (see the data-source list)."))
}
t7()

# ---------------------------------------------------------------- Appendix Table A1: event list
tA1 <- function() {
  e <- copy(ev)[order(war, event_date, event_id)]
  grp <- c("U.S. escalation" = "US", "China retaliation" = "CN", "Joint package" = "J", "De-escalation" = "D", "No bilateral news" = "--")
  sg <- function(x) ifelse(x > 0, "$+1$", ifelse(x < 0, "$-1$", "0"))
  flag <- c(named = "", imputed_rate = "a", approx = "b", timing_only = "c", not_customs = "d", no_bilateral_news = "")
  rows <- function(w) e[war == w, sprintf("%s & %s & %s & %s & %s & %s & %s%s \\\\", event_id, format(event_date), tex_escape(description),
                                          sg(l_bil), sg(l_row), grp[actor], num(dose, 2),
                                          ifelse(flag[dose_flag] == "", "", paste0("$^{", flag[dose_flag], "}$")))]
  out <- c("\\begin{center}\\scriptsize\\setlength{\\tabcolsep}{3pt}",
    "\\begin{longtable}{llp{7.6cm}cccr}",
    "\\caption{The 68 tariff-news events and their headline tariff intensity}\\label{tab:eventlist}\\\\",
    "\\toprule ID & Date & Description & $L^{BIL}$ & $L^{ROW}$ & Type & $I_j$ \\\\ \\midrule\\endfirsthead",
    "\\toprule ID & Date & Description & $L^{BIL}$ & $L^{ROW}$ & Type & $I_j$ \\\\ \\midrule\\endhead",
    "\\midrule\\multicolumn{7}{r}{\\textit{continued on next page}}\\\\\\endfoot",
    "\\bottomrule\\endlastfoot",
    "\\multicolumn{7}{l}{\\textit{Panel A. 2018--19 (intensity in \\% of 2017 bilateral goods trade, USD 635.2 billion)}}\\\\", rows("2018-19"),
    "\\addlinespace\\multicolumn{7}{l}{\\textit{Panel B. 2025 (intensity in \\% of 2024 bilateral goods trade, USD 583.6 billion)}}\\\\", rows("2025"),
    "\\end{longtable}\\end{center}",
    "\\vspace{-1.2em}\\begin{minipage}{\\linewidth}\\footnotesize\\textit{Notes:} Type: US = U.S. escalation, CN = Chinese retaliation, J = joint package, D = de-escalation.",
    "$I_j$ = covered trade $\\times$ announced change in the ad valorem rate, in percent of bilateral goods trade; the coding of each event is recorded in \\texttt{data/events.csv}.",
    "$^{a}$ Rate not named in the announcement; 25\\% (the proposed Section 301 rate) imputed.",
    "$^{b}$ Covered value or average rate approximated from contemporaneous official lists or estimates.",
    "$^{c}$ Timing or framework news without an announced rate change (coded 0).",
    "$^{d}$ Measure outside formal customs value (de minimis shipments, port fees; coded 0).",
    "Three candidates (TW2-027 court ruling, TW2-035 scope adjustment, TW2-041 Section 301 notice) were excluded before outcomes were examined.\\end{minipage}")
  writeLines(out, "tables/tab_event_list.tex")
}
tA1()

# ---------------------------------------------------------------- Appendix Table A2: basket weights
tA2 <- function() {
  w <- dcast(wts, currency ~ vintage, value.var = "weight")
  setnames(w, c("2017", "2026"), c("w17", "w26"))
  w[, in_basket := currency %in% BASKET]
  w[, r17 := ifelse(in_basket, w17 / sum(w17[in_basket]), NA)]
  w[, r26 := ifelse(in_basket, w26 / sum(w26[in_basket]), NA)]
  setorder(w, -w17, na.last = TRUE)
  f <- function(x) ifelse(is.na(x), "--", sprintf("%.2f", 100 * x))
  why <- c(USD = "numeraire", HKD = "USD peg", SAR = "USD peg", AED = "USD peg", MOP = "HKD peg", RUB = "no ECB quote")
  body <- w[, sprintf("%s & %s & %s & %s & %s & %s \\\\", currency, f(w17), f(r17), f(w26), f(r26),
                      ifelse(in_basket, "", why[currency]))]
  write_table("tab_basket.tex", "Currency basket used to measure the dollar leg", "tab:basket", "lccccl",
    "Currency & CFETS 2017 & Baseline & CFETS 2026 & Robustness & Excluded \\\\", body,
    paste("CFETS basket weights in percent (vintage effective 1 January 2017, in force throughout 2018--19; vintage effective 1 January 2026, the most recent with the full weight list published).",
          "The ``Baseline'' and ``Robustness'' columns renormalise the weights over the 19 non-dollar currencies quoted by the ECB; the baseline holds the 2017 basket fixed in both wars.",
          "Dollar pegs belong to the dollar leg; the ECB stopped quoting the rouble on 1 March 2022."),
    size = "\\footnotesize")
}
tA2()
