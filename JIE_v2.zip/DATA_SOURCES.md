# Data sources

Every file in `data/` is listed below, with its origin, how it was obtained, what it contains and which outputs use it. SHA-256 checksums identify the exact versions used for `JIE_v2.pdf`. Files 1–6 are unchanged from JIE_v1 and feed Sections 4–5; files 7–20 are new in JIE_v2 and feed Section 6 (Tables 8–10, A3–A6, Figures 5–6).

| File | Rows | Used for |
|---|---|---|
| `ecb_eurofxref_hist.csv` | 7,092 business days | all exchange-rate outcomes, Figures 1–3, A1–A2, Tables 2–5 |
| `cfets_basket_weights.csv` | 49 | dollar-leg basket, Table A2 |
| `events.csv` | 71 candidates (68 retained) | events, signed news, tariff intensity, Tables 1, 5, A1 |
| `us_china_trade.csv` | 2 | denominators of tariff intensity |
| `cny_fixing_events.csv` | 68 | central-parity support and band distance, Table 7, Figure 4 |
| `forward_premium_estimates_v92.csv` | 15 | Table 6 (licensed-data estimates) |
| `fed_h10_daily.csv` | 2,577 days | daily dollar leg and renminbi leg of Section 6 (Tables 8–10, A4–A6, Figures 5–6) |
| `fred_rates_daily.csv` | 2,562 days | U.S. 2-year and 3-month yields (Tables 9, A4–A6) |
| `shibor_daily.csv` | 2,680 days | Shibor 3-month and 1-year (Tables 9, A4, A6) |
| `vix_daily.csv` | 2,497 days | VIX (Tables 9, A4–A6) |
| `brent_daily.csv` | 2,502 days | Brent (Tables 9, A6) |
| `cny_fixing_daily.csv` | 2,365 days | central parity, fixing stance (Tables 9, A4, A6) |
| `events_extension.csv` | 27 candidates (20 retained) | 2020–24 and 2026 tariff events (Tables 9, A5, A6) |
| `safe_settlement_monthly.csv` | 200 months | SAFE bank settlement and sales by item (Tables 9, A3, A6) |
| `safe_receipts_payments_monthly.csv` | 200 months | SAFE cross-border receipts and payments by item and currency (Table A3) |
| `customs_cfets_monthly.csv` | 116 months | customs trade and CFETS client spot turnover (Tables A3, A6) |
| `policy_rate_changes.csv` | 28 | policy-rate changes of seven central banks (Table 9) |
| `pboc_usd_deposit_rates.csv` | 114 months | PBoC average rate on large USD deposits (Table A4) |
| `bop_annual_usd_bn.csv` | 17 items × 6 years | balance of payments (Table A3) |
| `cnh_rr25_annual.csv` | 12 | annual means of the USD/CNH 25-delta risk reversal, derived from licensed data (Table A4) |

---

## 1. `ecb_eurofxref_hist.csv`: ECB euro foreign exchange reference rates

- **Publisher:** European Central Bank, euro foreign exchange reference rates. The ECB sets them daily through a concertation among central banks at around 14:10 CET and publishes them at about 16:00 CET. Official page: <https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html>. Official full-history file: <https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist.zip>.
- **Copy used:** the unmodified `eurofxref-hist.csv` from the official zip, as redistributed inside the Python package `currencyconverter` version 0.18.22 (PyPI, file `currency_converter/eurofxref-hist.zip`). The last observation is 14 September 2026.
- **Contents:** units of each currency per euro, for 4 January 1999 to 14 September 2026. `N/A` marks days without a quote.
- **Processing (in `R/01_data.R`):** the file is restricted to 2017-01-01 to 2026-08-31 (JIE_v1 used 2026-06-30; the extension only serves the ECB cross-check rows of Table 8), and every rate is converted to log units per U.S. dollar. The dollar leg uses the 2017 CFETS weights renormalized over 19 currencies: EUR, JPY, KRW, AUD, MYR, SGD, GBP, THB, CAD, ZAR, CHF, MXN, TRY, PLN, SEK, NZD, DKK, HUF, NOK. The latent dollar factor adds CZK, ILS, INR, IDR, PHP and BRL.
- **Licence:** ECB statistics may be reused with attribution to the source.
- **SHA-256:** `f230f5499c2fc54552278d3a712b71e4be2dc3224e44dbf8be71ccdce330e4ea`

## 2. `cfets_basket_weights.csv`: CFETS RMB index basket weights

- **2017 vintage** (24 currencies, effective 1 January 2017, in force throughout 2018–19): CFETS, *Public Announcement of China Foreign Exchange Trade System on Adjusting Rules for Currency Baskets of CFETS RMB Indices*, 29 December 2016, <https://www.chinamoney.com.cn/english/svcnrl/20161229/2049.html>. Cross-checked against UOB China, *CFETS Upgrades Its RMB Index Basket* (30 December 2016).
- **2026 vintage** (25 currencies, effective 1 January 2026, based on 2024 trade): CFETS announcement of 31 December 2025, as reproduced in full by Sina Finance, <https://finance.sina.com.cn/roll/2025-12-31/doc-inhestep5283290.shtml>.
- **Why no 2025 vintage:** the full 2025 weight list (announced 31 December 2024 at <https://iftp.chinamoney.com.cn/chinese/zxpl/20241231/3028340.html>) could not be retrieved in full. Only the USD, EUR and JPY weights (18.903%, 17.902%, 8.584%) could be verified, from Reuters via Investing.com. The baseline therefore holds the 2017 basket fixed in both wars, and the 2026 vintage serves as the robustness basket. If the complete 2025 table becomes available, add it as vintage 2025 and change `basket_w(2026)` in `R/01_data.R`.
- **SHA-256:** `2306ae42052b3825cd1dad55248d4d425fcdb08a01ebcfef2f78c3df3f4f0445`

## 3. `events.csv`: tariff-news event archive and headline tariff intensity

- **Origin:** the 71-candidate narrative event archive of the authors' earlier project version (V9.3). The main sources are USTR and White House releases, the *Federal Register*, and the Ministry of Finance and State Council Tariff Commission of China, cross-checked against the PIIE timelines (Bown and Kolb 2025; Bown 2025). The primary URL of each event is in `source_url`, and `source` gives a short label.
- **Columns kept:** `event_id, war, event_date, category, l_bil, l_row, retained, exclusion_reason, description, source, source_url`. Three candidates (TW2-027, TW2-035, TW2-041) are not retained. They were excluded before any outcome was examined.
- **New in this version: headline tariff intensity.**
  - `covered_usd_bn` is the covered trade value in USD billion. `rate_change_pp` is the announced change in the ad valorem rate. `taxed_value_usd_bn` is their product divided by 100.
  - `dose_flag` records how each value was obtained: `named` (both value and rate named in the announcement or official list), `imputed_rate` (list named without a rate; the proposed Section 301 rate of 25% is imputed), `approx` (value or average rate approximated), `timing_only` (no rate change; coded 0), `not_customs` (outside formal customs value; coded 0), `no_bilateral_news` (implementation or rest-of-world only). `dose_basis` gives a one-line justification for each value.
  - External facts used in the `approx` rows: the U.S. sorghum exports behind the 178.6% deposit were USD 957 million in 2017 (Farm Progress, *China hits $957 million U.S. sorghum trade with fresh duty*). The February 2025 Chinese retaliation covered about USD 14 billion (Reuters, as reported; energy components in *China tariff retaliation targets its modest US energy imports*, Yahoo Finance/Reuters). The March 2025 Chinese retaliation covered USD 21 billion (Reuters calculation reported by The Poultry Site, 4 March 2025). The April 2025 electronics exemption covered 23% of U.S. imports from China (Capital Economics, reported by Al Jazeera, 14 April 2025). The line-count-weighted rates of the Chinese USD 60 billion list use the official line counts: 3 August 2018, 2,493 lines at 25%, 1,078 at 20%, 974 at 10% and 662 at 5% (18.6% on average); 18 September 2018, 3,571 lines at 10% and 1,636 at 5% (8.4%); May 2019, a return to the August structure (an increase of 10.2 points).
  - The intensity $I_j$ is computed in `R/01_data.R` as 100 × `taxed_value_usd_bn` / bilateral goods trade in the year before each war.
- **SHA-256:** `85f18d69a1f04ef6cd0ce22c9f623b437fbd747fc41436cc7a557b3cc6d39cd6`

## 4. `us_china_trade.csv`: U.S.–China goods trade

- **Source:** U.S. Census Bureau, *Trade in Goods with China*, annual totals in USD million, <https://www.census.gov/foreign-trade/balance/c5700.html> (accessed 24 September 2026).
- **Values:** 2017 exports 129,997.2 and imports 505,165.1; 2024 exports 143,271.7 and imports 440,319.4.
- **SHA-256:** `5722fbb0b1afd2274b2af1e94d745e794902c54c5f873acb032bb8f944f30788`

## 5. `cny_fixing_events.csv`: central parity and onshore close around each event

- **Contents:** for each of the 68 events, the onshore USD/CNY 16:30 close on the pre-event day (`cny_close_1630`), the central parity on that day (`fixing_on_pre_close_date`), and the first central parity after the event (`next_fixing`, `next_fixing_date`).
- **Origin:** the central parity is published daily by CFETS on behalf of the People's Bank of China (<https://www.chinamoney.com.cn/english/bmkcpr/>). The 16:30 close is the CFETS official onshore close. Both were retrieved through Bloomberg in the earlier project version, and the file holds only these published price points.
- **Spot check:** the central parity of 9 April 2025, 7.2066, matches the CFETS figure reported by Xinhua (*Market exchange rates in China – April 9*, 2025, "U.S. dollar 100 720.66").
- **SHA-256:** `f99c32356dc98721c7300e7677fc097530903bbec1deb32ca4b98b9c400d07cb`

## 6. `forward_premium_estimates_v92.csv`: licensed-data estimates (Table 6 only)

- **Contents:** cross-war differences in forward-premium responses at 1M, 3M, 6M, 1Y and 2Y, for horizons 1, 5 and 10, with bootstrap intervals and Romano–Wolf p-values.
- **Origin:** the output file `table_14_forward_premium_term_structure.csv` of the authors' V9.2 production run (seed 271828, 4,999 wild-bootstrap replications). That run used Bloomberg CNH spot and deliverable forward quotes at the Hong Kong close.
- **Why estimates rather than raw data:** the Bloomberg quotes are licensed and cannot be redistributed. This is the only output in the paper that cannot be rebuilt from raw data in this package. `R/03_tables.R` formats the table directly from this file.
- **SHA-256:** `851586b729ab6a157617a65c601d727086ddd0b4cfa8fa04fec827926f723d0c`


---

# Files added in JIE_v2 (Section 6)

## 7. `fed_h10_daily.csv`: Federal Reserve H.10 noon buying rates

- **Publisher:** Board of Governors of the Federal Reserve System, *Foreign Exchange Rates – H.10*, Data Download Program, <https://www.federalreserve.gov/releases/h10/>. Noon buying rates in New York, certified by the Federal Reserve Bank of New York, units of foreign currency per U.S. dollar (the euro, pound, Australian and New Zealand dollars are published as dollars per unit; the file keeps the Fed's convention as redistributed, i.e. all series are foreign currency per dollar after the mirror's harmonisation).
- **Copy used:** the daily file of the Open Knowledge Foundation "exchange-rates" data package, which mirrors the H.10 release (<https://raw.githubusercontent.com/datasets/exchange-rates/main/data/daily.csv>), retrieved 22 October 2026; last observation 16 October 2026.
- **Processing:** restricted to 1 December 2016 onwards and pivoted to one column per currency: CNY, EUR, JPY, KRW, AUD, HKD, MYR, SGD, GBP, THB, CAD, ZAR, CHF, MXN, SEK, NZD, DKK, NOK, TWD, INR, BRL. Days on which the renminbi or any basket currency is not quoted are dropped in `R/05_data_annual.R`. The 16-currency dollar leg uses the 2017 CFETS weights renormalised (HKD, SAR, AED are dollar pegs; RUB, TRY, PLN, HUF are not quoted).
- **Why H.10 and not the ECB rates in Section 6:** noon New York is about 00:00–01:00 Beijing time of the following day, which places the observation after the U.S. close and before the next central parity; see Section 4.2 of the paper. Table 8 shows that the ECB rates give the same annual decomposition.
- **Licence:** public domain (U.S. federal government data); the mirror is PDDL.
- **SHA-256:** `b6aaddbe9b4b938c309bf44f10c4003e3fe27e92d0287e3312c11bb4814b83ba`

## 8. `fred_rates_daily.csv`: U.S. Treasury yields

- **Publisher:** Federal Reserve Bank of St. Louis, FRED, series `DGS2` (2-year constant maturity) and `DGS3MO` (3-month constant maturity), from the Board of Governors H.15 release. Downloaded by the authors from <https://fred.stlouisfed.org/series/DGS2> and <https://fred.stlouisfed.org/series/DGS3MO> on 28 September 2026; last observation 25 September 2026.
- **Processing:** merged on date; U.S. holidays are blank. In `R/05_data_annual.R` short gaps are carried forward and, in the daily regressions, missing changes are set to zero.
- **SHA-256:** `4d8080619bb19b0ec39ae9420c97317555ace368f7373297d797871fb8963ea1`

## 9. `shibor_daily.csv`: Shanghai Interbank Offered Rate

- **Publisher:** China Foreign Exchange Trade System / National Interbank Funding Center, "Shibor数据" (historical data), <https://www.chinamoney.com.cn/chinese/bkshibor/>. Downloaded by the authors year by year (2016–2026) on 28 September 2026; last observation 29 September 2026.
- **Columns:** `ON, W1, M1, M3, M6, Y1` in percent. `M3` and `Y1` are used.
- **SHA-256:** `7adfa5002222be43222c3e6e5de3d123d644e5f263a5002752243898e4e57f3c`

## 10. `vix_daily.csv`: CBOE Volatility Index

- **Publisher:** Cboe Global Markets, VIX historical data (<https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv>), as mirrored by the Open Knowledge Foundation "finance-vix" data package (<https://raw.githubusercontent.com/datasets/finance-vix/main/data/vix-daily.csv>), retrieved 22 October 2026; last observation 22 September 2026. Daily close, from 1 December 2016.
- **SHA-256:** `9af30159a77795d5053335c1391fe54221d3eeb2c2afa30b28156e68f45f9e6f`

## 11. `brent_daily.csv`: Brent crude oil spot price

- **Publisher:** U.S. Energy Information Administration, Europe Brent Spot Price FOB (dollars per barrel), as mirrored by the Open Knowledge Foundation "oil-prices" data package (<https://raw.githubusercontent.com/datasets/oil-prices/main/data/brent-daily.csv>), retrieved 22 October 2026; last observation 14 October 2026. From 1 December 2016.
- **SHA-256:** `2fa0450ab5bcfd19fcf287ff70a6f4fc699af4c48540693fd035892da8774a11`

## 12. `cny_fixing_daily.csv`: USD/CNY central parity

- **Publisher:** State Administration of Foreign Exchange, 人民币汇率中间价 (annual files 2017–2026, <https://www.safe.gov.cn/safe/rmbhlzjj/index.html>), authorised by the PBoC and published by CFETS at 09:15 Beijing time. Downloaded by the authors on 29 September 2026; last observation 24 September 2026. Units: renminbi per dollar (the source quotes per 100 dollars; divided by 100).
- **Use:** the fixing stance of Section 6 is the log fixing of day *t* minus the log H.10 rate of day *t−1*.
- **SHA-256:** `31c635523d810af2c19e82f37af4e563732ff7319971bddac683aa5512a07fdf`

## 13. `events_extension.csv`: tariff-news events of 2020–24 and 2026

- **Origin:** 27 candidate announcements coded by the authors with the rule of `events.csv` (Section 4.2): 15 for 15 December 2019 to 31 December 2024 (12 retained) and 12 for 2026 (8 retained). Same columns as `events.csv`; `war` takes the values `2020-24` and `2026`. Sources are listed in `source_url`; all were opened on 26 September 2026. A verification note for every row accompanies the authors' working files.
- **Use:** only the tariff-news-day dummies of Section 6 (the event study of Section 5 uses the 68 events of `events.csv` alone).
- **SHA-256:** `6a7f3f77f8d754a05c5da045fb5bcf86a8148cb15a8e4d7f7dc0e38cf2f88a00`

## 14. `safe_settlement_monthly.csv`: bank settlement and sales of foreign exchange

- **Publisher:** State Administration of Foreign Exchange, 银行结售汇数据时间序列 (time series, monthly, USD, sheet 以美元计价（月度）), <https://www.safe.gov.cn/safe/tjsj1/index.html>. Downloaded by the authors on 27 September 2026; January 2010 to August 2026. Units in the file: USD 100 million (the source unit); converted to USD billion in `R/05_data_annual.R`.
- **Columns:** `js_*` settlement (bank purchases of FX from clients) and `ss_*` sales, total / client / goods trade / services / capital and financial account; `fwd_sign_*` forward contracts signed; `fwd_out_*` outstanding; `opt_delta` option delta.
- **Cross-check:** the national series agrees with the sum of the 36 regional files in 78 of 80 months from 2020 (two months differ because of later revisions).
- **SHA-256:** `84750c67a0402ed430dffa17cc1a56dba37e0ab9ca03d219333cd96d166fa464`

## 15. `safe_receipts_payments_monthly.csv`: cross-border receipts and payments by bank clients

- **Publisher:** SAFE, 银行代客涉外收付款数据时间序列 (monthly, USD, sheet 以美元计值（月度）). Downloaded 27 September 2026; January 2010 to August 2026; USD 100 million.
- **Columns:** `rec_*` receipts and `pay_*` payments, by item (`all, ca, goods, services, fa`) and by currency (`rmb, fx, usd, hkd, eur, jpy`). The currency split exists only for the total of all items.
- **SHA-256:** `dad60e5c4b5e7e3e5dc053d52ef570c245ad31f24168ba71cd487df2a7d21d9c`

## 16. `customs_cfets_monthly.csv`: customs trade and CFETS client spot turnover

- **Customs:** General Administration of Customs, 进出口商品总值表 (monthly), exports, imports and balance; the latest revised release of each month is used; converted from renminbi at the monthly average central parity where the dollar release is unavailable (column `cus_source` of the authors' build file records this). January 2017 to August 2026, USD billion.
- **CFETS:** 中国外汇市场交易概况 (annual workbooks 2017–2026, USD version), bank-to-client spot market: purchases of FX from clients and sales of FX to clients, USD billion.
- **SHA-256:** `09b08996da9b0808fdb3f9a0e7b198f5183fec11c0722ee2447e8b7b1178a2eb`

## 17. `policy_rate_changes.csv`: policy-rate changes over the four windows

- **Content:** the change in the policy rate of the Federal Reserve (target range upper bound), the ECB (deposit facility rate), the Bank of Japan, the Bank of Korea, the Reserve Bank of Australia, the Bank of England and the Bank of Canada over each window (calendar years 2018, 2019 and 2025; January–August 2026), with the decisions listed in `decisions` and the source type in `source`. Compiled by the authors from the central banks' decision statements; the 2026 entries were checked against the ECB account of the 9–10 September 2026 meeting, the BoJ statement of 16 June 2026, the BoK decision of 27 August 2026, the RBA release of 29 September 2026, the BoE September 2026 summary and the BoC release of 2 September 2026.
- **Use:** the "relative monetary policy" row of Table 9, with CFETS 2017 weights over the six basket central banks.
- **SHA-256:** `8ff4cf46e1159f666c18dfcc0cc028bc4a49db5f6256d89852b6eaf01789f0b6`

## 18. `pboc_usd_deposit_rates.csv`: average interest rate on large USD deposits

- **Publisher:** People's Bank of China, *China Monetary Policy Report* (quarterly), table "大额美元存款与美元贷款平均利率" (average rates on large USD deposits and USD loans), monthly values by maturity. Transcribed by the authors from the 38 reports for 2017Q1–2026Q2 (PBoC website, 货币政策执行报告); 114 months, January 2017 to June 2026; percent. Each month appears in several reports and the values were checked to be identical across them.
- **Columns:** demand, under 3 months, 3–6 months, 6–12 months, 1 year, over 1 year. The 1-year rate is used in Table A4.
- **SHA-256:** `aa197022e6c9f30ef704188c243b24f8c0d7a351be625ac9776041fd575feeb3`

## 19. `bop_annual_usd_bn.csv`: balance of payments

- **Publisher:** SAFE, 中国国际收支平衡表时间序列 (BPM6), annual table in USD (sheet 年度BOP（美元）), downloaded 27 September 2026. Seventeen items for 2017, 2018, 2019, 2023, 2024 and 2025, converted from USD 100 million to USD billion and rounded to one decimal. BPM6 sign convention: a negative asset entry is a net acquisition of assets abroad.
- **SHA-256:** `e47f91116d8f53d8daa899a85fe9d6b0ad502ae98ef917468cc072233bc55fd5`

## 20. `cnh_rr25_annual.csv`: USD/CNH 25-delta risk reversal, annual means (derived from licensed data)

- **Origin:** annual means (volatility points) and day counts of the 1-month and 1-year 25-delta risk reversal from the Bloomberg USD/CNH option strategies behind Table 6 (BGN, Tokyo 15:00 cut), computed by the authors from the licensed daily quotes for 2017–2020 and 2024–2025 (the extract has no 2021–23 quotes). The daily quotes cannot be redistributed; only these annual means are included, and they are used only in panel C of Table A4.
- **SHA-256:** `70223b2db291213c76848dd2a64e66dcb396c6b9d26197f9e66a6d632e776cfb`
