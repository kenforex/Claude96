# JIE_v2 — Replication package

**Where Did the Renminbi's Tariff Response Go? The Dollar Leg of Two U.S.–China Trade Wars**
Xinxin Wei, Yi Pang, Muhammad Ali Nasir (University of Leeds), October 2026.

JIE_v2 adds to JIE_v1 a new Section 6, "From event days to years", which attributes the annual change in USD/CNY in 2018, 2019, 2025 and January–August 2026 to its sources. In `JIE_v2.tex` every passage that is new or changed relative to JIE_v1 is set in green (`\new{...}` and `\color{v2green}`); the compiled `JIE_v2.pdf` shows the same colouring. Nothing in Sections 1–5 was re-estimated: the nine JIE_v1 tables are reproduced bit for bit by the same code.

## Quick start

From this folder:

```
Rscript R/00_run_all.R      # rebuilds tables/ and figures/ from data/ (about 40 seconds)
pdflatex JIE_v2
bibtex   JIE_v2
pdflatex JIE_v2
pdflatex JIE_v2             # produces JIE_v2.pdf (36 pages)
```

## Requirements

- R ≥ 4.1 with `data.table`, `ggplot2` (≥ 3.4) and `scales`. Nothing else: the Section 6 scripts use base R only (Newey–West standard errors and two-stage least squares are written out by hand). Tested with R 4.3.3, data.table 1.14.10, ggplot2 3.4.4.
- Figures are written with `cairo_pdf` in Liberation Sans; if the font is missing, cairo substitutes the default sans-serif font (change `FONT` in `R/04_figures.R`).
- A standard TeX distribution with pdfLaTeX, BibTeX, natbib, booktabs, longtable, caption and xcolor.

All random draws (wild cluster bootstrap, 9,999 replications; randomization inference, 2,000 draws) use seed `20260924` and are reset inside every call. Section 6 uses no random numbers. Tables are bit-identical across runs.

## Contents

```
JIE_v2.tex, JIE_v2.bib     manuscript and references; the manuscript \input's tables/ and includes figures/
JIE_v2.pdf                 compiled manuscript
DATA_SOURCES.md            origin, retrieval, processing and SHA-256 of every data file
data/                      20 input files (6 from JIE_v1, 14 new; see DATA_SOURCES.md)
R/00_run_all.R             master script: sets seed and replication counts, runs 01–08
R/01_data.R                daily ECB panel (USD/CNY, dollar leg, renminbi vs basket), events, event windows, overlap clusters
R/02_estimation.R          local projections, wild cluster bootstrap, latent dollar factor, robustness, actors and intensity,
                           randomization inference, leave-one-cluster-out, central parity
R/03_tables.R              writes Tables 1–7, A1–A2 (one .tex file per table)
R/04_figures.R             writes Figures 1–4, A1–A2 (one .pdf file per figure)
R/05_data_annual.R         NEW: daily Fed H.10 panel with rates, VIX, oil, fixing and all four tariff episodes; monthly SAFE flows
R/06_estimation_annual.R   NEW: annual decomposition, dollar beta, daily and monthly regressions, IV, attribution and shares
R/07_tables_annual.R       NEW: writes Tables 8–10, A3–A6
R/08_figures_annual.R      NEW: writes Figures 5–6
tables/                    16 tables (generated)
figures/                   8 figures (generated)
```

The scripts pass objects in memory. The only files written are the `.tex` files in `tables/` and the `.pdf` files in `figures/`; no intermediate data are saved. Every function and block carries a comment header that states what it does, where it is called from, and which tables and figures depend on it.

## Map from outputs to the paper

| Paper | File | Produced by |
|---|---|---|
| Table 1 | `tables/tab_events.tex` | `03_tables.R::t1` |
| Table 2 | `tables/tab_bilateral.tex` | `t2` |
| Table 3 | `tables/tab_decomposition.tex` | `t3` |
| Table 4 | `tables/tab_robustness.tex` | `t4` |
| Table 5 | `tables/tab_actors_intensity.tex` | `t5` |
| Table 6 | `tables/tab_forward.tex` | `t7` (from licensed-data estimates) |
| Table 7 | `tables/tab_fixing.tex` | `t6` |
| Table 8 | `tables/tab_annual_decomp.tex` | `07_tables_annual.R::t8` |
| Table 9 | `tables/tab_attribution_legs.tex` | `t9` |
| Table 10 | `tables/tab_usdcny_shares.tex` | `t10` |
| Table A1 | `tables/tab_event_list.tex` | `03_tables.R::tA1` |
| Table A2 | `tables/tab_basket.tex` | `tA2` |
| Table A3 | `tables/tab_flows_bop.tex` | `07_tables_annual.R::tA3` |
| Table A4 | `tables/tab_policy_carry.tex` | `tA4` |
| Table A5 | `tables/tab_episodes.tex` | `tA5` |
| Table A6 | `tables/tab_regressions.tex` | `tA6` |
| Figure 1 | `figures/fig_paths.pdf` | `04_figures.R` |
| Figure 2 | `figures/fig_responses.pdf` | `04_figures.R` |
| Figure 3 | `figures/fig_events_day5.pdf` | `04_figures.R` |
| Figure 4 | `figures/fig_fixing.pdf` | `04_figures.R` |
| Figure 5 | `figures/fig_annual_decomp.pdf` | `08_figures_annual.R` |
| Figure 6 | `figures/fig_attribution.pdf` | `08_figures_annual.R` |
| Figure A1 | `figures/fig_randomisation.pdf` | `04_figures.R` |
| Figure A2 | `figures/fig_leave_one_out.pdf` | `04_figures.R` |

## What is new in Section 6, in one paragraph

`05_data_annual.R` builds a daily panel from the Fed H.10 noon rates (16-currency dollar leg, same weighting rule as the ECB basket), U.S. Treasury yields, Shibor, the VIX, Brent, the SAFE central parity and the tariff-event calendar of all four episodes, and a monthly panel of SAFE bank settlement and customs trade. `06_estimation_annual.R` (i) decomposes each annual change into the dollar leg and the renminbi leg and estimates the renminbi's beta to the dollar; (ii) regresses the daily dollar leg on U.S. yields, the VIX, oil and tariff days; (iii) regresses the daily renminbi leg on the dollar leg (year-specific) and the same controls; (iv) estimates monthly regressions of the renminbi-specific component on the fixing stance, the carry and net settlement, with net settlement instrumented by the customs surplus; and (v) turns these into an accounting attribution with shares, plus the sensitivity ranges reported in the notes of Table 10. The checks behind the "Mechanisms" subsection (flows, balance of payments, fixing stance, carry, option skew, event-day responses by episode) are computed in block 6 of the same script.

## Licensed data

Table 6 and panel C of Table A4 are reproduced from estimates (`forward_premium_estimates_v92.csv`) and annual means (`cnh_rr25_annual.csv`) computed from Bloomberg quotes that cannot be redistributed. Everything else is built from public sources listed in `DATA_SOURCES.md`.
